package com.redclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;

/** Aimbot + auto attack. fast=true -> instant snap and attack every tick (1.8 style). */
public class Aura extends Module {
    private final boolean fast;

    public Aura(String name, String desc, boolean fast) {
        super(name, desc);
        this.fast = fast;
    }

    @Override
    protected void onEnable() {
        // the two modes exclude each other
        if (fast) Modules.AIM_AURA.setEnabled(false);
        else Modules.FAST_AURA.setEnabled(false);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null || !p.isAlive()) return;

        double range = fast ? 3.9 : 3.4;
        Vec3d eye = p.getEyePos();

        LivingEntity target = mc.world.getEntitiesByClass(
                        LivingEntity.class,
                        p.getBoundingBox().expand(range + 1.5),
                        e -> e != p && e.isAlive() && !(e instanceof ArmorStandEntity)
                                && !(e instanceof TameableEntity t && t.isOwner(p))
                                && p.canSee(e)
                                && eye.distanceTo(e.getBoundingBox().getCenter()) <= range)
                .stream()
                .min(Comparator.comparingDouble(e -> eye.distanceTo(e.getBoundingBox().getCenter())))
                .orElse(null);
        if (target == null) return;

        float left = look(p, target.getBoundingBox().getCenter(), fast ? 360f : 28f);

        boolean ready = fast || p.getAttackCooldownProgress(0.5f) >= 1.0f;
        if (ready && left < 20f) {
            mc.interactionManager.attackEntity(p, target);
            p.swingHand(Hand.MAIN_HAND);
        }
    }

    /** Turns the player towards a point; returns the remaining angle in degrees. */
    private static float look(ClientPlayerEntity p, Vec3d to, float maxStep) {
        Vec3d eye = p.getEyePos();
        double dx = to.x - eye.x, dy = to.y - eye.y, dz = to.z - eye.z;
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yawT = (float) (MathHelper.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
        float pitchT = (float) -(MathHelper.atan2(dy, flat) * 180.0 / Math.PI);

        float dYaw = MathHelper.wrapDegrees(yawT - p.getYaw());
        float dPitch = pitchT - p.getPitch();
        float sYaw = MathHelper.clamp(dYaw, -maxStep, maxStep);
        float sPitch = MathHelper.clamp(dPitch, -maxStep, maxStep);

        p.setYaw(p.getYaw() + sYaw);
        p.setPitch(MathHelper.clamp(p.getPitch() + sPitch, -90f, 90f));
        return Math.max(Math.abs(dYaw - sYaw), Math.abs(dPitch - sPitch));
    }
}
