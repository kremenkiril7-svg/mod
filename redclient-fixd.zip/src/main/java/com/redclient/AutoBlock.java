package com.redclient;

import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.FallingBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** Places a block under the player's feet (scaffold). Needs blocks in the hotbar. */
public class AutoBlock extends Module {
    public AutoBlock() {
        super("Авто-блок под себя", "Ставит блок из хотбара под ноги");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null || mc.interactionManager == null || mc.currentScreen != null) return;

        BlockPos target = BlockPos.ofFloored(p.getX(), p.getY() - 0.5, p.getZ());
        if (!w.getBlockState(target).isReplaceable()) return;

        int slot = findBlockSlot(p);
        if (slot < 0) return;

        for (Direction d : Direction.values()) {
            BlockPos n = target.offset(d);
            if (w.getBlockState(n).isReplaceable()) continue;

            Direction face = d.getOpposite();
            Vec3d hit = Vec3d.ofCenter(n).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);

            int prev = p.getInventory().selectedSlot;
            p.getInventory().selectedSlot = slot;
            ActionResult r = mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(hit, face, n, false));
            if (r.isAccepted()) p.swingHand(Hand.MAIN_HAND);
            p.getInventory().selectedSlot = prev;
            return;
        }
    }

    private static int findBlockSlot(ClientPlayerEntity p) {
        int cur = p.getInventory().selectedSlot;
        if (isPlaceable(p.getInventory().getStack(cur))) return cur;
        for (int i = 0; i < 9; i++) {
            if (isPlaceable(p.getInventory().getStack(i))) return i;
        }
        return -1;
    }

    private static boolean isPlaceable(ItemStack s) {
        return !s.isEmpty() && s.getItem() instanceof BlockItem bi
                && !(bi.getBlock() instanceof BlockEntityProvider)
                && !(bi.getBlock() instanceof FallingBlock);
    }
}
