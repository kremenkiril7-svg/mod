package com.redclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.MathHelper;

/** Velocity fly: WASD to move, Space up, Shift down. */
public class Fly extends Module {
    private static final double SPEED = 0.8;
    private static final double VERTICAL = 0.6;

    public Fly() {
        super("Полёт", "WASD, Space вверх, Shift вниз");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null) return;

        float yaw = p.getYaw() * 0.017453292f;
        double fx = -MathHelper.sin(yaw), fz = MathHelper.cos(yaw);   // forward
        double lx = MathHelper.cos(yaw), lz = MathHelper.sin(yaw);    // left

        double mx = 0, mz = 0;
        if (mc.options.forwardKey.isPressed()) { mx += fx; mz += fz; }
        if (mc.options.backKey.isPressed())    { mx -= fx; mz -= fz; }
        if (mc.options.leftKey.isPressed())    { mx += lx; mz += lz; }
        if (mc.options.rightKey.isPressed())   { mx -= lx; mz -= lz; }

        double len = Math.sqrt(mx * mx + mz * mz);
        if (len > 0) { mx = mx / len * SPEED; mz = mz / len * SPEED; }

        double vy = 0;
        if (mc.options.jumpKey.isPressed()) vy += VERTICAL;
        if (mc.options.sneakKey.isPressed()) vy -= VERTICAL;

        p.setVelocity(mx, vy, mz);
        p.fallDistance = 0;
    }
}
