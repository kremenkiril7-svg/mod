package com.redclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class MenuScreen extends Screen {
    private static final int W = 230, ROW = 24, HEAD = 34;

    public MenuScreen() {
        super(Text.literal("Red Menu"));
    }

    @Override
    public boolean shouldPause() { return false; }

    private int panelH() { return HEAD + Modules.ALL.size() * ROW + 6; }
    private int px() { return (width - W) / 2; }
    private int py() { return (height - panelH()) / 2; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        int x = px(), y = py(), h = panelH();

        ctx.fill(0, 0, width, height, 0x60200000);          // dim
        ctx.fill(x - 2, y - 2, x + W + 2, y + h + 2, 0xFFB00000); // border
        ctx.fill(x, y, x + W, y + h, 0xF0180000);           // body
        ctx.fill(x, y, x + W, y + HEAD - 6, 0xFF8B0000);    // header
        ctx.drawCenteredTextWithShadow(textRenderer, "RED MENU", x + W / 2, y + 10, 0xFFFFFFFF);

        String hint = null;
        for (int i = 0; i < Modules.ALL.size(); i++) {
            Module m = Modules.ALL.get(i);
            int ry = y + HEAD + i * ROW;
            boolean hover = mouseX >= x + 6 && mouseX <= x + W - 6 && mouseY >= ry && mouseY < ry + ROW - 3;
            boolean on = m.isEnabled();

            int bg = on ? (hover ? 0xFFE01c1c : 0xFFC81414) : (hover ? 0xFF4A0E0E : 0xFF2A0606);
            ctx.fill(x + 6, ry, x + W - 6, ry + ROW - 3, bg);
            ctx.drawText(textRenderer, m.name, x + 12, ry + 7, 0xFFFFFFFF, true);
            String s = on ? "ON" : "OFF";
            ctx.drawText(textRenderer, s, x + W - 12 - textRenderer.getWidth(s), ry + 7, on ? 0xFFFFFFFF : 0xFFAA6666, true);
            if (hover) hint = m.desc;
        }
        if (hint != null) {
            ctx.drawCenteredTextWithShadow(textRenderer, hint, width / 2, y + h + 8, 0xFFFF8888);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int x = px(), y = py();
            for (int i = 0; i < Modules.ALL.size(); i++) {
                int ry = y + HEAD + i * ROW;
                if (mouseX >= x + 6 && mouseX <= x + W - 6 && mouseY >= ry && mouseY < ry + ROW - 3) {
                    Modules.ALL.get(i).toggle();
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
