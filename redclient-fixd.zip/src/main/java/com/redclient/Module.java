package com.redclient;

import net.minecraft.client.MinecraftClient;

public abstract class Module {
    public final String name;
    public final String desc;
    private boolean enabled;

    protected Module(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }

    public boolean isEnabled() { return enabled; }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean v) {
        if (v == enabled) return;
        enabled = v;
        if (v) onEnable(); else onDisable();
    }

    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick(MinecraftClient mc) {}
}
