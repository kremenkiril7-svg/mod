package com.redclient;

import java.util.List;

public final class Modules {
    public static final Aura AIM_AURA  = new Aura("Наводка + автоатака", "Плавная наводка и атака по кулдауну (1.9+)", false);
    public static final Aura FAST_AURA = new Aura("Быстрая наводка 1.8", "Мгновенная наводка + атака каждый тик (как в 1.8)", true);
    public static final AutoBlock AUTO_BLOCK = new AutoBlock();
    public static final Fly FLY = new Fly();
    public static final XRay XRAY = new XRay();

    public static final List<Module> ALL = List.of(AIM_AURA, FAST_AURA, AUTO_BLOCK, FLY, XRAY);

    private Modules() {}
}
