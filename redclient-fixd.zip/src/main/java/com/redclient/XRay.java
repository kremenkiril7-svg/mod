package com.redclient;

import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.Registries;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** X-Ray: only ores & some valuable blocks are drawn. Does NOT work together with Sodium. */
public class XRay extends Module {
    public static volatile boolean active = false;
    private static final Map<Block, Boolean> CACHE = new ConcurrentHashMap<>();

    public XRay() {
        super("XRay", "Видны только руды, сундуки, спавнеры, лава");
    }

    public static boolean isVisible(Block b) {
        return CACHE.computeIfAbsent(b, XRay::test);
    }

    private static boolean test(Block b) {
        String id = Registries.BLOCK.getId(b).getPath();
        return id.endsWith("_ore") || id.equals("ancient_debris") || id.equals("gilded_blackstone")
                || id.equals("chest") || id.equals("trapped_chest") || id.equals("ender_chest")
                || id.equals("spawner") || id.equals("trial_spawner") || id.equals("lava");
    }

    @Override
    protected void onEnable() {
        active = true;
        reload();
    }

    @Override
    protected void onDisable() {
        active = false;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        reload();
    }

    @Override
    public void onTick(MinecraftClient mc) {
        // fullbright so caves are visible
        if (mc.player != null && !mc.player.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
            mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1_000_000, 0, false, false, false));
        }
    }

    private static void reload() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.worldRenderer != null && mc.world != null) mc.worldRenderer.reload();
    }
}
