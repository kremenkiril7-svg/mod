package com.redclient.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import com.redclient.XRay;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Block.class)
public class BlockMixin {
    @Inject(method = "shouldDrawSide", at = @At("HEAD"), cancellable = true)
    private static void redclient$xray(CallbackInfoReturnable<Boolean> cir,
                                       @Local(argsOnly = true, ordinal = 0) BlockState state) {
        if (XRay.active) cir.setReturnValue(XRay.isVisible(state.getBlock()));
    }
}
