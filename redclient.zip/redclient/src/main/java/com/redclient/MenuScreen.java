package com.redclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class MenuScreen extends Screen {
    private static final int W = 280, ROW = 24, HEAD = 26;
    private Module listening;

    public MenuScreen() { super(Text.literal("Red Client")); }

    public boolean isListening() { return listening != null; }
    @Override public boolean shouldPause() { return false; }

    private int px() { return (width - W) / 2; }
    private int py() { return (height - (HEAD + RedClient.MODULES.size() * ROW + 28)) / 2; }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) { }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x77000000);
        int x = px(), y = py();
        int h = HEAD + RedClient.MODULES.size() * ROW + 28;

        ctx.fill(x - 2, y - 2, x + W + 2, y + h + 2, 0xFFFF2A2A);
        ctx.fill(x, y, x + W, y + h, 0xF0200000);
        ctx.fill(x, y, x + W, y + HEAD - 2, 0xFFC81414);
        ctx.drawCenteredTextWithShadow(textRenderer, "RED CLIENT", width / 2, y + 8, 0xFFFFFFFF);

        int i = 0;
        for (Module m : RedClient.MODULES) {
            int ry = y + HEAD + i * ROW;
            boolean hover = mouseX >= x + 6 && mouseX <= x + W - 6 && mouseY >= ry && mouseY < ry + ROW - 3;
            int bg = m.enabled ? (hover ? 0xFFE02020 : 0xFFB01010) : (hover ? 0xFF4A1010 : 0xFF330808);
            ctx.fill(x + 6, ry, x + W - 6, ry + ROW - 3, bg);
            ctx.drawText(textRenderer, m.name, x + 12, ry + 7, 0xFFFFFFFF, true);

            int kx1 = x + W - 84, kx2 = x + W - 10;
            boolean kh = mouseX >= kx1 && mouseX <= kx2 && mouseY >= ry + 2 && mouseY < ry + ROW - 5;
            ctx.fill(kx1, ry + 2, kx2, ry + ROW - 5, kh ? 0xFF000000 : 0xFF150000);
            String label = listening == m ? "..." : (m.key == -1 ? "—" : keyName(m.key));
            ctx.drawCenteredTextWithShadow(textRenderer, label, (kx1 + kx2) / 2, ry + 7, 0xFFFFAAAA);
            i++;
        }
        ctx.drawCenteredTextWithShadow(textRenderer,
                "ЛКМ - вкл/выкл | клик по клавише - назначить (Backspace - убрать)",
                width / 2, y + h - 14, 0xFFCC8888);
    }

    private static String keyName(int key) {
        return InputUtil.fromKeyCode(key, 0).getLocalizedText().getString();
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int x = px(), y = py();
        int i = 0;
        for (Module m : RedClient.MODULES) {
            int ry = y + HEAD + i * ROW;
            if (my >= ry && my < ry + ROW - 3 && mx >= x + 6 && mx <= x + W - 6) {
                int kx1 = x + W - 84, kx2 = x + W - 10;
                if (mx >= kx1 && mx <= kx2) {
                    listening = m;
                } else {
                    listening = null;
                    m.toggle();
                }
                return true;
            }
            i++;
        }
        listening = null;
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listening != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                // отмена
            } else if (keyCode == GLFW.GLFW_KEY_BACKSPACE || keyCode == GLFW.GLFW_KEY_DELETE) {
                listening.key = -1;
            } else if (keyCode != RedClient.MENU_KEY) {
                listening.key = keyCode;
            }
            listening = null;
            RedClient.save();
            return true;
        }
        if (keyCode == RedClient.MENU_KEY) return true; // закрывается в tick (чтобы не открылось заново)
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() { RedClient.save(); }
}
