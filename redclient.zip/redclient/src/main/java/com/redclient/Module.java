package com.redclient;

import net.minecraft.client.MinecraftClient;

public abstract class Module {
    public final String id;
    public final String name;
    public int key = -1;
    public boolean enabled;
    boolean wasDown;
    protected final MinecraftClient mc = MinecraftClient.getInstance();

    protected Module(String id, String name) { this.id = id; this.name = name; }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean v) {
        if (v == enabled) return;
        enabled = v;
        if (v) onEnable(); else onDisable();
    }

    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick() {}
}
