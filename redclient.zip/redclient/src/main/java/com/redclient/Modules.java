package com.redclient;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.UUID;

public final class Modules {
    private Modules() {}

    public static final KillAura KILL_AURA = new KillAura();
    public static final FastAura FAST_AURA = new FastAura();
    public static final AutoBlock AUTO_BLOCK = new AutoBlock();
    public static final Fly FLY = new Fly();
    public static final XRay XRAY = new XRay();
    public static final NightVision NIGHT_VISION = new NightVision();
    public static final Speed SPEED = new Speed();
    public static final Esp ESP = new Esp();

    public static void init() {
        RedClient.MODULES.add(KILL_AURA);
        RedClient.MODULES.add(FAST_AURA);
        RedClient.MODULES.add(AUTO_BLOCK);
        RedClient.MODULES.add(FLY);
        RedClient.MODULES.add(XRAY);
        RedClient.MODULES.add(NIGHT_VISION);
        RedClient.MODULES.add(SPEED);
        RedClient.MODULES.add(ESP);
    }

    // ---------- helpers ----------

    static LivingEntity findTarget(double range) {
        MinecraftClient mc = MinecraftClient.getInstance();
        LivingEntity best = null;
        double bestD = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == mc.player || !le.isAlive()) continue;
            if (e instanceof ArmorStandEntity) continue;
            double d = mc.player.distanceTo(e);
            if (d <= range && d < bestD) { best = le; bestD = d; }
        }
        return best;
    }

    static void aim(Entity t) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Vec3d eye = mc.player.getEyePos();
        Vec3d to = t.getPos().add(0, t.getHeight() * 0.6, 0);
        double dx = to.x - eye.x, dy = to.y - eye.y, dz = to.z - eye.z;
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        mc.player.setYaw(yaw);
        mc.player.setPitch(pitch);
    }

    static void attack(Entity t) {
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.interactionManager.attackEntity(mc.player, t);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    /** Меняет скорость атаки у серверного игрока (одиночный мир), чтобы убрать кулдаун 1.9+ (как в 1.8). */
    static void setServerAttackSpeed(double value) {
        MinecraftClient mc = MinecraftClient.getInstance();
        MinecraftServer server = mc.getServer();
        if (server == null || mc.player == null) return;
        UUID id = mc.player.getUuid();
        server.execute(() -> {
            var sp = server.getPlayerManager().getPlayer(id);
            if (sp != null && sp.getAttributeInstance(EntityAttributes.ATTACK_SPEED) != null) {
                sp.getAttributeInstance(EntityAttributes.ATTACK_SPEED).setBaseValue(value);
            }
        });
    }

    public static boolean isXrayBlock(Block b) {
        String p = Registries.BLOCK.getId(b).getPath();
        return p.endsWith("_ore") || p.equals("ancient_debris") || p.equals("spawner")
                || p.equals("chest") || p.equals("trapped_chest") || p.equals("ender_chest")
                || p.equals("lava") || p.equals("water") || p.equals("end_portal_frame")
                || p.equals("gilded_blackstone") || p.equals("diamond_block") || p.equals("emerald_block");
    }

    // ---------- modules ----------

    public static class KillAura extends Module {
        public KillAura() { super("killaura", "Наводка + Авто-атака"); }
        @Override public void onTick() {
            LivingEntity t = findTarget(6.0);
            if (t == null) return;
            aim(t);
            if (mc.player.getAttackCooldownProgress(0.5f) >= 1.0f) attack(t);
        }
    }

    public static class FastAura extends Module {
        public FastAura() { super("fastaura", "Быстрая атака (как 1.8)"); }
        @Override protected void onEnable() { setServerAttackSpeed(1000.0); }
        @Override protected void onDisable() { setServerAttackSpeed(4.0); }
        @Override public void onTick() {
            if (mc.player.age % 20 == 0) setServerAttackSpeed(1000.0);
            LivingEntity t = findTarget(6.0);
            if (t == null) return;
            aim(t);
            attack(t);
        }
    }

    public static class AutoBlock extends Module {
        public AutoBlock() { super("autoblock", "Авто-блок под собой"); }
        @Override public void onTick() {
            BlockPos below = BlockPos.ofFloored(mc.player.getX(), mc.player.getY() - 1.0, mc.player.getZ());
            if (!mc.world.getBlockState(below).isReplaceable()) return;

            int slot = -1;
            for (int i = 0; i < 9; i++) {
                ItemStack s = mc.player.getInventory().getStack(i);
                if (!s.isEmpty() && s.getItem() instanceof BlockItem bi
                        && bi.getBlock().getDefaultState().isSolidBlock(mc.world, below)) { slot = i; break; }
            }
            if (slot == -1) return;

            for (Direction d : Direction.values()) {
                BlockPos n = below.offset(d);
                BlockState st = mc.world.getBlockState(n);
                if (st.isReplaceable()) continue;
                mc.player.getInventory().selectedSlot = slot;
                Direction face = d.getOpposite();
                Vec3d hitPos = Vec3d.ofCenter(n).add(Vec3d.of(face.getVector()).multiply(0.5));
                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                        new BlockHitResult(hitPos, face, n, false));
                mc.player.swingHand(Hand.MAIN_HAND);
                return;
            }
        }
    }

    public static class Fly extends Module {
        public Fly() { super("fly", "Полёт"); }
        @Override public void onTick() {
            var ab = mc.player.getAbilities();
            ab.allowFlying = true;
            ab.flying = true;
            ab.setFlySpeed(0.12f);
            mc.player.fallDistance = 0;
            MinecraftServer server = mc.getServer();
            if (server != null) {
                UUID id = mc.player.getUuid();
                server.execute(() -> {
                    var sp = server.getPlayerManager().getPlayer(id);
                    if (sp != null) sp.fallDistance = 0;
                });
            }
        }
        @Override protected void onDisable() {
            if (mc.player == null) return;
            if (!mc.player.isCreative() && !mc.player.isSpectator()) {
                mc.player.getAbilities().allowFlying = false;
                mc.player.getAbilities().flying = false;
            }
            mc.player.getAbilities().setFlySpeed(0.05f);
        }
    }

    public static class XRay extends Module {
        public XRay() { super("xray", "XRay"); }
        @Override protected void onEnable() { if (mc.worldRenderer != null) mc.worldRenderer.reload(); }
        @Override protected void onDisable() { if (mc.worldRenderer != null) mc.worldRenderer.reload(); }
    }

    public static class NightVision extends Module {
        public NightVision() { super("nightvision", "Ночное зрение"); }
        @Override public void onTick() {
            mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1000, 0, false, false, false));
        }
        @Override protected void onDisable() {
            if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }

    public static class Speed extends Module {
        public static double SPEED = 0.45;
        public Speed() { super("speed", "Скорость"); }
        @Override public void onTick() {
            float fw = (mc.options.forwardKey.isPressed() ? 1 : 0) - (mc.options.backKey.isPressed() ? 1 : 0);
            float st = (mc.options.leftKey.isPressed() ? 1 : 0) - (mc.options.rightKey.isPressed() ? 1 : 0);
            if (fw == 0 && st == 0) return;
            double yaw = Math.toRadians(mc.player.getYaw());
            double sin = Math.sin(yaw), cos = Math.cos(yaw);
            double x = -sin * fw + cos * st;
            double z = cos * fw + sin * st;
            double len = Math.sqrt(x * x + z * z);
            if (len == 0) return;
            mc.player.setVelocity(x / len * SPEED, mc.player.getVelocity().y, z / len * SPEED);
        }
    }

    /** Подсветка сквозь стены + показывает невидимых. Работает через миксин Entity. */
    public static class Esp extends Module {
        public Esp() { super("esp", "Показ игроков/мобов (ESP)"); }
    }
}
