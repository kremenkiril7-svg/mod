package com.redclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class RedClient implements ClientModInitializer {
    public static final List<Module> MODULES = new ArrayList<>();
    /** ПРАВЫЙ Shift — открыть/закрыть меню */
    public static final int MENU_KEY = GLFW.GLFW_KEY_RIGHT_SHIFT;
    private boolean menuWasDown;

    private static Path cfg() { return FabricLoader.getInstance().getConfigDir().resolve("redclient.properties"); }

    @Override
    public void onInitializeClient() {
        Modules.init();
        load();
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private void tick(MinecraftClient mc) {
        if (mc.getWindow() == null) return;
        long h = mc.getWindow().getHandle();

        boolean down = InputUtil.isKeyPressed(h, MENU_KEY);
        if (down && !menuWasDown && mc.player != null) {
            if (mc.currentScreen == null) {
                mc.setScreen(new MenuScreen());
            } else if (mc.currentScreen instanceof MenuScreen ms && !ms.isListening()) {
                mc.setScreen(null);
            }
        }
        menuWasDown = down;

        for (Module m : MODULES) {
            boolean d = m.key != -1 && InputUtil.isKeyPressed(h, m.key);
            if (d && !m.wasDown && mc.currentScreen == null && mc.player != null) m.toggle();
            m.wasDown = d;
        }

        if (mc.player != null && mc.world != null) {
            for (Module m : MODULES) if (m.enabled) m.onTick();
        }
    }

    public static void save() {
        Properties p = new Properties();
        for (Module m : MODULES) p.setProperty(m.id, Integer.toString(m.key));
        try (Writer w = Files.newBufferedWriter(cfg(), StandardCharsets.UTF_8)) {
            p.store(w, "Red Client keybinds");
        } catch (IOException ignored) {}
    }

    private static void load() {
        Path f = cfg();
        if (!Files.exists(f)) return;
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(f, StandardCharsets.UTF_8)) {
            p.load(r);
            for (Module m : MODULES) {
                String v = p.getProperty(m.id);
                if (v != null) m.key = Integer.parseInt(v.trim());
            }
        } catch (Exception ignored) {}
    }
}
