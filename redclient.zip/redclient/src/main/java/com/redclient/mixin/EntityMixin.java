package com.redclient.mixin;

import com.redclient.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
    private boolean redclient$espTarget() {
        Entity self = (Entity) (Object) this;
        return Modules.ESP.enabled
                && self.getWorld().isClient()
                && self instanceof LivingEntity
                && self != MinecraftClient.getInstance().player;
    }

    @Inject(method = "isGlowing", at = @At("HEAD"), cancellable = true)
    private void redclient$glow(CallbackInfoReturnable<Boolean> cir) {
        if (redclient$espTarget()) cir.setReturnValue(true);
    }

    @Inject(method = "isInvisibleTo", at = @At("HEAD"), cancellable = true)
    private void redclient$visible(PlayerEntity viewer, CallbackInfoReturnable<Boolean> cir) {
        if (redclient$espTarget()) cir.setReturnValue(false);
    }
}
