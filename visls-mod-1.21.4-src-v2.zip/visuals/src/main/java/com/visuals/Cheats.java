package com.visuals;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.registry.Registries;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class Cheats {
    public static boolean aim, fast, scaffold, fly, speed, xray, night, players;

    static boolean prevXray = false, prevNV = false;
    static int attackCd = 0, antiKick = 0, nvTimer = 0;
    static final Map<Block, Boolean> ORE_CACHE = new ConcurrentHashMap<>();
    static final Set<Integer> glowed = new HashSet<>();
    public static final Set<Integer> invisIds = new HashSet<>();

    public static boolean get(int i) {
        return switch (i) {
            case 0 -> aim; case 1 -> fast; case 2 -> scaffold; case 3 -> fly;
            case 4 -> speed; case 5 -> xray; case 6 -> night; default -> players;
        };
    }

    public static void toggle(int i) {
        switch (i) {
            case 0 -> aim = !aim;
            case 1 -> fast = !fast;
            case 2 -> scaffold = !scaffold;
            case 3 -> fly = !fly;
            case 4 -> speed = !speed;
            case 5 -> xray = !xray;
            case 6 -> night = !night;
            default -> players = !players;
        }
    }

    public static boolean isXrayBlock(BlockState s) {
        Block b = s.getBlock();
        Boolean r = ORE_CACHE.get(b);
        if (r == null) {
            String path = Registries.BLOCK.getId(b).getPath();
            r = path.endsWith("_ore") || path.equals("ancient_debris") || path.equals("spawner")
                    || path.equals("chest") || path.equals("trapped_chest") || path.equals("ender_chest");
            ORE_CACHE.put(b, r);
        }
        return r;
    }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null) return;
        combat(mc, p, w);
        scaffold(mc, p, w);
        flight(mc, p);
        speedTick(mc, p);
        worldTick(mc, p, w);
    }

    // ---------- наводка и атака ----------
    static double boxDist(Vec3d eye, Box b) {
        double dx = Math.max(Math.max(b.minX - eye.x, 0), eye.x - b.maxX);
        double dy = Math.max(Math.max(b.minY - eye.y, 0), eye.y - b.maxY);
        double dz = Math.max(Math.max(b.minZ - eye.z, 0), eye.z - b.maxZ);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    static LivingEntity nearest(ClientWorld w, ClientPlayerEntity p, double range) {
        LivingEntity best = null;
        double bd = range;
        Vec3d eye = p.getEyePos();
        for (Entity e : w.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive()) continue;
            if (e instanceof ArmorStandEntity || le.isSpectator()) continue;
            if (e instanceof TameableEntity t && t.isTamed()) continue;
            double d = boxDist(eye, le.getBoundingBox());
            if (d < bd && p.canSee(le)) { bd = d; best = le; }
        }
        return best;
    }

    static void combat(MinecraftClient mc, ClientPlayerEntity p, ClientWorld w) {
        if (attackCd > 0) attackCd--;
        if ((!aim && !fast) || mc.currentScreen != null) return;
        LivingEntity t = nearest(w, p, 6.0);
        if (t == null) return;

        Vec3d eye = p.getEyePos();
        double dx = t.getX() - eye.x;
        double dy = t.getY() + t.getHeight() * 0.5 - eye.y;
        double dz = t.getZ() - eye.z;
        float yaw = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
        float pitch = (float) (-Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI);
        float dyaw = MathHelper.wrapDegrees(yaw - p.getYaw());
        float dpitch = pitch - p.getPitch();
        float maxStep = fast ? 180f : 14f;
        p.setYaw(p.getYaw() + MathHelper.clamp(dyaw, -maxStep, maxStep));
        p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(dpitch, -maxStep, maxStep), -90f, 90f));

        if (boxDist(eye, t.getBoundingBox()) > 3.8) return;
        boolean ready = fast ? attackCd == 0
                : (p.getAttackCooldownProgress(0.5f) >= 0.95f && Math.abs(dyaw) < 20f);
        if (ready) {
            mc.interactionManager.attackEntity(p, t);
            p.swingHand(Hand.MAIN_HAND);
            attackCd = fast ? 2 : 0;
        }
    }

    // ---------- авто-блок под собой ----------
    static void scaffold(MinecraftClient mc, ClientPlayerEntity p, ClientWorld w) {
        if (!scaffold || mc.currentScreen != null) return;
        Hand hand = null;
        if (p.getMainHandStack().getItem() instanceof BlockItem) hand = Hand.MAIN_HAND;
        else if (p.getOffHandStack().getItem() instanceof BlockItem) hand = Hand.OFF_HAND;
        if (hand == null) return;

        BlockPos pos = BlockPos.ofFloored(p.getX(), p.getY() - 1.0, p.getZ());
        if (!w.getBlockState(pos).isReplaceable()) return;

        for (Direction d : Direction.values()) {
            if (d == Direction.UP) continue;
            BlockPos n = pos.offset(d);
            if (w.getBlockState(n).isReplaceable()) continue;
            Direction face = d.getOpposite();
            Vec3d hit = Vec3d.ofCenter(n).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
            mc.interactionManager.interactBlock(p, hand, new BlockHitResult(hit, face, n, false));
            p.swingHand(hand);
            return;
        }
    }

    // ---------- движение ----------
    static double[] moveDir(ClientPlayerEntity p, GameOptions o) {
        double yaw = Math.toRadians(p.getYaw());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw), lx = Math.cos(yaw), lz = Math.sin(yaw);
        double mx = 0, mz = 0;
        if (o.forwardKey.isPressed()) { mx += fx; mz += fz; }
        if (o.backKey.isPressed()) { mx -= fx; mz -= fz; }
        if (o.leftKey.isPressed()) { mx += lx; mz += lz; }
        if (o.rightKey.isPressed()) { mx -= lx; mz -= lz; }
        double len = Math.sqrt(mx * mx + mz * mz);
        if (len > 0) { mx /= len; mz /= len; }
        return new double[]{mx, mz};
    }

    static void flight(MinecraftClient mc, ClientPlayerEntity p) {
        if (!fly || mc.currentScreen != null) return;
        GameOptions o = mc.options;
        double[] d = moveDir(p, o);
        double my = 0;
        if (o.jumpKey.isPressed()) my = 0.5;
        if (o.sneakKey.isPressed()) my = -0.5;
        if (++antiKick >= 20) { antiKick = 0; if (my == 0) my = -0.06; }
        p.setVelocity(d[0] * 0.7, my, d[1] * 0.7);
        p.fallDistance = 0;
    }

    static void speedTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (!speed || fly || mc.currentScreen != null) return;
        double[] d = moveDir(p, mc.options);
        if (d[0] == 0 && d[1] == 0) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(d[0] * 0.5, v.y, d[1] * 0.5);
    }

    // ---------- рентген, ночное зрение, игроки ----------
    static void worldTick(MinecraftClient mc, ClientPlayerEntity p, ClientWorld w) {
        if (xray != prevXray) {
            prevXray = xray;
            mc.worldRenderer.reload();
        }
        boolean wantNV = xray || night;
        if (wantNV) {
            if (--nvTimer <= 0) {
                nvTimer = 100;
                if (!p.hasStatusEffect(StatusEffects.NIGHT_VISION))
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1000000, 0, false, false));
            }
        } else if (prevNV) {
            p.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
        prevNV = wantNV;

        if (players) {
            for (AbstractClientPlayerEntity o : w.getPlayers()) {
                if (o == p) continue;
                if (o.isInvisible()) { invisIds.add(o.getId()); o.setInvisible(false); }
                o.setGlowing(true);
                glowed.add(o.getId());
            }
        } else if (!glowed.isEmpty()) {
            for (Entity e : w.getEntities()) if (glowed.contains(e.getId())) e.setGlowing(false);
            glowed.clear();
            invisIds.clear();
        }
    }
}
