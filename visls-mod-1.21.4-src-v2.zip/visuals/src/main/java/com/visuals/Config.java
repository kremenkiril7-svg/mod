package com.visuals;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;
import java.util.Arrays;

public class Config {
    public static int mobSound = 0, playerSound = 0;   // 0 Нет, 1 Луч света, 2 Падение человека, 3 Святой дух
    public static int mobAnim = 0, playerAnim = 0;     // 0 Нет, 1 Красная молния, 2 Золотой столб, 3 Огненный взрыв
    public static int keyMenu = 344;                   // Right Shift
    public static final int[] keys = new int[8];       // клавиши функций, -1 = не назначена
    static { Arrays.fill(keys, -1); }
    static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("visuals_mod.json");

    static int i(JsonObject o, String k, int d) { return o.has(k) ? o.get(k).getAsInt() : d; }

    public static void load() {
        try {
            if (!Files.exists(PATH)) return;
            JsonObject o = JsonParser.parseString(Files.readString(PATH)).getAsJsonObject();
            mobSound = i(o, "mobSound", 0);
            playerSound = i(o, "playerSound", 0);
            mobAnim = i(o, "mobAnim", 0);
            playerAnim = i(o, "playerAnim", 0);
            keyMenu = i(o, "keyMenu", 344);
            if (o.has("keys")) {
                JsonArray a = o.getAsJsonArray("keys");
                for (int n = 0; n < keys.length && n < a.size(); n++) keys[n] = a.get(n).getAsInt();
            }
        } catch (Exception ignored) {}
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("mobSound", mobSound);
            o.addProperty("playerSound", playerSound);
            o.addProperty("mobAnim", mobAnim);
            o.addProperty("playerAnim", playerAnim);
            o.addProperty("keyMenu", keyMenu);
            JsonArray a = new JsonArray();
            for (int k : keys) a.add(k);
            o.add("keys", a);
            Files.writeString(PATH, o.toString());
        } catch (Exception ignored) {}
    }
}
