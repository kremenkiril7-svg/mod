package com.visuals;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.slf4j.LoggerFactory;
import java.util.*;

public class VisualsMod implements ClientModInitializer {
    static final boolean[] prevKey = new boolean[8];
    static boolean menuPrev = false;
    static final Set<Integer> done = new HashSet<>();

    @Override
    public void onInitializeClient() {
        LoggerFactory.getLogger("visuals").info("Visuals mod loaded!");
        Config.load();
        Sounds.register();

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("visuals").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.send(() -> mc.setScreen(new VisualsScreen()));
                    return Command.SINGLE_SUCCESS;
                })));

        // Показания игроков (HUD)
        HudRenderCallback.EVENT.register((ctx, tc) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (!Cheats.players || mc.player == null || mc.world == null || mc.options.hudHidden) return;
            int y = 30;
            ctx.drawTextWithShadow(mc.textRenderer, "Игроки рядом:", 4, y, 0xFFFF5555);
            y += 11;
            int n = 0;
            for (AbstractClientPlayerEntity o : mc.world.getPlayers()) {
                if (o == mc.player) continue;
                if (n++ >= 12) break;
                String s = o.getName().getString() + "  " + Math.round(o.getHealth() + o.getAbsorptionAmount()) + " хп  "
                        + Math.round(mc.player.distanceTo(o)) + " м" + (Cheats.invisIds.contains(o.getId()) ? "  [невидимка]" : "");
                ctx.drawTextWithShadow(mc.textRenderer, s, 4, y, 0xFFFFFFFF);
                y += 10;
            }
            if (n == 0) ctx.drawTextWithShadow(mc.textRenderer, "никого нет", 4, y, 0xFF999999);
        });

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            long handle = mc.getWindow().getHandle();

            // клавиша меню
            boolean md = Config.keyMenu >= 0 && InputUtil.isKeyPressed(handle, Config.keyMenu);
            if (md && !menuPrev && mc.currentScreen == null) mc.setScreen(new VisualsScreen());
            menuPrev = md;

            // клавиши функций
            for (int i = 0; i < prevKey.length; i++) {
                int k = Config.keys[i];
                boolean d = k >= 0 && InputUtil.isKeyPressed(handle, k);
                if (d && !prevKey[i] && mc.currentScreen == null) Cheats.toggle(i);
                prevKey[i] = d;
            }

            if (mc.player == null || mc.world == null) return;

            Cheats.tick(mc);
            Anims.tick(mc.world);

            // смерти мобов и игроков: анимация + звук
            Set<Integer> present = new HashSet<>();
            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof LivingEntity le) || e == mc.player || e instanceof ArmorStandEntity) continue;
                if (le.isDead()) {
                    present.add(e.getId());
                    if (done.add(e.getId())) {
                        Vec3d pos = le.getPos();
                        boolean pl = le instanceof PlayerEntity;
                        Anims.play(pl ? Config.playerAnim : Config.mobAnim, pos);
                        Sounds.play(pl ? Config.playerSound : Config.mobSound, mc.world, pos);
                    }
                }
            }
            done.retainAll(present);
        });
    }
}
