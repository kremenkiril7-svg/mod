package com.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class VisualsScreen extends Screen {
    static final int PW = 440, PH = 222, RED = 0xFFFF1A1A, GRAY = 0xFF444444, CW = 102;
    static final String[] NAMES = {"Наводка+атака", "Супер 1.8", "Авто-блок", "Полёт", "Скорость", "Рентген", "Ночное зрение", "Игроки (ESP)"};
    static final String[] SUBS = {"Плавно, по КД", "Мгновенно, спам", "Блок в руке", "Пробел / Shift", "Быстрый бег", "Только руды", "Видно в темноте", "Видит невидимок"};
    static final String[] ANIMS = {"Нет", "Красная молния", "Золотой столб", "Огненный взрыв"};
    int tab = 0; // 0 читы, 1 звуки, 2 анимации
    int px, py, waiting = -1, age = 0;

    public VisualsScreen() { super(Text.literal("Читы")); }

    @Override protected void init() { px = (width - PW) / 2; py = (height - PH) / 2; }
    @Override public boolean shouldPause() { return false; }
    @Override public void tick() { age++; }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float d) {
        c.fill(0, 0, width, height, 0x99000000);
    }

    static String keyName(int k) {
        if (k < 0) return "—";
        String s = InputUtil.fromKeyCode(k, 0).getLocalizedText().getString();
        return s.length() > 8 ? s.substring(0, 8) : s;
    }

    void card(DrawContext c, int x, int y, String name, boolean sel) {
        c.fill(x, y, x + CW, y + 30, sel ? 0xFF550000 : 0xFF151515);
        c.drawBorder(x, y, CW, 30, sel ? RED : GRAY);
        c.drawCenteredTextWithShadow(textRenderer, name, x + CW / 2, y + 11, 0xFFFFFFFF);
    }

    void tabBtn(DrawContext c, int x, String t, boolean sel) {
        c.fill(x, py + 30, x + 96, py + 46, sel ? 0xFF550000 : 0xFF1A1A1A);
        c.drawBorder(x, py + 30, 96, 16, sel ? RED : GRAY);
        c.drawCenteredTextWithShadow(textRenderer, t, x + 48, py + 34, 0xFFFFFFFF);
    }

    @Override
    public void render(DrawContext c, int mx, int my, float d) {
        renderBackground(c, mx, my, d);
        c.fill(px, py, px + PW, py + PH, 0xFF0A0A0A);
        c.drawBorder(px, py, PW, PH, RED);
        c.drawTextWithShadow(textRenderer, "Настройки", px + 10, py + 6, 0xFFFFFFFF);
        c.drawText(textRenderer, "Настрой игру под себя!", px + 10, py + 17, 0xFF999999, false);
        tabBtn(c, px + 10, "Читы", tab == 0);
        tabBtn(c, px + 110, "Звуки", tab == 1);
        tabBtn(c, px + 210, "Анимации", tab == 2);

        if (tab == 0) {
            for (int i = 0; i < 8; i++) {
                int x = px + 10 + (i / 4) * 215, y = py + 54 + (i % 4) * 36, w = 205;
                c.fill(x, y, x + w, y + 32, 0xFF121212);
                c.drawBorder(x, y, w, 32, GRAY);
                c.drawTextWithShadow(textRenderer, NAMES[i], x + 6, y + 6, 0xFFFFFFFF);
                c.drawText(textRenderer, SUBS[i], x + 6, y + 18, 0xFF888888, false);
                int kx = x + w - 92;
                boolean wait = waiting == i;
                c.fill(kx, y + 8, kx + 52, y + 24, wait ? 0xFF550000 : 0xFF1E1E1E);
                c.drawBorder(kx, y + 8, 52, 16, wait ? RED : GRAY);
                c.drawCenteredTextWithShadow(textRenderer, wait ? "..." : keyName(Config.keys[i]), kx + 26, y + 12, 0xFFFFFFFF);
                boolean on = Cheats.get(i);
                int sx = x + w - 34;
                c.fill(sx, y + 9, sx + 28, y + 23, on ? RED : 0xFF333333);
                int kn = on ? sx + 16 : sx + 2;
                c.fill(kn, y + 11, kn + 10, y + 21, 0xFFFFFFFF);
            }
            c.drawTextWithShadow(textRenderer, "Клавиша меню:", px + 10, py + 205, 0xFFFFFFFF);
            boolean wm = waiting == 100;
            c.fill(px + 100, py + 201, px + 170, py + 215, wm ? 0xFF550000 : 0xFF1E1E1E);
            c.drawBorder(px + 100, py + 201, 70, 14, wm ? RED : GRAY);
            c.drawCenteredTextWithShadow(textRenderer, wm ? "..." : keyName(Config.keyMenu), px + 135, py + 204, 0xFFFFFFFF);
            c.drawText(textRenderer, "Нажми кнопку клавиши и жми нужную (Esc — убрать)", px + 180, py + 205, 0xFF777777, false);
        } else if (tab == 1) {
            c.drawTextWithShadow(textRenderer, "Звук смерти моба", px + 10, py + 54, 0xFFFFFFFF);
            for (int i = 0; i < 4; i++) card(c, px + 10 + i * 108, py + 66, Sounds.NAMES[i], Config.mobSound == i);
            c.drawTextWithShadow(textRenderer, "Звук смерти игрока", px + 10, py + 110, 0xFFFFFFFF);
            for (int i = 0; i < 4; i++) card(c, px + 10 + i * 108, py + 122, Sounds.NAMES[i], Config.playerSound == i);
            c.drawText(textRenderer, "Клик по карточке — прослушать", px + 10, py + 170, 0xFF777777, false);
        } else {
            c.drawTextWithShadow(textRenderer, "Анимация смерти моба", px + 10, py + 54, 0xFFFFFFFF);
            for (int i = 0; i < 4; i++) card(c, px + 10 + i * 108, py + 66, ANIMS[i], Config.mobAnim == i);
            c.drawTextWithShadow(textRenderer, "Анимация смерти игрока", px + 10, py + 110, 0xFFFFFFFF);
            for (int i = 0; i < 4; i++) card(c, px + 10 + i * 108, py + 122, ANIMS[i], Config.playerAnim == i);
            c.drawText(textRenderer, "Клик по карточке — посмотреть перед собой", px + 10, py + 170, 0xFF777777, false);
        }
    }

    boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (waiting != -1) {
            int val = keyCode == GLFW.GLFW_KEY_ESCAPE ? -1 : keyCode;
            if (waiting == 100) { if (val != -1) Config.keyMenu = val; }
            else Config.keys[waiting] = val;
            waiting = -1;
            Config.save();
            return true;
        }
        if (keyCode == Config.keyMenu && age > 6) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int b) {
        waiting = -1;
        if (in(mx, my, px + 10, py + 30, 96, 16)) { tab = 0; return true; }
        if (in(mx, my, px + 110, py + 30, 96, 16)) { tab = 1; return true; }
        if (in(mx, my, px + 210, py + 30, 96, 16)) { tab = 2; return true; }
        if (tab == 0) {
            if (in(mx, my, px + 100, py + 201, 70, 14)) { waiting = 100; return true; }
            for (int i = 0; i < 8; i++) {
                int x = px + 10 + (i / 4) * 215, y = py + 54 + (i % 4) * 36, w = 205;
                if (in(mx, my, x + w - 92, y + 8, 52, 16)) { waiting = i; return true; }
                if (in(mx, my, x, y, w, 32)) { Cheats.toggle(i); return true; }
            }
        } else if (tab == 1) {
            for (int i = 0; i < 4; i++) {
                if (in(mx, my, px + 10 + i * 108, py + 66, CW, 30)) { Config.mobSound = i; Config.save(); previewSound(i); return true; }
                if (in(mx, my, px + 10 + i * 108, py + 122, CW, 30)) { Config.playerSound = i; Config.save(); previewSound(i); return true; }
            }
        } else {
            for (int i = 0; i < 4; i++) {
                if (in(mx, my, px + 10 + i * 108, py + 66, CW, 30)) { Config.mobAnim = i; Config.save(); previewAnim(i); return true; }
                if (in(mx, my, px + 10 + i * 108, py + 122, CW, 30)) { Config.playerAnim = i; Config.save(); previewAnim(i); return true; }
            }
        }
        return super.mouseClicked(mx, my, b);
    }

    void previewSound(int i) {
        if (client.world != null && client.player != null) Sounds.play(i, client.world, client.player.getPos());
    }

    void previewAnim(int i) {
        if (client.player == null) return;
        Vec3d look = client.player.getRotationVec(1f);
        Anims.play(i, client.player.getPos().add(look.x * 5, 0, look.z * 5));
    }
}
