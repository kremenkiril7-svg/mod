package com.visuals;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;

public class Config {
    public static boolean jumpAnim = true;
    public static int killEffect = 0; // 0 Луч, 1 Бог забирает, 2 Поданы
    public static int handPose = 0;   // 0 Обычная, 1 Низко, 2 Высоко, 3 Наклон
    public static int mobSound = 0;   // 0 Нет, 1 Луч света, 2 Падение человека, 3 Святой дух
    public static int playerSound = 0;
    static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("visuals_mod.json");

    public static void load() {
        try {
            if (!Files.exists(PATH)) return;
            JsonObject o = JsonParser.parseString(Files.readString(PATH)).getAsJsonObject();
            jumpAnim = o.get("jumpAnim").getAsBoolean();
            killEffect = o.get("killEffect").getAsInt();
            handPose = o.get("handPose").getAsInt();
            mobSound = o.get("mobSound").getAsInt();
            playerSound = o.get("playerSound").getAsInt();
        } catch (Exception ignored) {}
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("jumpAnim", jumpAnim);
            o.addProperty("killEffect", killEffect);
            o.addProperty("handPose", handPose);
            o.addProperty("mobSound", mobSound);
            o.addProperty("playerSound", playerSound);
            Files.writeString(PATH, o.toString());
        } catch (Exception ignored) {}
    }
}
