package com.visuals;

import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.*;
import net.minecraft.util.math.Vec3d;
import java.util.Random;

public class Effects {
    static final Random R = new Random();
    static final DustParticleEffect RED = new DustParticleEffect(0xFF0D0D, 1.6f);

    public static void kill(int type, ClientWorld w, Vec3d p) {
        switch (type) {
            case 0 -> beam(w, p);
            case 1 -> angel(w, p);
            default -> skulls(w, p);
        }
    }

    static void beam(ClientWorld w, Vec3d p) {
        for (double y = 0; y < 14; y += 0.25) {
            w.addParticle(ParticleTypes.END_ROD, p.x, p.y + y, p.z, 0, 0.05, 0);
            w.addParticle(RED, p.x, p.y + y, p.z, 0, 0, 0);
        }
        for (int r = 1; r <= 3; r++)
            for (int i = 0; i < 40; i++) {
                double a = i / 40.0 * Math.PI * 2;
                w.addParticle(RED, p.x + Math.cos(a) * r * 0.6, p.y + 0.1, p.z + Math.sin(a) * r * 0.6, 0, 0.02, 0);
            }
    }

    static void angel(ClientWorld w, Vec3d p) {
        for (int i = 0; i < 24; i++) {
            double t = i / 23.0;
            for (int s = -1; s <= 1; s += 2) {
                double x = p.x + s * (0.3 + t * 1.4);
                double y = p.y + 1.2 + t * 0.9 - t * t * 1.0;
                w.addParticle(ParticleTypes.END_ROD, x, y, p.z, 0, 0.08, 0);
                w.addParticle(RED, x, y - 0.2, p.z, 0, 0.05, 0);
            }
        }
        for (int i = 0; i < 24; i++) {
            double a = i / 24.0 * Math.PI * 2;
            w.addParticle(ParticleTypes.END_ROD, p.x + Math.cos(a) * 0.4, p.y + 2.6, p.z + Math.sin(a) * 0.4, 0, 0.06, 0);
        }
        for (int i = 0; i < 20; i++)
            w.addParticle(ParticleTypes.SOUL_FIRE_FLAME, p.x, p.y + 0.2, p.z, (R.nextDouble() - .5) * .1, 0.2, (R.nextDouble() - .5) * .1);
    }

    static void skulls(ClientWorld w, Vec3d p) {
        for (int i = 0; i < 80; i++)
            w.addParticle(RED, p.x, p.y + 1, p.z, (R.nextDouble() - .5) * .6, R.nextDouble() * .5, (R.nextDouble() - .5) * .6);
        for (int i = 0; i < 15; i++)
            w.addParticle(ParticleTypes.SOUL, p.x, p.y + 1, p.z, (R.nextDouble() - .5) * .2, 0.15, (R.nextDouble() - .5) * .2);
        w.addParticle(ParticleTypes.EXPLOSION, p.x, p.y + 1, p.z, 0, 0, 0);
    }

    public static void jump(ClientWorld w, PlayerEntity pl) {
        for (int i = 0; i < 24; i++) {
            double a = i / 24.0 * Math.PI * 2;
            w.addParticle(ParticleTypes.CLOUD, pl.getX() + Math.cos(a) * .5, pl.getY() + .05, pl.getZ() + Math.sin(a) * .5,
                    Math.cos(a) * .12, 0.02, Math.sin(a) * .12);
        }
        w.addParticle(RED, pl.getX(), pl.getY() + .1, pl.getZ(), 0, 0, 0);
    }
}
