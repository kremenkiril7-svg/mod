package com.visuals;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;
import org.slf4j.LoggerFactory;

public class VisualsMod implements ClientModInitializer {
    static KeyBinding menuKey;
    static LivingEntity target;
    static int targetTicks;
    static boolean wasOnGround = true;
    static boolean rshiftWasDown = false;

    @Override
    public void onInitializeClient() {
        LoggerFactory.getLogger("visuals").info("Visuals mod loaded!");
        Config.load();
        Sounds.register();
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "Меню визуалов", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "Visuals"));

        // запасной вариант: команда /visuals
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("visuals").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.send(() -> mc.setScreen(new VisualsScreen()));
                    return Command.SINGLE_SUCCESS;
                })));

        AttackEntityCallback.EVENT.register((p, w, hand, e, hit) -> {
            if (w.isClient && e instanceof LivingEntity le) { target = le; targetTicks = 0; }
            return ActionResult.PASS;
        });

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            // Right Shift читаем напрямую (работает даже если привязка клавиши сбилась)
            boolean down = InputUtil.isKeyPressed(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT);
            boolean pressed = (down && !rshiftWasDown) | menuKey.wasPressed();
            rshiftWasDown = down;
            if (pressed && mc.currentScreen == null) mc.setScreen(new VisualsScreen());

            if (mc.player == null || mc.world == null) return;

            if (target != null) {
                if (!target.isAlive()) {
                    var pos = target.getPos();
                    Effects.kill(Config.killEffect, mc.world, pos);
                    Sounds.play(target instanceof PlayerEntity ? Config.playerSound : Config.mobSound, mc.world, pos);
                    target = null;
                } else if (++targetTicks > 200) target = null;
            }

            boolean ground = mc.player.isOnGround();
            if (Config.jumpAnim && wasOnGround && !ground && mc.player.getVelocity().y > 0.2)
                Effects.jump(mc.world, mc.player);
            wasOnGround = ground;
        });
    }
}
