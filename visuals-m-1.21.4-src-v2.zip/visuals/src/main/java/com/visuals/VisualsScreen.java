package com.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class VisualsScreen extends Screen {
    static final int PW = 320, PH = 210, RED = 0xFFFF1A1A, GRAY = 0xFF444444;
    static final String[] KILL = {"Луч", "Бог забирает", "Поданы"};
    static final int[] KILL_C = {0xCC0000, 0xFFFFFF, 0x880000};
    static final String[] POSE = {"Обычная", "Низко", "Высоко", "Наклон"};
    int tab = 0; // 0 визуалы, 1 звуки
    int px, py;

    public VisualsScreen() { super(Text.literal("Настройки")); }

    @Override protected void init() { px = (width - PW) / 2; py = (height - PH) / 2; }
    @Override public boolean shouldPause() { return false; }

    void card(DrawContext c, int x, int y, int w, String name, int col, boolean sel) {
        c.fill(x, y, x + w, y + 36, 0xFF111111);
        c.fill(x + 2, y + 2, x + w - 2, y + 24, 0x66000000 | col);
        c.drawBorder(x, y, w, 36, sel ? RED : GRAY);
        c.drawCenteredTextWithShadow(textRenderer, name, x + w / 2, y + 26, 0xFFFFFFFF);
    }

    void tabBtn(DrawContext c, int x, String t, boolean sel) {
        c.fill(x, py + 30, x + 100, py + 46, sel ? 0xFF550000 : 0xFF1A1A1A);
        c.drawBorder(x, py + 30, 100, 16, sel ? RED : GRAY);
        c.drawCenteredTextWithShadow(textRenderer, t, x + 50, py + 34, 0xFFFFFFFF);
    }

    @Override
    public void render(DrawContext c, int mx, int my, float d) {
        renderBackground(c, mx, my, d);
        c.fill(px, py, px + PW, py + PH, 0xEE0A0A0A);
        c.drawBorder(px, py, PW, PH, RED);
        c.drawTextWithShadow(textRenderer, "Настройки", px + 10, py + 6, 0xFFFFFFFF);
        c.drawText(textRenderer, "Настрой игру под себя!", px + 10, py + 17, 0xFF999999, false);
        tabBtn(c, px + 10, "Визуалы", tab == 0);
        tabBtn(c, px + 114, "Звуки", tab == 1);

        if (tab == 0) {
            c.drawTextWithShadow(textRenderer, "Анимация прыжка", px + 10, py + 56, 0xFFFFFFFF);
            c.fill(px + PW - 50, py + 54, px + PW - 14, py + 68, Config.jumpAnim ? RED : 0xFF333333);
            int kx = Config.jumpAnim ? px + PW - 28 : px + PW - 48;
            c.fill(kx, py + 56, kx + 12, py + 66, 0xFFFFFFFF);

            c.drawTextWithShadow(textRenderer, "Убийство (эффект)", px + 10, py + 78, 0xFFFFFFFF);
            for (int i = 0; i < 3; i++) card(c, px + 10 + i * 104, py + 90, 98, KILL[i], KILL_C[i], Config.killEffect == i);

            c.drawTextWithShadow(textRenderer, "Положение руки с мечом", px + 10, py + 134, 0xFFFFFFFF);
            for (int i = 0; i < 4; i++) card(c, px + 10 + i * 77, py + 146, 72, POSE[i], 0xFFAA00, Config.handPose == i);
        } else {
            c.drawTextWithShadow(textRenderer, "Звук смерти моба", px + 10, py + 54, 0xFFFFFFFF);
            for (int i = 0; i < 4; i++) card(c, px + 10 + i * 77, py + 66, 72, Sounds.NAMES[i], 0xFF3333, Config.mobSound == i);
            c.drawTextWithShadow(textRenderer, "Звук смерти игрока", px + 10, py + 110, 0xFFFFFFFF);
            for (int i = 0; i < 4; i++) card(c, px + 10 + i * 77, py + 122, 72, Sounds.NAMES[i], 0xFF3333, Config.playerSound == i);
            c.drawText(textRenderer, "Клик по карточке — прослушать", px + 10, py + 170, 0xFF777777, false);
        }
        super.render(c, mx, my, d);
    }

    boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    @Override
    public boolean mouseClicked(double mx, double my, int b) {
        if (in(mx, my, px + 10, py + 30, 100, 16)) { tab = 0; return true; }
        if (in(mx, my, px + 114, py + 30, 100, 16)) { tab = 1; return true; }
        if (tab == 0) {
            if (in(mx, my, px + PW - 50, py + 54, 36, 14)) { Config.jumpAnim = !Config.jumpAnim; Config.save(); return true; }
            for (int i = 0; i < 3; i++)
                if (in(mx, my, px + 10 + i * 104, py + 90, 98, 36)) {
                    Config.killEffect = i; Config.save();
                    if (client.world != null && client.player != null)
                        Effects.kill(i, client.world, client.player.getPos().add(client.player.getRotationVec(1f).multiply(3, 0, 3)));
                    return true;
                }
            for (int i = 0; i < 4; i++)
                if (in(mx, my, px + 10 + i * 77, py + 146, 72, 36)) { Config.handPose = i; Config.save(); return true; }
        } else {
            for (int i = 0; i < 4; i++) {
                if (in(mx, my, px + 10 + i * 77, py + 66, 72, 36)) { Config.mobSound = i; Config.save(); preview(i); return true; }
                if (in(mx, my, px + 10 + i * 77, py + 122, 72, 36)) { Config.playerSound = i; Config.save(); preview(i); return true; }
            }
        }
        return super.mouseClicked(mx, my, b);
    }

    void preview(int i) {
        if (client.world != null && client.player != null) Sounds.play(i, client.world, client.player.getPos());
    }
}
