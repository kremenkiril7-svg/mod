package com.visuals;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;

public class Config {
    public static int mobSound = 0;    // 0 Нет, 1 Луч света, 2 Падение человека, 3 Святой дух
    public static int playerSound = 0;
    static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("visuals_mod.json");

    static int i(JsonObject o, String k, int d) { return o.has(k) ? o.get(k).getAsInt() : d; }

    public static void load() {
        try {
            if (!Files.exists(PATH)) return;
            JsonObject o = JsonParser.parseString(Files.readString(PATH)).getAsJsonObject();
            mobSound = i(o, "mobSound", 0);
            playerSound = i(o, "playerSound", 0);
        } catch (Exception ignored) {}
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("mobSound", mobSound);
            o.addProperty("playerSound", playerSound);
            Files.writeString(PATH, o.toString());
        } catch (Exception ignored) {}
    }
}
