package com.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class VisualsScreen extends Screen {
    static final int PW = 320, PH = 210, RED = 0xFFFF1A1A, GRAY = 0xFF444444;
    static final String[] NAMES = {"Наводка + авто-атака", "Супер-наводка (1.8)", "Авто-блок под собой", "Полёт", "Рентген (X-Ray)"};
    static final String[] SUBS = {"Плавно наводится и бьёт по КД", "Мгновенно, спам-атака", "Держи блок в руке", "Прыжок вверх, красться вниз", "Видны только руды"};
    int tab = 0; // 0 читы, 1 звуки
    int px, py;

    public VisualsScreen() { super(Text.literal("Читы")); }

    @Override protected void init() { px = (width - PW) / 2; py = (height - PH) / 2; }
    @Override public boolean shouldPause() { return false; }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float d) {
        c.fill(0, 0, width, height, 0x99000000);
    }

    static boolean get(int i) {
        return switch (i) { case 0 -> Cheats.aim; case 1 -> Cheats.fast; case 2 -> Cheats.scaffold; case 3 -> Cheats.fly; default -> Cheats.xray; };
    }

    static void toggle(int i) {
        switch (i) {
            case 0 -> Cheats.aim = !Cheats.aim;
            case 1 -> Cheats.fast = !Cheats.fast;
            case 2 -> Cheats.scaffold = !Cheats.scaffold;
            case 3 -> Cheats.fly = !Cheats.fly;
            default -> Cheats.xray = !Cheats.xray;
        }
    }

    void card(DrawContext c, int x, int y, int w, String name, boolean sel) {
        c.fill(x, y, x + w, y + 30, sel ? 0xFF550000 : 0xFF151515);
        c.drawBorder(x, y, w, 30, sel ? RED : GRAY);
        c.drawCenteredTextWithShadow(textRenderer, name, x + w / 2, y + 11, 0xFFFFFFFF);
    }

    void tabBtn(DrawContext c, int x, String t, boolean sel) {
        c.fill(x, py + 30, x + 96, py + 46, sel ? 0xFF550000 : 0xFF1A1A1A);
        c.drawBorder(x, py + 30, 96, 16, sel ? RED : GRAY);
        c.drawCenteredTextWithShadow(textRenderer, t, x + 48, py + 34, 0xFFFFFFFF);
    }

    @Override
    public void render(DrawContext c, int mx, int my, float d) {
        renderBackground(c, mx, my, d);
        c.fill(px, py, px + PW, py + PH, 0xFF0A0A0A);
        c.drawBorder(px, py, PW, PH, RED);
        c.drawTextWithShadow(textRenderer, "Настройки", px + 10, py + 6, 0xFFFFFFFF);
        c.drawText(textRenderer, "Настрой игру под себя!", px + 10, py + 17, 0xFF999999, false);
        tabBtn(c, px + 10, "Читы", tab == 0);
        tabBtn(c, px + 110, "Звуки", tab == 1);

        if (tab == 0) {
            for (int i = 0; i < 5; i++) {
                int y = py + 54 + i * 29;
                c.fill(px + 10, y, px + PW - 10, y + 26, 0xFF121212);
                c.drawBorder(px + 10, y, PW - 20, 26, GRAY);
                c.drawTextWithShadow(textRenderer, NAMES[i], px + 18, y + 4, 0xFFFFFFFF);
                c.drawText(textRenderer, SUBS[i], px + 18, y + 15, 0xFF888888, false);
                boolean on = get(i);
                c.fill(px + PW - 56, y + 6, px + PW - 20, y + 20, on ? RED : 0xFF333333);
                int kx = on ? px + PW - 34 : px + PW - 54;
                c.fill(kx, y + 8, kx + 12, y + 18, 0xFFFFFFFF);
            }
        } else {
            c.drawTextWithShadow(textRenderer, "Звук смерти моба", px + 10, py + 54, 0xFFFFFFFF);
            for (int i = 0; i < 4; i++) card(c, px + 10 + i * 77, py + 66, 72, Sounds.NAMES[i], Config.mobSound == i);
            c.drawTextWithShadow(textRenderer, "Звук смерти игрока", px + 10, py + 110, 0xFFFFFFFF);
            for (int i = 0; i < 4; i++) card(c, px + 10 + i * 77, py + 122, 72, Sounds.NAMES[i], Config.playerSound == i);
            c.drawText(textRenderer, "Клик по карточке — прослушать", px + 10, py + 170, 0xFF777777, false);
        }
    }

    boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    @Override
    public boolean mouseClicked(double mx, double my, int b) {
        if (in(mx, my, px + 10, py + 30, 96, 16)) { tab = 0; return true; }
        if (in(mx, my, px + 110, py + 30, 96, 16)) { tab = 1; return true; }
        if (tab == 0) {
            for (int i = 0; i < 5; i++)
                if (in(mx, my, px + 10, py + 54 + i * 29, PW - 20, 26)) { toggle(i); return true; }
        } else {
            for (int i = 0; i < 4; i++) {
                if (in(mx, my, px + 10 + i * 77, py + 66, 72, 30)) { Config.mobSound = i; Config.save(); preview(i); return true; }
                if (in(mx, my, px + 10 + i * 77, py + 122, 72, 30)) { Config.playerSound = i; Config.save(); preview(i); return true; }
            }
        }
        return super.mouseClicked(mx, my, b);
    }

    void preview(int i) {
        if (client.world != null && client.player != null) Sounds.play(i, client.world, client.player.getPos());
    }
}
