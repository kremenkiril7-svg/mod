package com.visuals;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;

public class Config {
    public static boolean jumpAnim = true;
    public static int killEffect = 0; // 0 Луч, 1 Бог забирает, 2 Утопление
    public static int handPose = 0;
    public static int mobSound = 0;
    public static int playerSound = 0;
    public static int wings = 0;      // 0 нет, 1 ангела, 2 демона, 3 огненные
    public static int hat = 0;        // 0 нет, 1 нимб, 2 корона, 3 ведьмы
    static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("visuals_mod.json");

    static int i(JsonObject o, String k, int d) { return o.has(k) ? o.get(k).getAsInt() : d; }

    public static void load() {
        try {
            if (!Files.exists(PATH)) return;
            JsonObject o = JsonParser.parseString(Files.readString(PATH)).getAsJsonObject();
            jumpAnim = !o.has("jumpAnim") || o.get("jumpAnim").getAsBoolean();
            killEffect = i(o, "killEffect", 0);
            handPose = i(o, "handPose", 0);
            mobSound = i(o, "mobSound", 0);
            playerSound = i(o, "playerSound", 0);
            wings = i(o, "wings", 0);
            hat = i(o, "hat", 0);
        } catch (Exception ignored) {}
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("jumpAnim", jumpAnim);
            o.addProperty("killEffect", killEffect);
            o.addProperty("handPose", handPose);
            o.addProperty("mobSound", mobSound);
            o.addProperty("playerSound", playerSound);
            o.addProperty("wings", wings);
            o.addProperty("hat", hat);
            Files.writeString(PATH, o.toString());
        } catch (Exception ignored) {}
    }
}
