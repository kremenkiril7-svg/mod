package com.visuals;

import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.*;
import net.minecraft.util.math.Vec3d;
import java.util.*;

public class Effects {
    static final Random R = new Random();
    interface Anim { void run(ClientWorld w, int t); }
    static class Task {
        int t = 0; final int dur; final Anim a;
        Task(int dur, Anim a) { this.dur = dur; this.a = a; }
    }
    static final List<Task> TASKS = new ArrayList<>();

    static DustParticleEffect dust(int rgb, float s) { return new DustParticleEffect(rgb, s); }

    public static void tick(ClientWorld w) {
        Iterator<Task> it = TASKS.iterator();
        while (it.hasNext()) {
            Task k = it.next();
            k.a.run(w, k.t);
            if (++k.t >= k.dur) it.remove();
        }
    }

    public static void kill(int type, Vec3d p) {
        switch (type) {
            case 0 -> beam(p);
            case 1 -> hand(p);
            default -> water(p);
        }
    }

    // 1) Луч с неба / из солнца
    static void beam(Vec3d p) {
        TASKS.add(new Task(50, (w, t) -> {
            double H = 32;
            DustParticleEffect gold = dust(0xFFD84A, 1.3f);
            for (double y = 0; y < H; y += 0.7) {
                w.addParticle(ParticleTypes.END_ROD, p.x, p.y + y, p.z, 0, 0, 0);
                double a = R.nextDouble() * Math.PI * 2;
                w.addParticle(gold, p.x + Math.cos(a) * 0.35, p.y + y, p.z + Math.sin(a) * 0.35, 0, 0, 0);
            }
            DustParticleEffect sun = dust(0xFFE070, 3.5f);
            for (int i = 0; i < 8; i++) {
                double a = R.nextDouble() * Math.PI * 2, b = R.nextDouble() * Math.PI, r = 2.2 * R.nextDouble();
                w.addParticle(sun, p.x + Math.cos(a) * Math.sin(b) * r, p.y + H + Math.cos(b) * r,
                        p.z + Math.sin(a) * Math.sin(b) * r, 0, 0, 0);
            }
            double rr = 0.3 + t * 0.12;
            for (int i = 0; i < 24; i++) {
                double a = i / 24.0 * Math.PI * 2;
                w.addParticle(ParticleTypes.END_ROD, p.x + Math.cos(a) * rr, p.y + 0.1, p.z + Math.sin(a) * rr, 0, 0.01, 0);
            }
            if (t < 25)
                w.addParticle(ParticleTypes.END_ROD, p.x + (R.nextDouble() - .5) * .6, p.y + R.nextDouble() * 2, p.z + (R.nextDouble() - .5) * .6, 0, 0.1, 0);
        }));
    }

    // 2) Бог забирает: рука с неба хватает и уносит
    static void hand(Vec3d p) {
        TASKS.add(new Task(75, (w, t) -> {
            double cy;
            if (t < 25) { double e = t / 25.0; e = e * e * (3 - 2 * e); cy = p.y + 14 - 11.8 * e; }
            else if (t < 35) cy = p.y + 2.2;
            else cy = p.y + 2.2 + (t - 35) * 0.9;
            double curl = t < 25 ? 0.8 : (t < 35 ? 0.8 - 0.45 * ((t - 25) / 10.0) : 0.35);
            DustParticleEffect d = dust(0xFFF2B0, 1.0f);
            for (double y = 0.2; y < 14; y += 0.5)
                for (int j = 0; j < 3; j++) {
                    double a = R.nextDouble() * Math.PI * 2;
                    w.addParticle(d, p.x + Math.cos(a) * 0.22, cy + y, p.z + Math.sin(a) * 0.22, 0, 0, 0);
                }
            for (int i = 0; i < 14; i++) {
                double a = R.nextDouble() * Math.PI * 2, r = Math.sqrt(R.nextDouble()) * 0.8;
                w.addParticle(d, p.x + Math.cos(a) * r, cy, p.z + Math.sin(a) * r, 0, 0, 0);
            }
            for (int f = 0; f < 5; f++) {
                double ang = Math.toRadians(-70 + 35 * f);
                double fx = p.x + Math.sin(ang) * curl, fz = p.z + Math.cos(ang) * curl;
                for (double y = 0; y < 0.9; y += 0.2) w.addParticle(d, fx, cy - y, fz, 0, 0, 0);
            }
            w.addParticle(ParticleTypes.END_ROD, p.x, cy + 0.3, p.z, 0, 0, 0);
            if (t >= 25) {
                w.addParticle(ParticleTypes.SOUL, p.x + (R.nextDouble() - .5) * .5, cy - 0.5 + (R.nextDouble() - .5) * .5, p.z + (R.nextDouble() - .5) * .5, 0, 0.05, 0);
                w.addParticle(ParticleTypes.CLOUD, p.x + (R.nextDouble() - .5) * .5, cy - 0.4, p.z + (R.nextDouble() - .5) * .5, 0, 0.02, 0);
            }
        }));
    }

    // 3) Утопление: водяной столб накрывает и уходит
    static void water(Vec3d p) {
        TASKS.add(new Task(70, (w, t) -> {
            double h = 2.8 * Math.sin(Math.PI * t / 70.0);
            DustParticleEffect d = dust(0x2F7BFF, 1.5f);
            for (int i = 0; i < 40; i++) {
                double a = R.nextDouble() * Math.PI * 2;
                double r = R.nextBoolean() ? 0.9 : 0.9 * Math.sqrt(R.nextDouble());
                w.addParticle(d, p.x + Math.cos(a) * r, p.y + R.nextDouble() * h, p.z + Math.sin(a) * r, 0, 0, 0);
            }
            for (int i = 0; i < 6; i++)
                w.addParticle(ParticleTypes.BUBBLE, p.x + (R.nextDouble() - .5) * 1.4, p.y + R.nextDouble() * h, p.z + (R.nextDouble() - .5) * 1.4, 0, 0.12, 0);
            if (t < 8)
                for (int i = 0; i < 20; i++) {
                    double a = i / 20.0 * Math.PI * 2;
                    w.addParticle(ParticleTypes.SPLASH, p.x + Math.cos(a) * 1.0, p.y + 0.1, p.z + Math.sin(a) * 1.0, 0, 0.2, 0);
                }
            if (t > 55)
                for (int i = 0; i < 6; i++)
                    w.addParticle(ParticleTypes.FALLING_WATER, p.x + (R.nextDouble() - .5) * 1.6, p.y + 2.5, p.z + (R.nextDouble() - .5) * 1.6, 0, 0, 0);
        }));
    }

    // Анимация прыжка
    public static void jump(PlayerEntity pl) {
        double x = pl.getX(), y = pl.getY(), z = pl.getZ();
        TASKS.add(new Task(14, (w, t) -> {
            double r = 0.3 + t * 0.14;
            for (int i = 0; i < 28; i++) {
                double a = i / 28.0 * Math.PI * 2;
                w.addParticle(ParticleTypes.CLOUD, x + Math.cos(a) * r, y + 0.05, z + Math.sin(a) * r, Math.cos(a) * 0.04, 0.01, Math.sin(a) * 0.04);
                if (i % 2 == 0)
                    w.addParticle(dust(0xFF2020, 1.2f), x + Math.cos(a) * r, y + 0.1, z + Math.sin(a) * r, 0, 0, 0);
            }
            double a = t * 0.9;
            w.addParticle(ParticleTypes.END_ROD, x + Math.cos(a) * 0.6, y + t * 0.12, z + Math.sin(a) * 0.6, 0, 0.02, 0);
            w.addParticle(ParticleTypes.END_ROD, x + Math.cos(a + Math.PI) * 0.6, y + t * 0.12, z + Math.sin(a + Math.PI) * 0.6, 0, 0.02, 0);
        }));
    }

    // Скины: крылья (из частиц)
    public static void wings(ClientWorld w, PlayerEntity pl, int type) {
        double yaw = Math.toRadians(pl.bodyYaw);
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);
        double rx = Math.cos(yaw), rz = Math.sin(yaw);
        double bx = pl.getX() - fx * 0.3, bz = pl.getZ() - fz * 0.3;
        double by = pl.getY() + (pl.isSneaking() ? 1.0 : 1.2);
        for (int side = -1; side <= 1; side += 2)
            for (int i = 0; i <= 9; i++) {
                double t = i / 9.0;
                double out = 0.15 + t * 1.4;
                double up = 0.2 + Math.sin(t * Math.PI * 0.6) * 0.8;
                double px = bx + rx * side * out - fx * t * 0.3, pz = bz + rz * side * out - fz * t * 0.3;
                spawnWing(w, type, px, by + up, pz);
                if (i == 2 || i == 4 || i == 6 || i == 8) {
                    double L = 0.9 * (1 - t * 0.5);
                    for (double y = 0.25; y < L; y += 0.25) spawnWing(w, type, px, by + up - y, pz);
                }
            }
    }

    static void spawnWing(ClientWorld w, int type, double x, double y, double z) {
        switch (type) {
            case 1 -> w.addParticle(ParticleTypes.END_ROD, x, y, z, 0, 0, 0);
            case 2 -> w.addParticle(dust(0xCC0000, 1.0f), x, y, z, 0, 0, 0);
            default -> w.addParticle(ParticleTypes.FLAME, x, y, z, 0, 0, 0);
        }
    }

    // Скины: шапка (из частиц)
    public static void hat(ClientWorld w, PlayerEntity pl, int type) {
        double top = pl.getY() + pl.getHeight();
        double x = pl.getX(), z = pl.getZ();
        switch (type) {
            case 1 -> ring(w, ParticleTypes.END_ROD, x, top + 0.25, z, 0.35, 16);
            case 2 -> {
                DustParticleEffect g = dust(0xFFC800, 1.0f);
                ring(w, g, x, top + 0.05, z, 0.3, 14);
                for (int i = 0; i < 5; i++) {
                    double a = i / 5.0 * Math.PI * 2;
                    for (double y = 0.05; y < 0.3; y += 0.1)
                        w.addParticle(g, x + Math.cos(a) * 0.3, top + y, z + Math.sin(a) * 0.3, 0, 0, 0);
                }
            }
            default -> {
                DustParticleEffect v = dust(0x6A1B9A, 1.0f);
                ring(w, v, x, top + 0.05, z, 0.55, 20);
                for (double h = 0; h < 1.0; h += 0.2) ring(w, v, x, top + 0.1 + h, z, 0.35 * (1 - h), 8);
            }
        }
    }

    static void ring(ClientWorld w, ParticleEffect e, double x, double y, double z, double r, int n) {
        for (int i = 0; i < n; i++) {
            double a = i / (double) n * Math.PI * 2;
            w.addParticle(e, x + Math.cos(a) * r, y, z + Math.sin(a) * r, 0, 0, 0);
        }
    }
}
