package com.visuals;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import org.slf4j.LoggerFactory;
import java.util.*;

public class VisualsMod implements ClientModInitializer {
    static KeyBinding menuKey;
    static final Map<LivingEntity, Integer> targets = new HashMap<>();
    static boolean wasOnGround = true;
    static boolean rshiftWasDown = false;
    static int jumpCd = 0;

    @Override
    public void onInitializeClient() {
        LoggerFactory.getLogger("visuals").info("Visuals mod loaded!");
        Config.load();
        Sounds.register();
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "Меню визуалов", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "Visuals"));

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("visuals").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.send(() -> mc.setScreen(new VisualsScreen()));
                    return Command.SINGLE_SUCCESS;
                })));

        AttackEntityCallback.EVENT.register((p, w, hand, e, hit) -> {
            if (w.isClient && e instanceof LivingEntity le) targets.put(le, 0);
            return ActionResult.PASS;
        });

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            boolean down = InputUtil.isKeyPressed(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT);
            boolean pressed = (down && !rshiftWasDown) | menuKey.wasPressed();
            rshiftWasDown = down;
            if (pressed && mc.currentScreen == null) mc.setScreen(new VisualsScreen());

            if (mc.player == null || mc.world == null) return;

            Effects.tick(mc.world);

            // убийства
            Iterator<Map.Entry<LivingEntity, Integer>> it = targets.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<LivingEntity, Integer> en = it.next();
                LivingEntity e = en.getKey();
                if (!e.isAlive()) {
                    if (e.getHealth() <= 0) {
                        Vec3d pos = e.getPos();
                        Effects.kill(Config.killEffect, pos);
                        Sounds.play(e instanceof PlayerEntity ? Config.playerSound : Config.mobSound, mc.world, pos);
                    }
                    it.remove();
                } else {
                    int n = en.getValue() + 1;
                    if (n > 300) it.remove(); else en.setValue(n);
                }
            }

            // прыжок
            if (jumpCd > 0) jumpCd--;
            boolean ground = mc.player.isOnGround();
            boolean jumped = (wasOnGround && !ground && mc.player.getVelocity().y > 0.1)
                    || (ground && mc.options.jumpKey.isPressed());
            if (Config.jumpAnim && jumped && jumpCd == 0) { Effects.jump(mc.player); jumpCd = 10; }
            wasOnGround = ground;

            // скины (видно в третьем лице)
            if (!mc.options.getPerspective().isFirstPerson() && mc.player.age % 2 == 0) {
                if (Config.wings > 0) Effects.wings(mc.world, mc.player, Config.wings);
                if (Config.hat > 0) Effects.hat(mc.world, mc.player, Config.hat);
            }
        });
    }
}
