package com.visuals.mixin;

import com.visuals.Config;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
    private void visuals$pose(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                              float swingProgress, ItemStack item, float equipProgress, MatrixStack m,
                              VertexConsumerProvider vc, int light, CallbackInfo ci) {
        if (hand != Hand.MAIN_HAND || !item.isIn(net.minecraft.registry.tag.ItemTags.SWORDS)) return;
        switch (Config.handPose) {
            case 1 -> m.translate(0.05f, -0.25f, 0.0f);                       // низко
            case 2 -> { m.translate(-0.05f, 0.15f, -0.1f); }                  // высоко
            case 3 -> { m.translate(0.1f, -0.05f, 0.0f);                      // наклон
                        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-25f));
                        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(15f)); }
            default -> {}
        }
    }
}
