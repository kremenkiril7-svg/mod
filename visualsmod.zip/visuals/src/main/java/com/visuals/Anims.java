package com.visuals;

import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.*;
import net.minecraft.util.math.Vec3d;
import java.util.*;

// Анимации смерти (из частиц)
public class Anims {
    static final Random R = new Random();
    interface Anim { void run(ClientWorld w, int t); }
    static class Task {
        int t = 0; final int dur; final Anim a;
        Task(int dur, Anim a) { this.dur = dur; this.a = a; }
    }
    static final List<Task> TASKS = new ArrayList<>();

    static DustParticleEffect dust(int rgb, float s) { return new DustParticleEffect(rgb, s); }

    public static void tick(ClientWorld w) {
        Iterator<Task> it = TASKS.iterator();
        while (it.hasNext()) {
            Task k = it.next();
            k.a.run(w, k.t);
            if (++k.t >= k.dur) it.remove();
        }
    }

    public static void play(int type, Vec3d p) {
        switch (type) {
            case 1 -> redStrike(p);
            case 2 -> goldPillar(p);
            case 3 -> fireBurst(p);
            default -> {}
        }
    }

    // 1) Красная молния (как на видео): удар с неба, вспышка, купол-волна, лучи по земле
    static void redStrike(Vec3d p) {
        final long seed = R.nextLong();
        final double[] ang = new double[6];
        Random sr = new Random(seed);
        for (int i = 0; i < 6; i++) ang[i] = i * Math.PI / 3 + (sr.nextDouble() - .5) * 0.5;
        TASKS.add(new Task(46, (w, t) -> {
            Random r = new Random(seed + t / 2);
            double H = 36;
            double width = t < 6 ? 0.7 : (t < 14 ? 0.45 : (t < 28 ? 0.25 : 0.1));
            int dens = t < 6 ? 5 : (t < 14 ? 3 : (t < 28 ? 2 : 1));
            DustParticleEffect core = dust(0xFFD0E0, t < 14 ? 2.2f : 1.3f);
            DustParticleEffect red = dust(0xFF2255, t < 14 ? 2.8f : 1.6f);
            double ox = 0, oz = 0;
            for (double y = 0; y <= H; y += 0.5 / Opt.fx()) {
                ox += (r.nextDouble() - .5) * 0.4;
                oz += (r.nextDouble() - .5) * 0.4;
                ox *= 0.97; oz *= 0.97;
                w.addParticle(core, p.x + ox, p.y + y, p.z + oz, 0, 0, 0);
                for (int j = 0; j < dens; j++) {
                    double a = R.nextDouble() * Math.PI * 2, rr = R.nextDouble() * width;
                    w.addParticle(red, p.x + ox + Math.cos(a) * rr, p.y + y, p.z + oz + Math.sin(a) * rr, 0, 0, 0);
                }
            }
            // красная вспышка вокруг
            if (t < 8)
                for (int i = 0; i < (int) (22 * Opt.fx()); i++) {
                    double a = R.nextDouble() * Math.PI * 2, b = R.nextDouble() * Math.PI, rr = 2.2 * R.nextDouble();
                    w.addParticle(dust(0xFF1E50, 4.0f), p.x + Math.cos(a) * Math.sin(b) * rr, p.y + 1 + Math.cos(b) * rr,
                            p.z + Math.sin(a) * Math.sin(b) * rr, 0, 0, 0);
                }
            // серый купол-волна
            if (t < 12) {
                double rad = 0.4 + t * 0.4;
                for (int i = 0; i < (int) (36 * Opt.fx()); i++) {
                    double th = R.nextDouble() * Math.PI * 2, ph = R.nextDouble() * Math.PI / 2;
                    w.addParticle(dust(0xC8C8C8, 2.0f), p.x + rad * Math.sin(ph) * Math.cos(th), p.y + rad * Math.cos(ph),
                            p.z + rad * Math.sin(ph) * Math.sin(th), 0, 0, 0);
                }
            }
            // лучи-трещины по земле
            double len = Math.min(3.0, t * 0.6);
            for (double a : ang)
                for (double d = 0.2; d < len; d += 0.3)
                    w.addParticle(dust(0xFF9A70, 1.2f), p.x + Math.cos(a) * d, p.y + 0.06, p.z + Math.sin(a) * d, 0, 0, 0);
            if (t < 20)
                w.addParticle(ParticleTypes.END_ROD, p.x + (R.nextDouble() - .5), p.y + R.nextDouble() * 2, p.z + (R.nextDouble() - .5), 0, 0.1, 0);
        }));
    }

    // 2) Золотой столб света
    static void goldPillar(Vec3d p) {
        TASKS.add(new Task(60, (w, t) -> {
            double H = 30;
            DustParticleEffect gold = dust(0xFFD84A, 3.0f);
            DustParticleEffect white = dust(0xFFFFFF, 2.5f);
            for (double y = 0; y < H; y += 0.6 / Opt.fx()) {
                w.addParticle(ParticleTypes.END_ROD, p.x, p.y + y, p.z, 0, 0, 0);
                for (int j = 0; j < 3; j++) {
                    double a = R.nextDouble() * Math.PI * 2, r = R.nextDouble() * 0.55;
                    w.addParticle(j == 0 ? white : gold, p.x + Math.cos(a) * r, p.y + y, p.z + Math.sin(a) * r, 0, 0, 0);
                }
            }
            DustParticleEffect sun = dust(0xFFE070, 4.0f);
            for (int i = 0; i < 14; i++) {
                double a = R.nextDouble() * Math.PI * 2, b = R.nextDouble() * Math.PI, r = 3.5 * R.nextDouble();
                w.addParticle(sun, p.x + Math.cos(a) * Math.sin(b) * r, p.y + H + Math.cos(b) * r, p.z + Math.sin(a) * Math.sin(b) * r, 0, 0, 0);
            }
            double rr = 0.4 + t * 0.12;
            for (int i = 0; i < 32; i++) {
                double a = i / 32.0 * Math.PI * 2;
                w.addParticle(gold, p.x + Math.cos(a) * rr, p.y + 0.15, p.z + Math.sin(a) * rr, 0, 0, 0);
            }
            if (t == 0) w.addParticle(ParticleTypes.EXPLOSION, p.x, p.y + 1, p.z, 0, 0, 0);
        }));
    }

    // 3) Огненный взрыв
    static void fireBurst(Vec3d p) {
        TASKS.add(new Task(24, (w, t) -> {
            if (t == 0) w.addParticle(ParticleTypes.EXPLOSION, p.x, p.y + 1, p.z, 0, 0, 0);
            if (t < 12)
                for (int i = 0; i < (int) (30 * Opt.fx()); i++) {
                    double vx = (R.nextDouble() - .5) * 0.6, vy = R.nextDouble() * 0.5, vz = (R.nextDouble() - .5) * 0.6;
                    w.addParticle(ParticleTypes.FLAME, p.x, p.y + 1, p.z, vx, vy, vz);
                    if (i % 3 == 0) w.addParticle(ParticleTypes.LAVA, p.x, p.y + 1, p.z, vx, vy, vz);
                    if (i % 5 == 0) w.addParticle(ParticleTypes.LARGE_SMOKE, p.x, p.y + 1, p.z, vx * 0.5, vy, vz * 0.5);
                }
        }));
    }
}
