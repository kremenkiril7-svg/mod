package com.visuals;

import org.lwjgl.openal.AL10;
import org.lwjgl.openal.ALC10;
import org.lwjgl.stb.STBVorbis;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;

// Свой плеер: декодирует ogg / mp3 / wav и играет через OpenAL (тот же звук, что и в игре).
public class Audio {
    public static class Pcm {
        short[] data;
        int ch, rate;
        int seconds() { return rate <= 0 || ch <= 0 ? 0 : data.length / ch / rate; }
    }

    static int src = 0, buf = 0;

    // ---------- декодирование ----------
    static Pcm decode(String name, byte[] bytes) throws Exception {
        String l = name.toLowerCase();
        if (l.endsWith(".mp3")) return Mp3.decode(bytes);
        if (l.endsWith(".wav")) return wav(bytes);
        return ogg(bytes);
    }

    static Pcm ogg(byte[] b) throws IOException {
        ByteBuffer mem = MemoryUtil.memAlloc(b.length);
        mem.put(b).flip();
        try (MemoryStack st = MemoryStack.stackPush()) {
            IntBuffer ch = st.mallocInt(1), rate = st.mallocInt(1);
            ShortBuffer sb = STBVorbis.stb_vorbis_decode_memory(mem, ch, rate);
            if (sb == null) throw new IOException("ogg");
            Pcm p = new Pcm();
            p.ch = ch.get(0);
            p.rate = rate.get(0);
            p.data = new short[sb.remaining()];
            sb.get(p.data);
            try { org.lwjgl.system.libc.LibCStdlib.free(sb); } catch (Throwable ignored) {}
            return p;
        } finally {
            MemoryUtil.memFree(mem);
        }
    }

    static int le32(byte[] b, int i) { return (b[i] & 255) | (b[i + 1] & 255) << 8 | (b[i + 2] & 255) << 16 | (b[i + 3] & 255) << 24; }

    static Pcm wav(byte[] b) throws IOException {
        int pos = 12, ch = 2, rate = 44100, bits = 16, ds = -1, dl = 0;
        while (pos + 8 <= b.length) {
            String id = new String(b, pos, 4, java.nio.charset.StandardCharsets.US_ASCII);
            int len = le32(b, pos + 4);
            if (id.equals("fmt ")) {
                ch = (b[pos + 10] & 255) | (b[pos + 11] & 255) << 8;
                rate = le32(b, pos + 12);
                bits = (b[pos + 22] & 255) | (b[pos + 23] & 255) << 8;
            } else if (id.equals("data")) {
                ds = pos + 8;
                dl = Math.min(len < 0 ? Integer.MAX_VALUE : len, b.length - ds);
                break;
            }
            pos += 8 + len + (len & 1);
        }
        if (ds < 0 || bits != 16 || ch < 1 || ch > 2) throw new IOException("wav 16-bit");
        Pcm p = new Pcm();
        p.ch = ch;
        p.rate = rate;
        p.data = new short[dl / 2];
        for (int i = 0; i < p.data.length; i++) p.data[i] = (short) ((b[ds + 2 * i] & 255) | (b[ds + 2 * i + 1]) << 8);
        return p;
    }

    // ---------- OpenAL ----------
    static boolean ready() {
        try { return ALC10.alcGetCurrentContext() != 0L; } catch (Throwable t) { return false; }
    }

    static boolean valid() {
        try { return src != 0 && ready() && AL10.alIsSource(src); } catch (Throwable t) { return false; }
    }

    static boolean start(Pcm p, float startSec, float gain) {
        release();
        try {
            if (!ready()) return false;
            AL10.alGetError();
            buf = AL10.alGenBuffers();
            ShortBuffer sb = MemoryUtil.memAllocShort(p.data.length);
            sb.put(p.data).flip();
            AL10.alBufferData(buf, p.ch == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16, sb, p.rate);
            MemoryUtil.memFree(sb);
            src = AL10.alGenSources();
            AL10.alSourcei(src, AL10.AL_BUFFER, buf);
            AL10.alSourcef(src, AL10.AL_GAIN, gain);
            if (startSec > 0) AL10.alSourcef(src, AL10.AL_SEC_OFFSET, startSec);
            AL10.alSourcePlay(src);
            return AL10.alGetError() == AL10.AL_NO_ERROR;
        } catch (Throwable t) {
            return false;
        }
    }

    static void release() {
        try {
            if (valid()) {
                AL10.alSourceStop(src);
                AL10.alDeleteSources(src);
                if (buf != 0) AL10.alDeleteBuffers(buf);
            }
        } catch (Throwable ignored) {}
        src = 0;
        buf = 0;
    }

    static void pause() { try { if (valid()) AL10.alSourcePause(src); } catch (Throwable ignored) {} }

    static void resume() { try { if (valid()) AL10.alSourcePlay(src); } catch (Throwable ignored) {} }

    static void gain(float g) { try { if (valid()) AL10.alSourcef(src, AL10.AL_GAIN, g); } catch (Throwable ignored) {} }

    static float offset() { try { return valid() ? AL10.alGetSourcef(src, AL10.AL_SEC_OFFSET) : -1f; } catch (Throwable t) { return -1f; } }

    // 0 — остановлен, 1 — играет, 2 — пауза, -1 — источник недействителен
    static int state() {
        try {
            if (!valid()) return -1;
            int s = AL10.alGetSourcei(src, AL10.AL_SOURCE_STATE);
            return s == AL10.AL_PLAYING ? 1 : s == AL10.AL_PAUSED ? 2 : 0;
        } catch (Throwable t) { return -1; }
    }
}
