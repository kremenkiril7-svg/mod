package com.visuals;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.file.*;
import java.util.Arrays;

// Все публичные static-поля (int / boolean / float) сохраняются в конфиг автоматически.
public class Config {
    // звуки и анимации
    public static int mobSound = 0, playerSound = 0;   // 0 Нет, 1 Луч света, 2 Падение человека, 3 Святой дух
    public static int mobAnim = 0, playerAnim = 0;     // 0 Нет, 1 Красная молния, 2 Золотой столб, 3 Огненный взрыв
    public static int hitSound = 0;                    // звук удара (см. Sounds.HIT_NAMES)
    public static int hitVol = 100;                    // громкость удара, %

    // меню и бой
    public static int keyMenu = 344;                   // Right Shift
    public static final int[] keys = new int[24];      // клавиши функций, -1 = не назначена
    public static float radius = 3.5f;
    public static int cps = 10;
    public static boolean auraCd = true;
    public static int pickupRadius = 5;

    // боевые настройки
    public static int teamColor = 0;                   // цвет моей команды (Bedwars), 0 — не выбран
    public static int target = 0;                      // 0 все, 1 игроки, 2 мобы, 3 Bedwars: только враги-игроки
    public static boolean needSee = true;              // бить только то, что видно
    public static int aimSpeed = 14;                   // градусов за тик
    public static int antiKbPct = 100;
    public static int flySpeed = 100, speedMul = 100;
    public static boolean autoAxe = true;
    public static int clickCps = 12;
    public static boolean clickHold = true;

    // вид меню
    public static int theme = 0;                       // 0 чёрный, 1 приколный, 2 красный, 3 старый

    // ходьба
    public static int walkFx = 0;                      // 0 нет, 1 кольца, 2 след
    public static boolean animThirdOnly = false;       // рисовать только от 3-го лица

    // остров, FPS-панели
    public static boolean island = true;
    public static boolean fpsShow = true;
    public static int fpsPos = 0;                      // позиция острова
    public static boolean hudBar = false;              // панель FPS / TPS / пинг
    public static int barPos = 1;

    // панель «Инфо»
    public static boolean infoArmor = true, infoInv = true, infoHotbar = true, infoFood = true, infoHand = true, infoCoords = false;
    public static int infoPos = 0;
    public static int infoScale = 100;

    // текст песни
    public static boolean lyrics = true;
    public static int lyricsPos = 0;                   // 0 снизу, 1 по центру, 2 сверху
    public static int lyricsSize = 150;
    public static int lyricsOffset = 0;                // мс
    public static boolean lyricsAuto = true;           // искать текст в интернете
    public static int musicVol = 100;                  // громкость плеера, %

    // анимации смерти
    public static boolean animOnlyMine = false;        // только для моих убийств

    // экран
    public static boolean effectsHud = false, armorHud = false;
    public static int effectsPos = 2, armorGap = 30, armorScale = 100;

    // анимация прыжка
    public static int jumpFx = 0;                      // 0 нет, 1 прыжок, 2 приземление, 3 оба
    public static int jumpColor = 2;
    public static int jumpSize = 100;
    public static boolean jumpParts = true;

    // одежда
    public static int hat = 0, hatColor = 0, hatSize = 100;
    public static int wings = 0, wingColor = 2, wingSize = 100, wingSpeed = 100;

    // оптимизация
    public static int optMode = 0;                     // 0 выкл, 1 лёгкая, 2 сильная, 3 максимум
    public static boolean optAuto = false;
    public static int optTarget = 60;
    public static boolean origSaved = false;           // сохранены ли твои настройки игры
    public static int origView = 12, origSim = 12, origEnt = 100, origParticles = 0, origClouds = 2,
            origShadows = 1, origAo = 1, origGraphics = 1, origBlend = 2, origVsync = 1, origMip = 4;

    static { Arrays.fill(keys, -1); }
    static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("visuals_mod.json");

    public static void load() {
        try {
            if (!Files.exists(PATH)) return;
            JsonObject o = JsonParser.parseString(Files.readString(PATH)).getAsJsonObject();
            for (Field f : Config.class.getDeclaredFields()) {
                int m = f.getModifiers();
                String n = f.getName();
                if (!Modifier.isStatic(m) || Modifier.isFinal(m) || !o.has(n)) continue;
                try {
                    Class<?> t = f.getType();
                    if (t == int.class) f.setInt(null, o.get(n).getAsInt());
                    else if (t == boolean.class) f.setBoolean(null, o.get(n).getAsBoolean());
                    else if (t == float.class) f.setFloat(null, o.get(n).getAsFloat());
                } catch (Exception ignored) {}
            }
            if (o.has("keys")) {
                JsonArray a = o.getAsJsonArray("keys");
                for (int n = 0; n < keys.length && n < a.size(); n++) keys[n] = a.get(n).getAsInt();
            }
        } catch (Exception ignored) {}
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            for (Field f : Config.class.getDeclaredFields()) {
                int m = f.getModifiers();
                if (!Modifier.isStatic(m) || Modifier.isFinal(m)) continue;
                Class<?> t = f.getType();
                if (t == int.class) o.addProperty(f.getName(), f.getInt(null));
                else if (t == boolean.class) o.addProperty(f.getName(), f.getBoolean(null));
                else if (t == float.class) o.addProperty(f.getName(), f.getFloat(null));
            }
            JsonArray a = new JsonArray();
            for (int k : keys) a.add(k);
            o.add("keys", a);
            Files.writeString(PATH, o.toString());
        } catch (Exception ignored) {}
    }
}
