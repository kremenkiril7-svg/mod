package com.visuals;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix4f;

// Полупрозрачная светящаяся геометрия в мире (слой как у молнии). Все фигуры двусторонние.
public class Draw {
    public static final String[] COLORS = {"Синий", "Красный", "Белый", "Золотой", "Фиолетовый", "Бирюзовый", "Радуга"};
    static VertexConsumer buf;
    static VertexConsumerProvider vcp;
    static Matrix4f mat;

    public static int color(int idx, float time) {
        return switch (idx) {
            case 0 -> 0x2D5BFF;
            case 1 -> 0xFF2A2A;
            case 2 -> 0xFFFFFF;
            case 3 -> 0xFFC83C;
            case 4 -> 0xB04BFF;
            case 5 -> 0x28E0D0;
            default -> MathHelper.hsvToRgb((time * 0.01f) % 1f, 0.75f, 1f) & 0xFFFFFF;
        };
    }

    public static int light(int rgb) {
        int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
        return ((r + 255) / 2 << 16) | ((g + 255) / 2 << 8) | ((b + 255) / 2);
    }

    public static void begin(VertexConsumerProvider p, Matrix4f m) {
        vcp = p;
        mat = m;
        buf = p.getBuffer(RenderLayer.getLightning());
    }

    public static void end() {
        if (vcp instanceof VertexConsumerProvider.Immediate imm) imm.draw(RenderLayer.getLightning());
        buf = null;
        vcp = null;
    }

    static void v(float x, float y, float z, int rgb, float a) {
        int al = MathHelper.clamp((int) (a * 255f), 0, 255);
        buf.vertex(mat, x, y, z).color((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255, al);
    }

    public static void quad(float x1, float y1, float z1, float x2, float y2, float z2,
                            float x3, float y3, float z3, float x4, float y4, float z4,
                            int rgb, float a1, float a2, float a3, float a4) {
        v(x1, y1, z1, rgb, a1); v(x2, y2, z2, rgb, a2); v(x3, y3, z3, rgb, a3); v(x4, y4, z4, rgb, a4);
        v(x4, y4, z4, rgb, a4); v(x3, y3, z3, rgb, a3); v(x2, y2, z2, rgb, a2); v(x1, y1, z1, rgb, a1);
    }

    public static void tri(float x1, float y1, float z1, float x2, float y2, float z2,
                           float x3, float y3, float z3, int rgb, float a1, float a2, float a3) {
        quad(x1, y1, z1, x2, y2, z2, x3, y3, z3, x3, y3, z3, rgb, a1, a2, a3, a3);
    }

    // конус с основанием на высоте cy
    public static void cone(float cy, float r, float h, int seg, int rgb, float aBase, float aTip) {
        for (int i = 0; i < seg; i++) {
            double a0 = i * 2 * Math.PI / seg, a1 = (i + 1) * 2 * Math.PI / seg;
            tri((float) Math.cos(a0) * r, cy, (float) Math.sin(a0) * r,
                    (float) Math.cos(a1) * r, cy, (float) Math.sin(a1) * r,
                    0, cy + h, 0, rgb, aBase, aBase, aTip);
        }
    }

    // плоское кольцо
    public static void ring(float cy, float r1, float r2, int seg, int rgb, float aIn, float aOut) {
        for (int i = 0; i < seg; i++) {
            double a0 = i * 2 * Math.PI / seg, a1 = (i + 1) * 2 * Math.PI / seg;
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            quad(c0 * r1, cy, s0 * r1, c1 * r1, cy, s1 * r1, c1 * r2, cy, s1 * r2, c0 * r2, cy, s0 * r2, rgb, aIn, aIn, aOut, aOut);
        }
    }

    public static void disc(float cy, float r, int seg, int rgb, float a) {
        for (int i = 0; i < seg; i++) {
            double a0 = i * 2 * Math.PI / seg, a1 = (i + 1) * 2 * Math.PI / seg;
            tri(0, cy, 0, (float) Math.cos(a0) * r, cy, (float) Math.sin(a0) * r,
                    (float) Math.cos(a1) * r, cy, (float) Math.sin(a1) * r, rgb, a, a, a);
        }
    }

    // стенка цилиндра; gap > 0: каждый gap-й сегмент пропускается (эффект сетки)
    public static void wall(float cy, float r, float h, int seg, int rgb, float aBot, float aTop, int gap) {
        for (int i = 0; i < seg; i++) {
            if (gap > 0 && i % gap == gap - 1) continue;
            double a0 = i * 2 * Math.PI / seg, a1 = (i + 1) * 2 * Math.PI / seg;
            float c0 = (float) Math.cos(a0) * r, s0 = (float) Math.sin(a0) * r, c1 = (float) Math.cos(a1) * r, s1 = (float) Math.sin(a1) * r;
            quad(c0, cy, s0, c1, cy, s1, c1, cy + h, s1, c0, cy + h, s0, rgb, aBot, aBot, aTop, aTop);
        }
    }
}
