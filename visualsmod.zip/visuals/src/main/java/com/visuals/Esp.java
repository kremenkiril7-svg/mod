package com.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class Esp {
    static double[] project(MinecraftClient mc, Camera cam, Vec3d pos, int sw, int sh) {
        Vec3d cp = cam.getPos();
        double dx = pos.x - cp.x, dy = pos.y - cp.y, dz = pos.z - cp.z;
        double yaw = Math.toRadians(cam.getYaw()), pitch = Math.toRadians(cam.getPitch());
        double fx = -Math.sin(yaw) * Math.cos(pitch), fy = -Math.sin(pitch), fz = Math.cos(yaw) * Math.cos(pitch);
        double rx = -Math.cos(yaw), ry = 0, rz = -Math.sin(yaw);
        double ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx;
        double z = dx * fx + dy * fy + dz * fz;
        if (z <= 0.05) return null;
        double x = dx * rx + dy * ry + dz * rz;
        double y = dx * ux + dy * uy + dz * uz;
        double t = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2);
        double aspect = (double) mc.getWindow().getFramebufferWidth() / mc.getWindow().getFramebufferHeight();
        double sx = (x / (z * t * aspect)) * 0.5 + 0.5;
        double sy = 0.5 - (y / (z * t)) * 0.5;
        return new double[]{sx * sw, sy * sh};
    }

    static final org.joml.Matrix4f PROJ = new org.joml.Matrix4f(), PV = new org.joml.Matrix4f();
    static boolean haveMat = false;

    // матрицы камеры из мирового рендера: точная проекция (учитывает FOV и спринт)
    public static void capture(net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext ctx) {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            Camera cam = ctx.camera();
            org.joml.Matrix4f view = new org.joml.Matrix4f().rotation(new org.joml.Quaternionf(cam.getRotation()).conjugate());
            PROJ.set(ctx.projectionMatrix());
            PV.set(PROJ).mul(view);
            haveMat = true;
        } catch (Throwable t) { haveMat = false; }
    }

    static double[] proj(MinecraftClient mc, Camera cam, double x, double y, double z, int sw, int sh) {
        if (!haveMat) return project(mc, cam, new Vec3d(x, y, z), sw, sh);
        Vec3d cp = cam.getPos();
        org.joml.Vector4f v = new org.joml.Vector4f((float) (x - cp.x), (float) (y - cp.y), (float) (z - cp.z), 1f);
        PV.transform(v);
        if (v.w <= 0.05f) return null;
        double nx = v.x / v.w, ny = v.y / v.w;
        return new double[]{(nx * 0.5 + 0.5) * sw, (0.5 - ny * 0.5) * sh};
    }

    static void line(DrawContext c, double x1, double y1, double x2, double y2, int col) {
        double dx = x2 - x1, dy = y2 - y1;
        int len = (int) Math.round(Math.sqrt(dx * dx + dy * dy));
        if (len < 1) return;
        c.getMatrices().push();
        c.getMatrices().translate((float) x1, (float) y1, 0f);
        c.getMatrices().multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Z.rotation((float) Math.atan2(dy, dx)));
        c.fill(0, 0, len, 1, col);
        c.getMatrices().pop();
    }

    static final net.minecraft.util.Identifier H_BG = net.minecraft.util.Identifier.ofVanilla("hud/heart/container");
    static final net.minecraft.util.Identifier H_FULL = net.minecraft.util.Identifier.ofVanilla("hud/heart/full");
    static final net.minecraft.util.Identifier H_HALF = net.minecraft.util.Identifier.ofVanilla("hud/heart/half");
    static final net.minecraft.util.Identifier H_AFULL = net.minecraft.util.Identifier.ofVanilla("hud/heart/absorbing_full");
    static final net.minecraft.util.Identifier H_AHALF = net.minecraft.util.Identifier.ofVanilla("hud/heart/absorbing_half");

    static final net.minecraft.util.Identifier A_FULL = net.minecraft.util.Identifier.ofVanilla("hud/armor_full");
    static final net.minecraft.util.Identifier A_HALF = net.minecraft.util.Identifier.ofVanilla("hud/armor_half");
    static final net.minecraft.util.Identifier A_EMPTY = net.minecraft.util.Identifier.ofVanilla("hud/armor_empty");

    // броня: 10 значков, каждый = 2 очка
    static void armor(DrawContext c, int ar, double cxm, double y) {
        float s = 0.62f;
        c.getMatrices().push();
        c.getMatrices().translate((float) (cxm - 10 * 8 * s / 2), (float) y, 0f);
        c.getMatrices().scale(s, s, 1f);
        for (int i = 0; i < 10; i++) {
            if (i < ar / 2) sprite(c, A_FULL, i * 8, 0);
            else if (i == ar / 2 && ar % 2 == 1) sprite(c, A_HALF, i * 8, 0);
            else sprite(c, A_EMPTY, i * 8, 0);
        }
        c.getMatrices().pop();
    }

    static void sprite(DrawContext c, net.minecraft.util.Identifier id, int x, int y) {
        c.drawGuiTexture(net.minecraft.client.render.RenderLayer::getGuiTextured, id, x, y, 9, 9);
    }

    // сердечки как в игре: контейнеры + целые/половинки, золотые — поглощение
    static void hearts(DrawContext c, float hp, float absorb, float max, double cxm, double y) {
        int total = MathHelper.clamp((int) Math.ceil(max / 2f), 1, 10);
        float s = 0.62f;
        float wRow = total * 8 * s;
        c.getMatrices().push();
        c.getMatrices().translate((float) (cxm - wRow / 2), (float) y, 0f);
        c.getMatrices().scale(s, s, 1f);
        int h = Math.round(Math.min(hp, max));
        for (int i = 0; i < total; i++) {
            sprite(c, H_BG, i * 8, 0);
            if (i < h / 2) sprite(c, H_FULL, i * 8, 0);
            else if (i == h / 2 && h % 2 == 1) sprite(c, H_HALF, i * 8, 0);
        }
        int ab = Math.round(absorb);
        if (ab > 0) {
            int n = Math.min(10, (ab + 1) / 2);
            for (int i = 0; i < n; i++) {
                if (i < ab / 2) sprite(c, H_AFULL, i * 8, -9);
                else sprite(c, H_AHALF, i * 8, -9);
            }
        }
        c.getMatrices().pop();
    }

    // ВХ: 3D хитбокс (сквозь стены), сердечки здоровья, имя
    public static void draw(DrawContext ctx, MinecraftClient mc, float td) {
        if (!Cheats.players || mc.world == null || mc.player == null) return;
        Camera cam = mc.gameRenderer.getCamera();
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        TextRenderer tr = mc.textRenderer;
        for (AbstractClientPlayerEntity o : mc.world.getPlayers()) {
            if (o == mc.player) continue;
            if (mc.player.squaredDistanceTo(o) > (double) Config.espRange * Config.espRange) continue;
            double ix = MathHelper.lerp(td, o.prevX, o.getX());
            double iy = MathHelper.lerp(td, o.prevY, o.getY());
            double iz = MathHelper.lerp(td, o.prevZ, o.getZ());
            net.minecraft.util.math.Box bb = o.getBoundingBox().offset(ix - o.getX(), iy - o.getY(), iz - o.getZ());
            double[][] pt = new double[8][];
            double minX = 1e9, minY = 1e9, maxX = -1e9;
            boolean ok = true;
            for (int i = 0; i < 8 && ok; i++) {
                pt[i] = proj(mc, cam, (i & 1) == 0 ? bb.minX : bb.maxX, (i & 2) == 0 ? bb.minY : bb.maxY, (i & 4) == 0 ? bb.minZ : bb.maxZ, sw, sh);
                if (pt[i] == null) { ok = false; break; }
                minX = Math.min(minX, pt[i][0]); maxX = Math.max(maxX, pt[i][0]); minY = Math.min(minY, pt[i][1]);
            }
            if (!ok) continue;
            boolean invis = Cheats.invisIds.contains(o.getId());
            int col = invis ? 0xFFFFD040 : 0xFFFF2A2A;
            if (Config.espBox) {
                for (int i = 0; i < 8; i++)
                    for (int bit = 1; bit <= 4; bit <<= 1)
                        if ((i & bit) == 0) line(ctx, pt[i][0], pt[i][1], pt[i | bit][0], pt[i | bit][1], col);
            } else {
                double maxY = -1e9;
                for (double[] q : pt) maxY = Math.max(maxY, q[1]);
                ctx.drawBorder((int) minX, (int) minY, Math.max(6, (int) (maxX - minX)), Math.max(6, (int) (maxY - minY)), col);
            }
            double mid = (minX + maxX) / 2;
            float absorb = o.getAbsorptionAmount();
            float max = Math.max(1f, o.getMaxHealth());
            double y = minY - 11;
            if (Config.espHearts) {
                hearts(ctx, o.getHealth(), absorb, max, mid, y);
                y -= absorb > 0 ? 17 : 8;
            }
            if (Config.espHearts && o.getArmor() > 0) {
                armor(ctx, o.getArmor(), mid, y);
                y -= 8;
            }
            if (Config.espName) {
                String label = o.getName().getString() + "  " + Math.round(o.getHealth() + absorb) + " хп  " + o.getArmor() + " бр  " + Math.round(mc.player.distanceTo(o)) + " м" + (invis ? "  [невидимка]" : "");
                ctx.drawCenteredTextWithShadow(tr, label, (int) mid, (int) y - 4, 0xFFFFFFFF);
            }
        }
    }

    // Инфо: инвентарь и прочность без открытия (что показывать, где и какого размера — в меню «Приколно»)
    public static void info(DrawContext ctx, MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        TextRenderer tr = mc.textRenderer;
        float s = Math.max(0.5f, Config.infoScale / 100f);
        int sw = (int) (mc.getWindow().getScaledWidth() / s), sh = (int) (mc.getWindow().getScaledHeight() / s);
        int pw = 172;
        int ph = 18;
        if (Config.infoCoords) ph += 11;
        if (Config.infoArmor) ph += 34;
        if (Config.infoInv) ph += 58;
        if (Config.infoHotbar) ph += 22;
        if (Config.infoHand) ph += 12;
        ph += 4;
        boolean right = Config.infoPos == 0 || Config.infoPos == 2;
        boolean bottom = Config.infoPos >= 2;
        int x = right ? sw - pw - 4 : 4;
        int y = bottom ? sh - ph - 4 : 24;

        ctx.getMatrices().push();
        ctx.getMatrices().scale(s, s, 1f);
        Ui.panel(ctx, x, y, pw, ph);
        ctx.drawTextWithShadow(tr, "Инфо", x + 6, y + 5, 0xFFFFFFFF);
        if (Config.infoFood) {
            String food = "Еда " + p.getHungerManager().getFoodLevel() + "/20  хп " + Math.round(p.getHealth());
            ctx.drawText(tr, food, x + 40, y + 5, 0xFFFFE0E0, false);
        }
        int cy = y + 18;
        if (Config.infoCoords) {
            ctx.drawText(tr, "XYZ: " + p.getBlockX() + " " + p.getBlockY() + " " + p.getBlockZ(), x + 6, cy, 0xFFFFE0E0, false);
            cy += 11;
        }
        if (Config.infoArmor) {
            for (int i = 0; i < 5; i++) {
                ItemStack st = i < 4 ? p.getInventory().getArmorStack(3 - i) : p.getOffHandStack();
                int sx = x + 6 + i * 18 + (i == 4 ? 14 : 0), sy = cy;
                Ui.slot(ctx, sx, sy, 18, 18, false);
                if (!st.isEmpty()) {
                    ctx.drawItem(st, sx + 1, sy + 1);
                    ctx.drawStackOverlay(tr, st, sx + 1, sy + 1);
                    if (st.isDamageable()) {
                        int left = st.getMaxDamage() - st.getDamage();
                        int pct = left * 100 / Math.max(1, st.getMaxDamage());
                        int col = pct > 60 ? 0xFF7CFF7C : (pct > 30 ? 0xFFFFE060 : 0xFFFF5050);
                        ctx.drawText(tr, pct + "%", sx + 1, sy + 20, col, false);
                    }
                }
            }
            cy += 34;
        }
        if (Config.infoInv) {
            for (int i = 0; i < 27; i++) {
                ItemStack st = p.getInventory().getStack(9 + i);
                int sx = x + 6 + (i % 9) * 18, sy = cy + (i / 9) * 18;
                Ui.slot(ctx, sx, sy, 18, 18, false);
                if (!st.isEmpty()) { ctx.drawItem(st, sx + 1, sy + 1); ctx.drawStackOverlay(tr, st, sx + 1, sy + 1); }
            }
            cy += 58;
        }
        if (Config.infoHotbar) {
            for (int i = 0; i < 9; i++) {
                ItemStack st = p.getInventory().getStack(i);
                int sx = x + 6 + i * 18, sy = cy;
                Ui.slot(ctx, sx, sy, 18, 18, i == p.getInventory().selectedSlot);
                if (!st.isEmpty()) { ctx.drawItem(st, sx + 1, sy + 1); ctx.drawStackOverlay(tr, st, sx + 1, sy + 1); }
            }
            cy += 22;
        }
        if (Config.infoHand) {
            ItemStack hand = p.getMainHandStack();
            if (!hand.isEmpty() && hand.isDamageable()) {
                int left = hand.getMaxDamage() - hand.getDamage();
                ctx.drawText(tr, "В руке: " + left + "/" + hand.getMaxDamage(), x + 6, cy, 0xFFFFE0E0, false);
            }
        }
        ctx.getMatrices().pop();
    }
}
