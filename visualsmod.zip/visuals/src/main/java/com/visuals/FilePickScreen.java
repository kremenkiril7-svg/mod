package com.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import java.nio.file.*;
import java.util.*;

// Выбор песни прямо в игре: ходим по папкам, нажимаем на .ogg / .mp3 / .wav
public class FilePickScreen extends Screen {
    static final int W = 340, H = 232, ROWS = 10;
    final Screen parent;
    Path dir;
    List<Path> items = new ArrayList<>();
    int scroll = 0;
    String msg = "";
    float scale = 1f;
    int px, py;
    final List<int[]> boxes = new ArrayList<>();
    final List<Runnable> acts = new ArrayList<>();

    public FilePickScreen(Screen parent) {
        super(Text.literal("Выбор песни"));
        this.parent = parent;
        Path start = Paths.get("/storage/emulated/0/Download");
        if (!Files.isDirectory(start)) start = Paths.get(System.getProperty("user.home", "."));
        if (!Files.isDirectory(start)) start = Songs.songsDir();
        go(start);
    }

    void go(Path d) {
        List<Path> dirs = new ArrayList<>(), files = new ArrayList<>();
        try (var st = Files.list(d)) {
            for (Path p : (Iterable<Path>) st::iterator) {
                String n = p.getFileName().toString();
                if (n.startsWith(".")) continue;
                if (Files.isDirectory(p)) dirs.add(p);
                else if (Songs.audio(n)) files.add(p);
            }
        } catch (Throwable e) {
            msg = "Нет доступа к этой папке";
            return;
        }
        Comparator<Path> cmp = Comparator.comparing(p -> p.getFileName().toString().toLowerCase());
        dirs.sort(cmp);
        files.sort(cmp);
        items = new ArrayList<>(dirs);
        items.addAll(files);
        dir = d;
        scroll = 0;
        msg = items.isEmpty() ? "Тут нет песен и папок" : "";
    }

    @Override
    protected void init() {
        scale = Math.min(1f, Math.min((width - 6f) / W, (height - 6f) / H));
        px = (int) ((width / scale - W) / 2);
        py = (int) ((height / scale - H) / 2);
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float d) { c.fill(0, 0, width, height, 0xAA000000); }

    void box(DrawContext c, int x, int y, int w, int h, String label, boolean on, Runnable a) {
        Ui.slot(c, x, y, w, h, on);
        c.drawTextWithShadow(textRenderer, label, x + 5, y + (h - 8) / 2, 0xFFFFFFFF);
        boxes.add(new int[]{x, y, w, h});
        acts.add(a);
    }

    void root(DrawContext c, int i, String label, String path) {
        Path p = Paths.get(path);
        box(c, px + 8 + i * 66, py + 22, 63, 16, label, false, () -> { if (Files.isDirectory(p)) go(p); else msg = "Нет такой папки"; });
    }

    @Override
    public void render(DrawContext c, int mx, int my, float d) {
        renderBackground(c, mx, my, d);
        boxes.clear();
        acts.clear();
        c.getMatrices().push();
        c.getMatrices().scale(scale, scale, 1f);
        Ui.panel(c, px, py, W, H);
        c.drawTextWithShadow(textRenderer, "Выбери песню (ogg / mp3 / wav)", px + 8, py + 6, 0xFFFFFFFF);
        root(c, 0, "Загрузки", "/storage/emulated/0/Download");
        root(c, 1, "Музыка", "/storage/emulated/0/Music");
        root(c, 2, "Память", "/storage/emulated/0");
        root(c, 3, "Игра", Songs.songsDir().getParent().toString());
        root(c, 4, "Дом", System.getProperty("user.home", "."));
        String ps = dir == null ? "" : dir.toString();
        if (ps.length() > 52) ps = "…" + ps.substring(ps.length() - 51);
        c.drawText(textRenderer, ps, px + 8, py + 43, 0xFFFFC0C0, false);
        for (int r = 0; r < ROWS; r++) {
            int i = scroll + r, y = py + 55 + r * 15;
            if (i >= items.size()) break;
            Path p = items.get(i);
            boolean isDir = Files.isDirectory(p);
            String n = p.getFileName().toString();
            if (n.length() > 46) n = n.substring(0, 45) + "…";
            box(c, px + 8, y, 262, 14, (isDir ? "[ ] " : "♪ ") + n, false, () -> {
                if (isDir) go(p); else { Songs.addFromFile(p); close(); }
            });
        }
        box(c, px + 276, py + 55, 56, 16, "  ▲", false, () -> scroll = Math.max(0, scroll - ROWS));
        box(c, px + 276, py + 75, 56, 16, "  ▼", false, () -> scroll = Math.min(Math.max(0, items.size() - 1), scroll + ROWS));
        box(c, px + 276, py + 99, 56, 16, " Наверх", false, () -> { if (dir != null && dir.getParent() != null) go(dir.getParent()); });
        box(c, px + 276, py + H - 24, 56, 16, " Назад", false, this::close);
        if (items.size() > ROWS)
            c.drawText(textRenderer, (scroll + 1) + "-" + Math.min(items.size(), scroll + ROWS) + " / " + items.size(), px + 276, py + 122, 0xFFFFB0B0, false);
        c.drawText(textRenderer, msg, px + 8, py + H - 20, 0xFFFFE0E0, false);
        c.getMatrices().pop();
    }

    @Override
    public boolean mouseClicked(double rmx, double rmy, int b) {
        double mx = rmx / scale, my = rmy / scale;
        for (int i = boxes.size() - 1; i >= 0; i--) {
            int[] r = boxes.get(i);
            if (mx >= r[0] && mx < r[0] + r[2] && my >= r[1] && my < r[1] + r[3]) { acts.get(i).run(); return true; }
        }
        return super.mouseClicked(rmx, rmy, b);
    }

    public boolean mouseScrolled(double mx, double my, double h, double v) {
        scroll = MathHelper.clamp(scroll - (int) Math.signum(v) * 3, 0, Math.max(0, items.size() - 1));
        return true;
    }

    @Override
    public void close() { client.setScreen(parent); }
}
