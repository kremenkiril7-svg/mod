package com.visuals;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.*;

// «Приколы»: панель FPS/TPS/пинг, кольца прыжка, частицы
public class Fun {
    public static final String[] POS = {"Сверху по центру", "Сверху слева", "Сверху справа", "Снизу слева", "Снизу справа"};
    public static final String[] CORNERS = {"Справа сверху", "Слева сверху", "Справа снизу", "Слева снизу"};
    public static final String[] JUMP = {"Нет", "При прыжке", "При приземлении", "Прыжок и приземление"};

    // позиция плашки w×h на экране
    public static int[] place(int pos, int w, int h, int sw, int sh) {
        int x = (pos == 1 || pos == 3) ? 4 : (pos == 2 || pos == 4) ? sw - w - 4 : (sw - w) / 2;
        int y = pos >= 3 ? sh - h - 4 : 4;
        return new int[]{x, y};
    }

    // ---------- TPS ----------
    static final long[] TT = new long[20];
    static int ti = 0, tcount = 0;
    static long lastNs = 0;
    public static float tps = 20f;

    public static void tickTime() {
        long now = System.nanoTime();
        if (lastNs != 0) {
            TT[ti] = now - lastNs;
            ti = (ti + 1) % TT.length;
            if (tcount < TT.length) tcount++;
            long sum = 0;
            for (int i = 0; i < tcount; i++) sum += TT[i];
            if (sum > 0) tps = Math.min(20f, 1e9f * tcount / sum);
        }
        lastNs = now;
    }

    static int ping(MinecraftClient mc) {
        try {
            ClientPlayNetworkHandler nh = mc.getNetworkHandler();
            if (nh == null || mc.player == null) return 0;
            PlayerListEntry e = nh.getPlayerListEntry(mc.player.getUuid());
            return e == null ? 0 : e.getLatency();
        } catch (Throwable t) { return 0; }
    }

    public static void bar(DrawContext c, MinecraftClient mc) {
        TextRenderer tr = mc.textRenderer;
        String s = "Limozut  |  " + mc.getCurrentFps() + " fps  |  " + String.format(Locale.ROOT, "%.1f", tps) + " tps  |  " + ping(mc) + " ms";
        int w = tr.getWidth(s) + 16, h = 16;
        int[] p = place(Config.barPos, w, h, mc.getWindow().getScaledWidth(), mc.getWindow().getScaledHeight());
        Ui.round(c, p[0], p[1], w, h, 6, 0xCC101418);
        c.drawTextWithShadow(tr, s, p[0] + 8, p[1] + 4, 0xFFFFFFFF);
    }

    // ---------- кольца прыжка ----------
    static class Ring {
        final double x, y, z;
        final long t0;
        final float sz;
        Ring(double x, double y, double z, long t0, float sz) { this.x = x; this.y = y; this.z = z; this.t0 = t0; this.sz = sz; }
    }

    static final List<Ring> RINGS = new ArrayList<>();
    static boolean wasGround = true;
    static int air = 0;

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) { wasGround = true; return; }
        boolean g = p.isOnGround();
        if (Config.jumpFx != 0) {
            if (wasGround && !g && p.getVelocity().y > 0.1) {
                if (Config.jumpFx == 1 || Config.jumpFx == 3) ring(mc, p);
            } else if (!wasGround && g && air >= 5) {
                if (Config.jumpFx >= 2) ring(mc, p);
            }
            if (Config.jumpParts && p.getVelocity().horizontalLengthSquared() > 0.01 && p.age % 2 == 0 && Opt.fx() > 0.5f) {
                int rgb = Draw.color(Config.jumpColor, System.currentTimeMillis() / 20f);
                mc.world.addParticle(new DustParticleEffect(rgb, 0.9f),
                        p.getX() + (Math.random() - 0.5) * 0.6, p.getY() + 0.1 + Math.random() * 0.3, p.getZ() + (Math.random() - 0.5) * 0.6, 0, 0, 0);
            }
        }
        if (Config.walkFx != 0 && g && p.getVelocity().horizontalLengthSquared() > 0.004 && !p.isSneaking()) {
            if (Config.walkFx == 1 && p.age % 9 == 0) ring(mc, p, 0.45f, false);
            else if (Config.walkFx == 2 && p.age % 2 == 0 && Opt.fx() > 0.35f) {
                int rgb = Draw.color(Config.jumpColor, System.currentTimeMillis() / 20f);
                for (int i = 0; i < 2; i++)
                    mc.world.addParticle(new DustParticleEffect(rgb, 1.1f), p.getX() + (Math.random() - 0.5) * 0.4, p.getY() + 0.05,
                            p.getZ() + (Math.random() - 0.5) * 0.4, 0, 0.01, 0);
            }
        }
        air = g ? 0 : air + 1;
        wasGround = g;
    }

    public static void ring(MinecraftClient mc, ClientPlayerEntity p) { ring(mc, p, 1f, true); }

    public static void ring(MinecraftClient mc, ClientPlayerEntity p, float sz, boolean burst) {
        if (RINGS.size() > 12) RINGS.remove(0);
        RINGS.add(new Ring(p.getX(), p.getY(), p.getZ(), System.currentTimeMillis(), sz));
        if (burst && Config.jumpParts && mc.world != null) {
            int n = (int) (20 * Opt.fx());
            int rgb = Draw.color(Config.jumpColor, System.currentTimeMillis() / 20f);
            for (int i = 0; i < n; i++) {
                double a = i * 2 * Math.PI / Math.max(1, n);
                mc.world.addParticle(new DustParticleEffect(rgb, 1.0f),
                        p.getX() + Math.cos(a) * 0.4, p.getY() + 0.1, p.getZ() + Math.sin(a) * 0.4, Math.cos(a) * 0.1, 0.02, Math.sin(a) * 0.1);
                if (i % 4 == 0)
                    mc.world.addParticle(ParticleTypes.END_ROD, p.getX() + Math.cos(a) * 0.3, p.getY() + 0.1, p.getZ() + Math.sin(a) * 0.3, 0, 0.06, 0);
            }
        }
    }

    public static void renderWorld(WorldRenderContext ctx) {
        if (RINGS.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        MatrixStack ms = ctx.matrixStack();
        VertexConsumerProvider vcp = ctx.consumers();
        Camera cam = ctx.camera();
        if (ms == null || vcp == null || mc.world == null) return;
        long now = System.currentTimeMillis();
        RINGS.removeIf(r -> now - r.t0 > 1200);
        if (RINGS.isEmpty()) return;
        Vec3d c = cam.getPos();
        if (Config.animThirdOnly && !cam.isThirdPerson()) return;
        float k0 = Config.jumpSize / 100f;
        int col = Draw.color(Config.jumpColor, now / 20f);
        ms.push();
        ms.translate(-c.x, -c.y, -c.z);
        Draw.begin(vcp, ms.peek().getPositionMatrix());
        for (Ring r : RINGS) {
            float life = (now - r.t0) / 1000f;
            float fade = MathHelper.clamp(1f - life / 1.1f, 0f, 1f);
            float k = k0 * r.sz;
            float rad = (0.35f + life * 2.2f) * k;
            ms.push();
            ms.translate(r.x, r.y, r.z);
            Draw.mat = ms.peek().getPositionMatrix();
            Draw.ring(0.03f, rad, rad + 0.10f * k, 48, col, 0.95f * fade, 0.95f * fade);
            Draw.wall(0.03f, rad, 0.30f * k * (0.4f + fade * 0.6f), 48, col, 0.6f * fade, 0f, 3);
            ms.pop();
        }
        Draw.end();
        ms.pop();
    }

    // ---------- эффекты зельев (список справа/слева) ----------
    static String roman(int n) {
        String[] r = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        return n >= 1 && n < r.length ? r[n] : String.valueOf(n);
    }

    public static void effects(DrawContext c, MinecraftClient mc, int sw, int sh) {
        if (!Config.effectsHud || mc.player == null) return;
        List<net.minecraft.entity.effect.StatusEffectInstance> list = new ArrayList<>(mc.player.getStatusEffects());
        if (list.isEmpty()) return;
        TextRenderer tr = mc.textRenderer;
        int w = 112, rowH = 20, h = list.size() * rowH + 4;
        int[] pos = place(Config.effectsPos, w, h, sw, sh);
        if (Config.effectsPos == 0) pos[1] = 30;
        Ui.round(c, pos[0], pos[1], w, h, 6, 0x99101418);
        int y = pos[1] + 4;
        for (net.minecraft.entity.effect.StatusEffectInstance e : list) {
            net.minecraft.entity.effect.StatusEffect fx = e.getEffectType().value();
            int col = 0xFF000000 | (fx.getColor() & 0xFFFFFF);
            String name = fx.getName().getString();
            c.fill(pos[0] + 4, y, pos[0] + 20, y + 16, col);
            c.fill(pos[0] + 5, y + 1, pos[0] + 19, y + 15, 0x66000000);
            c.drawCenteredTextWithShadow(tr, name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(), pos[0] + 12, y + 4, 0xFFFFFFFF);
            String nm = name.length() > 12 ? name.substring(0, 11) + "…" : name;
            c.drawTextWithShadow(tr, nm + " " + roman(e.getAmplifier() + 1), pos[0] + 24, y, 0xFFFFFFFF);
            int d = e.getDuration();
            String tm = e.isInfinite() ? "∞" : (d / 20 / 60) + ":" + String.format("%02d", d / 20 % 60);
            c.drawText(tr, tm, pos[0] + 24, y + 9, d < 200 && !e.isInfinite() ? 0xFFFF6060 : 0xFFB0B0B0, false);
            y += rowH;
        }
    }

    // ---------- прочность брони вокруг прицела ----------
    public static void armor(DrawContext c, MinecraftClient mc, int sw, int sh) {
        if (!Config.armorHud || mc.player == null) return;
        net.minecraft.entity.EquipmentSlot[] slots = {net.minecraft.entity.EquipmentSlot.HEAD, net.minecraft.entity.EquipmentSlot.CHEST,
                net.minecraft.entity.EquipmentSlot.LEGS, net.minecraft.entity.EquipmentSlot.FEET};
        float k = Config.armorScale / 100f;
        int cx = sw / 2, cy = sh / 2;
        TextRenderer tr = mc.textRenderer;
        for (int i = 0; i < 4; i++) {
            net.minecraft.item.ItemStack st = mc.player.getEquippedStack(slots[i]);
            if (st.isEmpty()) continue;
            boolean left = i < 2;
            int row = i % 2;
            float gx = left ? cx - Config.armorGap * k - 16 * k : cx + Config.armorGap * k;
            float gy = cy - 18 * k + row * 20 * k;
            c.getMatrices().push();
            c.getMatrices().translate(gx, gy, 0);
            c.getMatrices().scale(k, k, 1f);
            c.drawItem(st, 0, 0);
            if (st.getMaxDamage() > 0) {
                int left2 = st.getMaxDamage() - st.getDamage();
                float f = left2 / (float) st.getMaxDamage();
                int col = f > 0.6f ? 0xFF60FF60 : f > 0.3f ? 0xFFFFD040 : 0xFFFF5050;
                String t = String.valueOf(left2);
                int tx = left ? -2 - tr.getWidth(t) : 18;
                c.drawTextWithShadow(tr, t, tx, 4, col);
            }
            c.getMatrices().pop();
        }
    }
}
