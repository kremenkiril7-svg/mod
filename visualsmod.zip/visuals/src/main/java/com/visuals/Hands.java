package com.visuals;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.resource.ResourcePackManager;
import net.minecraft.resource.ResourcePackProfile;
import net.minecraft.util.Identifier;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

// Скины и положение в руке для каждого меча / кирки / топора...
// Мод сам собирает ресурспак из твоих настроек (перекрашивает текстуры игры) и перезагружает ресурсы.
public class Hands {
    public static final String[] TOOLS = {"Меч", "Кирка", "Топор", "Лопата", "Мотыга"};
    static final String[] TOOL_IDS = {"sword", "pickaxe", "axe", "shovel", "hoe"};
    public static final String[] MATS = {"Дерево", "Камень", "Железо", "Золото", "Алмаз", "Незерит"};
    static final String[] MAT_IDS = {"wooden", "stone", "iron", "golden", "diamond", "netherite"};
    public static final String[] SKINS = {"Обычный", "Красный", "Оранжевый", "Жёлтый", "Лайм", "Зелёный", "Бирюзовый", "Голубой",
            "Синий", "Фиолетовый", "Розовый", "Тёмный", "Золотой", "Радужный", "Светящийся"};
    static final int[] HUES = {0, 0, 25, 55, 90, 130, 170, 200, 225, 275, 320};

    public static class Cfg {
        public int skin = 0;
        public boolean voxel = false;
        public int tx = 0, ty = 0, tz = 0;      // сдвиг, десятые доли
        public int rx = 0, ry = 0, rz = 0;      // поворот, градусы
        public int sc = 100;                    // размер, %

        boolean isDefault() { return skin == 0 && !voxel && tx == 0 && ty == 0 && tz == 0 && rx == 0 && ry == 0 && rz == 0 && sc == 100; }

        void reset() { skin = 0; voxel = false; tx = ty = tz = rx = ry = rz = 0; sc = 100; }
    }

    static final Map<String, Cfg> CFG = new LinkedHashMap<>();
    public static String status = "";

    public static String itemId(int tool, int mat) { return MAT_IDS[mat] + "_" + TOOL_IDS[tool]; }

    public static Cfg cfg(String id) { return CFG.computeIfAbsent(id, k -> new Cfg()); }

    static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("limozut_items.json"); }

    public static void load() {
        try {
            if (!Files.exists(file())) return;
            JsonObject root = JsonParser.parseString(Files.readString(file())).getAsJsonObject();
            for (var e : root.entrySet()) {
                JsonObject o = e.getValue().getAsJsonObject();
                Cfg c = new Cfg();
                c.skin = o.get("skin").getAsInt();
                c.voxel = o.get("voxel").getAsBoolean();
                c.tx = o.get("tx").getAsInt(); c.ty = o.get("ty").getAsInt(); c.tz = o.get("tz").getAsInt();
                c.rx = o.get("rx").getAsInt(); c.ry = o.get("ry").getAsInt(); c.rz = o.get("rz").getAsInt();
                c.sc = o.get("sc").getAsInt();
                CFG.put(e.getKey(), c);
            }
        } catch (Throwable ignored) {}
    }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            for (var e : CFG.entrySet()) {
                Cfg c = e.getValue();
                if (c.isDefault()) continue;
                JsonObject o = new JsonObject();
                o.addProperty("skin", c.skin); o.addProperty("voxel", c.voxel);
                o.addProperty("tx", c.tx); o.addProperty("ty", c.ty); o.addProperty("tz", c.tz);
                o.addProperty("rx", c.rx); o.addProperty("ry", c.ry); o.addProperty("rz", c.rz);
                o.addProperty("sc", c.sc);
                root.add(e.getKey(), o);
            }
            Files.writeString(file(), root.toString());
        } catch (Throwable ignored) {}
    }

    public static void reset(String id) { cfg(id).reset(); }

    // ---------- перекраска ----------
    static float[] hsv(float r, float g, float b) {
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min, h = 0;
        if (d > 0) {
            if (max == r) h = ((g - b) / d) % 6; else if (max == g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
            h *= 60;
            if (h < 0) h += 360;
        }
        return new float[]{h, max == 0 ? 0 : d / max, max};
    }

    static int rgb(float h, float s, float v) {
        float c = v * s, hp = (((h % 360) + 360) % 360) / 60f, x = c * (1 - Math.abs(hp % 2 - 1)), r = 0, g = 0, b = 0;
        switch ((int) hp) {
            case 0 -> { r = c; g = x; }
            case 1 -> { r = x; g = c; }
            case 2 -> { g = c; b = x; }
            case 3 -> { g = x; b = c; }
            case 4 -> { r = x; b = c; }
            default -> { r = c; b = x; }
        }
        float m = v - c;
        int R = Math.round((r + m) * 255), G = Math.round((g + m) * 255), B = Math.round((b + m) * 255);
        return (Math.max(0, Math.min(255, R)) << 16) | (Math.max(0, Math.min(255, G)) << 8) | Math.max(0, Math.min(255, B));
    }

    static int tint(int argb, int skin, int x, int y) {
        int a = argb >>> 24;
        if (a == 0 || skin == 0) return argb;
        float[] c = hsv(((argb >> 16) & 255) / 255f, ((argb >> 8) & 255) / 255f, (argb & 255) / 255f);
        int out;
        if (skin <= 10) out = rgb(HUES[skin], Math.max(c[1], 0.6f), Math.max(c[2], 0.3f));
        else if (skin == 11) out = rgb(c[0], c[1] * 0.5f, c[2] * 0.35f);
        else if (skin == 12) out = rgb(45, Math.max(0.75f, c[1]), Math.min(1f, c[2] * 1.1f + 0.1f));
        else if (skin == 13) out = rgb((x + y) * 14f, 0.8f, Math.max(c[2], 0.45f));
        else out = rgb(c[0], c[1] * 0.45f, Math.min(1f, c[2] * 1.3f + 0.25f));
        return (a << 24) | out;
    }

    // ---------- модель ----------
    static JsonArray arr(float a, float b, float c) {
        JsonArray j = new JsonArray();
        j.add(a); j.add(b); j.add(c);
        return j;
    }

    static JsonObject tr(float[] rot, float[] pos, float sc) {
        JsonObject o = new JsonObject();
        o.add("rotation", arr(rot[0], rot[1], rot[2]));
        o.add("translation", arr(pos[0], pos[1], pos[2]));
        o.add("scale", arr(sc, sc, sc));
        return o;
    }

    static float clampT(float v) { return Math.max(-80f, Math.min(80f, v)); }

    static JsonObject display(Cfg c, boolean voxel) {
        JsonObject d = new JsonObject();
        float k = c.sc / 100f;
        float dx = c.tx / 10f, dy = c.ty / 10f, dz = c.tz / 10f;
        // правая рука: от 1-го и 3-го лица (база как у ванильных инструментов)
        d.add("firstperson_righthand", tr(new float[]{c.rx, -90 + c.ry, 25 + c.rz}, new float[]{clampT(1.13f + dx), clampT(3.2f + dy), clampT(1.13f + dz)}, 0.68f * k));
        d.add("firstperson_lefthand", tr(new float[]{c.rx, 90 - c.ry, -25 - c.rz}, new float[]{clampT(1.13f - dx), clampT(3.2f + dy), clampT(1.13f + dz)}, 0.68f * k));
        d.add("thirdperson_righthand", tr(new float[]{c.rx, -90 + c.ry, 55 + c.rz}, new float[]{clampT(dx), clampT(4f + dy), clampT(0.5f + dz)}, 0.85f * k));
        d.add("thirdperson_lefthand", tr(new float[]{c.rx, 90 - c.ry, -55 - c.rz}, new float[]{clampT(-dx), clampT(4f + dy), clampT(0.5f + dz)}, 0.85f * k));
        if (voxel) {
            d.add("gui", tr(new float[]{25, -40, 0}, new float[]{0, 0, 0}, 0.85f));
            d.add("ground", tr(new float[]{0, 0, 0}, new float[]{0, 2, 0}, 0.5f));
            d.add("fixed", tr(new float[]{0, 180, 0}, new float[]{0, 0, 0}, 1f));
        }
        return d;
    }

    static JsonObject voxelModel(NativeImage img, String tex, Cfg c) {
        JsonObject m = new JsonObject();
        JsonObject texs = new JsonObject();
        texs.addProperty("p", tex);
        texs.addProperty("particle", tex);
        m.add("textures", texs);
        m.addProperty("gui_light", "front");
        JsonArray els = new JsonArray();
        int w = img.getWidth(), h = img.getHeight();
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                if ((img.getColorArgb(x, y) >>> 24) == 0) continue;
                JsonObject e = new JsonObject();
                e.add("from", arr(x, 15 - y, 6.5f));
                e.add("to", arr(x + 1, 16 - y, 9.5f));
                JsonObject faces = new JsonObject();
                for (String f : new String[]{"north", "south", "east", "west", "up", "down"}) {
                    JsonObject face = new JsonObject();
                    JsonArray uv = new JsonArray();
                    uv.add(x); uv.add(y); uv.add(x + 1); uv.add(y + 1);
                    face.add("uv", uv);
                    face.addProperty("texture", "#p");
                    faces.add(f, face);
                }
                e.add("faces", faces);
                els.add(e);
            }
        m.add("elements", els);
        m.add("display", display(c, true));
        return m;
    }

    static void put(ZipOutputStream zo, String name, byte[] data) throws java.io.IOException {
        zo.putNextEntry(new ZipEntry(name));
        zo.write(data);
        zo.closeEntry();
    }

    static void put(ZipOutputStream zo, String name, String text) throws java.io.IOException {
        put(zo, name, text.getBytes(StandardCharsets.UTF_8));
    }

    // ---------- сборка пака и перезагрузка ----------
    public static void apply() {
        MinecraftClient mc = MinecraftClient.getInstance();
        save();
        try {
            Path rp = FabricLoader.getInstance().getGameDir().resolve("resourcepacks");
            Files.createDirectories(rp);
            List<String> items = new ArrayList<>();
            for (var e : CFG.entrySet()) if (!e.getValue().isDefault()) items.add(e.getKey());
            String name = "limozut_hands_" + System.currentTimeMillis() + ".zip";
            if (!items.isEmpty()) {
                try (ZipOutputStream zo = new ZipOutputStream(Files.newOutputStream(rp.resolve(name)))) {
                    put(zo, "pack.mcmeta", "{\"pack\":{\"pack_format\":46,\"description\":\"Limozut hands\"}}");
                    for (String id : items) {
                        Cfg c = CFG.get(id);
                        String tex = "visuals:item/hand_" + id;
                        JsonObject model;
                        NativeImage img = null;
                        if (c.skin != 0 || c.voxel) {
                            try (InputStream in = mc.getResourceManager().getResource(Identifier.of("minecraft", "textures/item/" + id + ".png")).get().getInputStream()) {
                                img = NativeImage.read(in);
                            }
                            for (int y = 0; y < img.getHeight(); y++)
                                for (int x = 0; x < img.getWidth(); x++) img.setColorArgb(x, y, tint(img.getColorArgb(x, y), c.skin, x, y));
                            put(zo, "assets/visuals/textures/item/hand_" + id + ".png", img.getBytes());
                        }
                        if (c.voxel && img != null) model = voxelModel(img, tex, c);
                        else {
                            model = new JsonObject();
                            model.addProperty("parent", "minecraft:item/handheld");
                            JsonObject t = new JsonObject();
                            t.addProperty("layer0", img != null ? tex : "minecraft:item/" + id);
                            model.add("textures", t);
                            model.add("display", display(c, false));
                        }
                        if (img != null) img.close();
                        put(zo, "assets/visuals/models/item/hand_" + id + ".json", model.toString());
                        put(zo, "assets/minecraft/items/" + id + ".json",
                                "{\"model\":{\"type\":\"minecraft:model\",\"model\":\"visuals:item/hand_" + id + "\"}}");
                    }
                }
            }
            ResourcePackManager m = mc.getResourcePackManager();
            m.scanPacks();
            List<String> ids = new ArrayList<>(m.getEnabledIds());
            ids.removeIf(s -> s.contains("limozut_hands_"));
            if (!items.isEmpty()) ids.add("file/" + name);
            m.setEnabledProfiles(ids);
            mc.options.resourcePacks.clear();
            for (ResourcePackProfile p : m.getEnabledProfiles()) if (!p.isPinned()) mc.options.resourcePacks.add(p.getId());
            mc.options.write();
            status = items.isEmpty() ? "Всё по умолчанию, перезагружаю..." : "Применяю (" + items.size() + " предм.)...";
            mc.reloadResources();
            try (var st = Files.list(rp)) {        // старые наборы удаляем
                for (Path p : (Iterable<Path>) st::iterator) {
                    String fn = p.getFileName().toString();
                    if (fn.startsWith("limozut_hands_") && !fn.equals(name)) try { Files.deleteIfExists(p); } catch (Throwable ignored) {}
                }
            }
        } catch (Throwable t) {
            status = "Ошибка: " + t.getClass().getSimpleName();
        }
    }
}
