package com.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

// «Остров»: пилюля FPS, при событии/наведении плавно разворачивается в плеер
public class Island {
    static float anim = 0f;
    static long last = System.nanoTime();
    static long expandUntil = 0;
    static final int PILL_W = 150, PILL_H = 16, BIG_W = 260, BIG_H = 66;

    public static void expand() { expandUntil = System.currentTimeMillis() + 5000; }

    static int SH = 0;

    public static int[] rect(int sw) {
        int w = (int) (PILL_W + (BIG_W - PILL_W) * anim), h = (int) (PILL_H + (BIG_H - PILL_H) * anim);
        int[] p = Fun.place(Config.fpsPos, w, h, sw, SH > 0 ? SH : 240);
        return new int[]{p[0], p[1], w, h};
    }

    static int[] ctrl(int[] r, int i) { return new int[]{r[0] + 104 + i * 30, r[1] + 40, 22, 13}; }

    static String clip(String s, int n) { return s.length() > n ? s.substring(0, n - 1) + "…" : s; }

    static String time(int sec) { return (sec / 60) + ":" + String.format("%02d", sec % 60); }

    public static boolean click(int sw, double mx, double my) {
        SH = MinecraftClient.getInstance().getWindow().getScaledHeight();
        int[] r = rect(sw);
        boolean inside = mx >= r[0] && mx < r[0] + r[2] && my >= r[1] && my < r[1] + r[3];
        if (!inside) return false;
        if (anim > 0.7f) {
            for (int i = 0; i < 3; i++) {
                int[] b = ctrl(r, i);
                if (mx >= b[0] && mx < b[0] + b[2] && my >= b[1] && my < b[1] + b[3]) {
                    if (i == 0) Songs.prev(); else if (i == 1) Songs.toggle(); else Songs.next();
                    expand();
                    return true;
                }
            }
        }
        expand();
        return true;
    }

    public static void render(DrawContext c, MinecraftClient mc, int sw, int mx, int my, boolean interactive) {
        SH = mc.getWindow().getScaledHeight();
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;
        if (interactive) {
            int[] r0 = rect(sw);
            if (mx >= r0[0] && mx < r0[0] + r0[2] && my >= r0[1] && my < r0[1] + r0[3]) expand();
        }
        float target = System.currentTimeMillis() < expandUntil ? 1f : 0f;
        anim += (target - anim) * Math.min(1f, dt * 9f);
        int[] r = rect(sw);
        int x = r[0], y = r[1], w = r[2], h = r[3];
        Ui.round(c, x, y, w, h, (int) (8 + 4 * anim), 0xF2101418);
        TextRenderer tr = mc.textRenderer;
        Songs.Track t = Songs.current();
        c.drawTextWithShadow(tr, Config.fpsShow ? mc.getCurrentFps() + " FPS" : "Visuals", x + 8, y + 4, 0xFFFFFFFF);
        String right = Songs.playing && t != null ? clip(t.name(), 14) : "Local";
        c.drawTextWithShadow(tr, right, x + w - 8 - tr.getWidth(right), y + 4, 0xFFB0B0B0);

        if (anim > 0.55f) {
            int alpha = (int) (255 * (anim - 0.55f) / 0.45f);
            if (alpha < 12) return;
            int white = (alpha << 24) | 0xFFFFFF, gray = (alpha << 24) | 0xB0B0B0;
            c.fillGradient(x + 8, y + 20, x + 42, y + 54, (alpha << 24) | 0x1FB6A6, (alpha << 24) | 0xB0245A);
            c.drawCenteredTextWithShadow(tr, "♪", x + 25, y + 33, white);
            String title = t != null ? clip(t.name(), 18) : "Ничего не играет";
            c.drawTextWithShadow(tr, title, x + 50, y + 20, white);
            c.drawText(tr, t != null ? clip(t.artist(), 20) : "Выбери песню", x + 50, y + 31, gray, false);
            String[] icons = {"|<", Songs.playing ? "||" : ">", ">|"};
            for (int i = 0; i < 3; i++) {
                int[] b = ctrl(r, i);
                c.drawCenteredTextWithShadow(tr, icons[i], b[0] + b[2] / 2, b[1] + 3, white);
            }
            int el = Songs.elapsedSec(), dur = t != null ? t.dur() : 0;
            c.fill(x + 8, y + h - 12, x + w - 8, y + h - 10, (alpha / 4 << 24) | 0xFFFFFF);
            if (dur > 0) {
                int fw = (int) ((w - 16) * Math.min(1f, el / (float) dur));
                c.fill(x + 8, y + h - 12, x + 8 + fw, y + h - 10, white);
            }
            c.drawText(tr, time(el), x + 8, y + h - 9, gray, false);
            String end = dur > 0 ? time(dur) : "--:--";
            c.drawText(tr, end, x + w - 8 - tr.getWidth(end), y + h - 9, gray, false);
        }
    }
}
