package com.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

// Текст песни на экране. Ищется сам (lrclib.net) и кэшируется в visuals_songs/lyrics.
// Свой файл тоже можно положить в visuals_songs:
//   <название>.lrc  — с таймкодами [мм:сс.xx] (синхронно)
//   <название>.txt  — просто текст, строки равномерно растягиваются на длину песни
public class Lyrics {
    record Line(long ms, String text) {}

    static volatile List<Line> lines = List.of();
    public static volatile String status = "Нет текста";
    static int lastIdx = -1;
    static long since = 0;
    static final Pattern TS = Pattern.compile("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?]");

    static String decode(byte[] b) {
        String s = new String(b, StandardCharsets.UTF_8);
        if (s.indexOf('�') >= 0) s = new String(b, Charset.forName("windows-1251"));
        return s.startsWith("﻿") ? s.substring(1) : s;
    }

    static volatile int gen = 0;
    static Songs.Track curTrack;

    static String safe(String n) { return n.replaceAll("[^\\p{L}\\p{N} _-]", "_"); }

    static Path cacheDir() { return Songs.songsDir().resolve("lyrics"); }

    static Path findLocal(String base) {
        String b = base.toLowerCase(Locale.ROOT);
        for (Path dir : new Path[]{Songs.songsDir(), cacheDir()}) {
            for (String ext : new String[]{".lrc", ".txt"}) {
                try (var st = Files.list(dir)) {
                    for (Path p : (Iterable<Path>) st::iterator) {
                        if (p.getFileName().toString().toLowerCase(Locale.ROOT).equals(b + ext)) return p;
                    }
                } catch (IOException ignored) {}
            }
        }
        return null;
    }

    public static void load(Songs.Track t) {
        lines = List.of();
        lastIdx = -1;
        curTrack = t;
        int my = ++gen;
        status = "Нет текста";
        if (t == null) return;
        Path f = findLocal(t.name());
        if (f == null) f = findLocal(safe(t.artist() + " - " + t.name()));
        if (f != null) {
            try { parse(decode(Files.readAllBytes(f)), t, my); return; } catch (Throwable e) { status = "Ошибка текста"; }
        }
        if (Config.lyricsAuto) fetch(t, my); else status = "Нет текста (включи авто-поиск)";
    }

    // «Найти текст» вручную: забыть сохранённый и скачать заново
    public static void refetch() {
        Songs.Track t = curTrack != null ? curTrack : Songs.current();
        if (t == null) { status = "Сначала включи песню"; return; }
        try {
            Files.deleteIfExists(cacheDir().resolve(safe(t.artist() + " - " + t.name()) + ".lrc"));
            Files.deleteIfExists(cacheDir().resolve(safe(t.artist() + " - " + t.name()) + ".txt"));
        } catch (IOException ignored) {}
        curTrack = t;
        fetch(t, ++gen);
    }

    static void fetch(Songs.Track t, int my) {
        status = "Ищу текст в интернете...";
        Thread th = new Thread(() -> {
            try {
                String res = search(t, true);
                if (res == null) res = search(t, false);
                if (my != gen) return;
                if (res == null) { status = "Текст не найден (можно положить .lrc в visuals_songs)"; return; }
                try {
                    Files.createDirectories(cacheDir());
                    String ext = TS.matcher(res).find() ? ".lrc" : ".txt";
                    Files.writeString(cacheDir().resolve(safe(t.artist() + " - " + t.name()) + ext), res);
                } catch (IOException ignored) {}
                parse(res, t, my);
            } catch (Throwable e) {
                if (my == gen) status = "Нет интернета / сервис недоступен";
            }
        }, "visuals-lyrics");
        th.setDaemon(true);
        th.start();
    }

    // lrclib.net: бесплатная база текстов с таймкодами
    static String search(Songs.Track t, boolean withArtist) throws Exception {
        String q = (withArtist && !t.artist().equals("Свой файл") ? t.artist() + " " : "") + t.name();
        java.net.URL u = new java.net.URL("https://lrclib.net/api/search?q=" + java.net.URLEncoder.encode(q, StandardCharsets.UTF_8));
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) u.openConnection();
        c.setRequestProperty("User-Agent", "VisualsMod/1.7 (Minecraft Fabric mod)");
        c.setConnectTimeout(8000);
        c.setReadTimeout(10000);
        if (c.getResponseCode() != 200) return null;
        String body;
        try (var in = c.getInputStream()) { body = new String(in.readAllBytes(), StandardCharsets.UTF_8); }
        com.google.gson.JsonArray arr = com.google.gson.JsonParser.parseString(body).getAsJsonArray();
        String best = null, bestPlain = null;
        double bestDiff = 1e9;
        for (com.google.gson.JsonElement e : arr) {
            com.google.gson.JsonObject o = e.getAsJsonObject();
            double d = o.has("duration") && !o.get("duration").isJsonNull() ? o.get("duration").getAsDouble() : 0;
            double diff = t.dur() > 0 && d > 0 ? Math.abs(d - t.dur()) : 30;
            String syn = o.has("syncedLyrics") && !o.get("syncedLyrics").isJsonNull() ? o.get("syncedLyrics").getAsString() : "";
            String pl = o.has("plainLyrics") && !o.get("plainLyrics").isJsonNull() ? o.get("plainLyrics").getAsString() : "";
            if (!syn.isBlank() && diff < bestDiff) { best = syn; bestDiff = diff; }
            if (bestPlain == null && !pl.isBlank()) bestPlain = pl;
        }
        return best != null ? best : bestPlain;
    }

    static void parse(String text, Songs.Track t, int my) {
        try {
            List<Line> out = new ArrayList<>();
            boolean timed = false;
            List<String> plain = new ArrayList<>();
            for (String raw : text.split("\\r?\\n")) {
                String ln = raw.trim();
                if (ln.isEmpty()) continue;
                Matcher m = TS.matcher(ln);
                List<Long> times = new ArrayList<>();
                int end = 0;
                while (m.find() && m.start() == end) {
                    long mm = Long.parseLong(m.group(1)), ss = Long.parseLong(m.group(2));
                    String fr = m.group(3);
                    long ms = fr == null ? 0 : Long.parseLong((fr + "00").substring(0, 3));
                    times.add(mm * 60000 + ss * 1000 + ms);
                    end = m.end();
                }
                String body = ln.substring(end).trim();
                if (!times.isEmpty()) {
                    timed = true;
                    for (long tm : times) out.add(new Line(tm, body));
                } else if (!ln.startsWith("[")) {
                    plain.add(ln);
                }
            }
            if (!timed) {
                if (t.dur() <= 0 || plain.isEmpty()) { if (my == gen) status = "Текст без таймкодов: нужна длина песни"; return; }
                long total = t.dur() * 1000L;
                long start = total / 25, span = total * 9 / 10;
                for (int i = 0; i < plain.size(); i++) out.add(new Line(start + span * i / plain.size(), plain.get(i)));
            }
            out.sort(Comparator.comparingLong(Line::ms));
            if (my != gen) return;
            lines = out;
            status = "Текст: " + out.size() + " строк" + (timed ? " (синхронно)" : " (растянут)");
        } catch (Throwable e) {
            if (my == gen) status = "Ошибка текста: " + e.getClass().getSimpleName();
        }
    }

    public static int count() { return lines.size(); }

    public static void render(DrawContext c, MinecraftClient mc, int sw, int sh) {
        if (!Config.lyrics || !Songs.playing || lines.isEmpty()) return;
        long el = Songs.elapsedMs() + Config.lyricsOffset;
        int idx = -1;
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).ms() <= el) idx = i; else break;
        }
        if (idx < 0) return;
        long now = System.currentTimeMillis();
        if (idx != lastIdx) { lastIdx = idx; since = now; }
        float a = MathHelper.clamp((now - since) / 220f, 0f, 1f);
        TextRenderer tr = mc.textRenderer;
        int cx = sw / 2;
        int cy = Config.lyricsPos == 0 ? sh - 86 : Config.lyricsPos == 1 ? sh / 2 + 50 : 40;
        float s = Config.lyricsSize / 100f;
        for (int d = -1; d <= 1; d++) {
            int i = idx + d;
            if (i < 0 || i >= lines.size()) continue;
            String txt = lines.get(i).text();
            if (txt.isEmpty()) continue;
            float sc = d == 0 ? s : s * 0.66f;
            int w = tr.getWidth(txt);
            if (w * sc > sw * 0.92f) sc = sw * 0.92f / w;
            int alpha = d == 0 ? (int) (255 * a) : (int) (130 * (d < 0 ? 1f - a * 0.3f : a));
            alpha = Math.max(5, alpha);
            float yy = cy + d * 15f * s + (d == 0 ? (1f - a) * 6f : 0f);
            c.getMatrices().push();
            c.getMatrices().translate(cx, yy, 0f);
            c.getMatrices().scale(sc, sc, 1f);
            if (d == 0) Ui.round(c, -w / 2 - 6, -3, w + 12, 15, 5, 0x66101418);
            c.drawTextWithShadow(tr, txt, -w / 2, 0, (alpha << 24) | (d == 0 ? 0xFFFFFF : 0xC8C8C8));
            c.getMatrices().pop();
        }
    }
}
