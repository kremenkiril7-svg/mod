package com.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

// Текст песни на экране. Файл лежит рядом с песней в minecraft/visuals_songs:
//   <название>.lrc  — с таймкодами [мм:сс.xx] (синхронно)
//   <название>.txt  — просто текст, строки равномерно растягиваются на длину песни
public class Lyrics {
    record Line(long ms, String text) {}

    static List<Line> lines = List.of();
    public static String status = "Нет текста";
    static int lastIdx = -1;
    static long since = 0;
    static final Pattern TS = Pattern.compile("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?]");

    static String decode(byte[] b) {
        String s = new String(b, StandardCharsets.UTF_8);
        if (s.indexOf('�') >= 0) s = new String(b, Charset.forName("windows-1251"));
        return s.startsWith("﻿") ? s.substring(1) : s;
    }

    static Path find(String base) {
        try (var st = Files.list(Songs.songsDir())) {
            for (Path p : (Iterable<Path>) st::iterator) {
                String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
                String b = base.toLowerCase(Locale.ROOT);
                if (n.equals(b + ".lrc")) return p;
            }
        } catch (IOException ignored) {}
        try (var st = Files.list(Songs.songsDir())) {
            for (Path p : (Iterable<Path>) st::iterator) {
                String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
                if (n.equals(base.toLowerCase(Locale.ROOT) + ".txt")) return p;
            }
        } catch (IOException ignored) {}
        return null;
    }

    public static void load(Songs.Track t, int idx) {
        lines = List.of();
        lastIdx = -1;
        status = "Нет текста";
        if (t == null) return;
        try {
            Path f = find(t.name());
            if (f == null && idx >= 0 && idx < 3) f = find("song" + (idx + 1));
            if (f == null) { status = "Нет текста: положи \"" + t.name() + ".lrc\" в папку"; return; }
            String text = decode(Files.readAllBytes(f));
            List<Line> out = new ArrayList<>();
            boolean timed = false;
            List<String> plain = new ArrayList<>();
            for (String raw : text.split("\\r?\\n")) {
                String ln = raw.trim();
                if (ln.isEmpty()) continue;
                Matcher m = TS.matcher(ln);
                List<Long> times = new ArrayList<>();
                int end = 0;
                while (m.find() && m.start() == end) {
                    long mm = Long.parseLong(m.group(1)), ss = Long.parseLong(m.group(2));
                    String fr = m.group(3);
                    long ms = fr == null ? 0 : Long.parseLong((fr + "00").substring(0, 3));
                    times.add(mm * 60000 + ss * 1000 + ms);
                    end = m.end();
                }
                String body = ln.substring(end).trim();
                if (!times.isEmpty()) {
                    timed = true;
                    for (long tm : times) out.add(new Line(tm, body));
                } else if (!ln.startsWith("[")) {
                    plain.add(ln);
                }
            }
            if (!timed) {
                if (t.dur() <= 0 || plain.isEmpty()) { status = "Текст без таймкодов: нужна длина песни (.ogg)"; return; }
                long total = t.dur() * 1000L;
                long start = total / 25, span = total * 9 / 10;
                for (int i = 0; i < plain.size(); i++) out.add(new Line(start + span * i / plain.size(), plain.get(i)));
            }
            out.sort(Comparator.comparingLong(Line::ms));
            lines = out;
            status = "Текст: " + out.size() + " строк" + (timed ? " (синхронно)" : " (растянут)");
        } catch (Throwable e) {
            status = "Ошибка текста: " + e.getClass().getSimpleName();
        }
    }

    public static int count() { return lines.size(); }

    public static void render(DrawContext c, MinecraftClient mc, int sw, int sh) {
        if (!Config.lyrics || !Songs.playing || lines.isEmpty()) return;
        long el = Songs.elapsedMs() + Config.lyricsOffset;
        int idx = -1;
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).ms() <= el) idx = i; else break;
        }
        if (idx < 0) return;
        long now = System.currentTimeMillis();
        if (idx != lastIdx) { lastIdx = idx; since = now; }
        float a = MathHelper.clamp((now - since) / 220f, 0f, 1f);
        TextRenderer tr = mc.textRenderer;
        int cx = sw / 2;
        int cy = Config.lyricsPos == 0 ? sh - 86 : Config.lyricsPos == 1 ? sh / 2 + 50 : 40;
        float s = Config.lyricsSize / 100f;
        for (int d = -1; d <= 1; d++) {
            int i = idx + d;
            if (i < 0 || i >= lines.size()) continue;
            String txt = lines.get(i).text();
            if (txt.isEmpty()) continue;
            float sc = d == 0 ? s : s * 0.66f;
            int w = tr.getWidth(txt);
            if (w * sc > sw * 0.92f) sc = sw * 0.92f / w;
            int alpha = d == 0 ? (int) (255 * a) : (int) (130 * (d < 0 ? 1f - a * 0.3f : a));
            alpha = Math.max(5, alpha);
            float yy = cy + d * 15f * s + (d == 0 ? (1f - a) * 6f : 0f);
            c.getMatrices().push();
            c.getMatrices().translate(cx, yy, 0f);
            c.getMatrices().scale(sc, sc, 1f);
            if (d == 0) Ui.round(c, -w / 2 - 6, -3, w + 12, 15, 5, 0x66101418);
            c.drawTextWithShadow(tr, txt, -w / 2, 0, (alpha << 24) | (d == 0 ? 0xFFFFFF : 0xC8C8C8));
            c.getMatrices().pop();
        }
    }
}
