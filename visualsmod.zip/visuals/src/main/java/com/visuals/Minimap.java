package com.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Heightmap;

// Мини-карта: север сверху, красные точки — игроки, белая — ты (с линией взгляда).
public class Minimap {
    static final int G = 28;
    static final int[] GRID = new int[G * G];
    static double cacheX, cacheZ;
    static int cacheRange = -1;
    static long last = 0;
    static boolean have = false;

    static void refresh(ClientWorld w, double px, double pz, int range) {
        cacheX = px; cacheZ = pz; cacheRange = range;
        double step = 2.0 * range / G;
        BlockPos.Mutable bp = new BlockPos.Mutable();
        for (int j = 0; j < G; j++)
            for (int i = 0; i < G; i++) {
                int wx = MathHelper.floor(px + (i - G / 2 + 0.5) * step);
                int wz = MathHelper.floor(pz + (j - G / 2 + 0.5) * step);
                if (w.getChunkManager().getWorldChunk(wx >> 4, wz >> 4) == null) { GRID[j * G + i] = 0; continue; }
                int y = w.getTopY(Heightmap.Type.WORLD_SURFACE, wx, wz) - 1;
                bp.set(wx, y, wz);
                int col = w.getBlockState(bp).getMapColor(w, bp).color;
                if (col == 0) { GRID[j * G + i] = 0; continue; }
                float sh = MathHelper.clamp(0.75f + (y - 64) / 160f, 0.55f, 1.15f);
                int r = Math.min(255, (int) (((col >> 16) & 255) * sh));
                int g = Math.min(255, (int) (((col >> 8) & 255) * sh));
                int b = Math.min(255, (int) ((col & 255) * sh));
                GRID[j * G + i] = 0xFF000000 | (r << 16) | (g << 8) | b;
            }
        have = true;
    }

    public static void draw(DrawContext c, MinecraftClient mc, int sw, int sh) {
        if (!Config.mapOn || mc.world == null || mc.player == null) return;
        int s = Config.mapSize, range = Config.mapRange;
        int[] p = Fun.place(Config.mapPos, s, s, sw, sh);
        int x = p[0], y = p[1];
        double px = mc.player.getX(), pz = mc.player.getZ();
        long now = System.currentTimeMillis();
        if (Config.mapTerrain && (!have || range != cacheRange || now - last > 1000)) {
            last = now;
            refresh(mc.world, px, pz, range);
        }
        c.fill(x - 1, y - 1, x + s + 1, y + s + 1, 0xFF000000);
        c.fill(x, y, x + s, y + s, 0xFF1A1826);
        c.enableScissor(x, y, x + s, y + s);
        double half = s / 2.0, k = half / range;
        if (Config.mapTerrain && have) {
            double step = 2.0 * cacheRange / G;
            double cell = step * (s / (2.0 * range));
            double offX = (cacheX - px) * k, offY = (cacheZ - pz) * k;
            for (int j = 0; j < G; j++)
                for (int i = 0; i < G; i++) {
                    int col = GRID[j * G + i];
                    if (col == 0) continue;
                    int x0 = (int) Math.floor(x + half + offX + (i - G / 2) * cell);
                    int y0 = (int) Math.floor(y + half + offY + (j - G / 2) * cell);
                    int x1 = (int) Math.floor(x + half + offX + (i - G / 2 + 1) * cell);
                    int y1 = (int) Math.floor(y + half + offY + (j - G / 2 + 1) * cell);
                    c.fill(x0, y0, Math.max(x1, x0 + 1), Math.max(y1, y0 + 1), col);
                }
        }
        // крест
        c.fill(x, y + s / 2, x + s, y + s / 2 + 1, 0x33FFFFFF);
        c.fill(x + s / 2, y, x + s / 2 + 1, y + s, 0x33FFFFFF);
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || !(e instanceof LivingEntity)) continue;
            boolean pl = e instanceof PlayerEntity;
            if (!pl && !Config.mapMobs) continue;
            double dx = (e.getX() - px) * k, dz = (e.getZ() - pz) * k;
            double m = Math.max(Math.abs(dx), Math.abs(dz));
            if (m > half - 3) { if (!pl) continue; double f = (half - 3) / m; dx *= f; dz *= f; }   // игроков прижимаем к краю
            int col = pl ? (Cheats.invisIds.contains(e.getId()) ? 0xFFFFD040 : 0xFFFF2A2A) : 0xFF40D070;
            int ex = (int) (x + half + dx), ey = (int) (y + half + dz);
            int r = pl ? 2 : 1;
            c.fill(ex - r, ey - r, ex + r + 1, ey + r + 1, col);
        }
        // ты + направление взгляда
        int mx = x + s / 2, my = y + s / 2;
        double yaw = Math.toRadians(mc.player.getYaw());
        int fx = (int) (mx - Math.sin(yaw) * 7), fy = (int) (my + Math.cos(yaw) * 7);
        for (int t = 1; t <= 6; t++)
            c.fill((int) (mx - Math.sin(yaw) * t), (int) (my + Math.cos(yaw) * t), (int) (mx - Math.sin(yaw) * t) + 1, (int) (my + Math.cos(yaw) * t) + 1, 0xFFFFFFFF);
        c.fill(mx - 2, my - 2, mx + 3, my + 3, 0xFFFFFFFF);
        c.fill(mx - 1, my - 1, mx + 2, my + 2, 0xFF3A7BFF);
        c.disableScissor();
        c.drawText(mc.textRenderer, "N", x + s / 2 - 2, y + 2, 0xFFFFFFFF, true);
    }
}
