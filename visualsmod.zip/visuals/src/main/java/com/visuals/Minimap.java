package com.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Heightmap;

// Мини-карта: север сверху, красные точки — игроки, белая — ты (с линией взгляда).
public class Minimap {
    static final int G = 48;
    static final int[] GRID = new int[G * G];
    static double cacheX, cacheZ;
    static int cacheRange = -1;
    static long last = 0;
    static boolean have = false;

    static void refresh(ClientWorld w, double px, double pz, int range) {
        cacheX = px; cacheZ = pz; cacheRange = range;
        double step = 2.0 * range / G;
        BlockPos.Mutable bp = new BlockPos.Mutable();
        for (int j = 0; j < G; j++)
            for (int i = 0; i < G; i++) {
                int wx = MathHelper.floor(px + (i - G / 2 + 0.5) * step);
                int wz = MathHelper.floor(pz + (j - G / 2 + 0.5) * step);
                if (w.getChunkManager().getWorldChunk(wx >> 4, wz >> 4) == null) { GRID[j * G + i] = 0; continue; }
                int y = w.getTopY(Heightmap.Type.WORLD_SURFACE, wx, wz) - 1;
                bp.set(wx, y, wz);
                int col = w.getBlockState(bp).getMapColor(w, bp).color;
                if (col == 0) { GRID[j * G + i] = 0; continue; }
                int yw = w.getTopY(Heightmap.Type.WORLD_SURFACE, wx - 1, wz) - 1;
                float sh = MathHelper.clamp(0.85f + (y - yw) * 0.12f + (y - 64) / 400f, 0.5f, 1.25f);
                int r = Math.min(255, (int) (((col >> 16) & 255) * sh));
                int g = Math.min(255, (int) (((col >> 8) & 255) * sh));
                int b = Math.min(255, (int) ((col & 255) * sh));
                GRID[j * G + i] = 0xFF000000 | (r << 16) | (g << 8) | b;
            }
        have = true;
    }

    public static void draw(DrawContext c, MinecraftClient mc, int sw, int sh) {
        if (!Config.mapOn || mc.world == null || mc.player == null) return;
        int s = Config.mapSize, range = Config.mapRange;
        int[] p = Fun.place(Config.mapPos, s, s, sw, sh);
        int x = p[0], y = p[1];
        double px = mc.player.getX(), pz = mc.player.getZ();
        long now = System.currentTimeMillis();
        if (Config.mapTerrain && (!have || range != cacheRange || now - last > 500)) {
            last = now;
            refresh(mc.world, px, pz, range);
        }
        c.fill(x - 2, y - 2, x + s + 2, y + s + 2, 0xFF000000);
        c.fill(x - 1, y - 1, x + s + 1, y + s + 1, 0xFF8A86A8);
        c.fill(x, y, x + s, y + s, 0xFF15131F);
        c.enableScissor(x, y, x + s, y + s);
        double half = s / 2.0, k = half / range;
        float rot = Config.mapRotate ? (float) (-mc.player.getYaw() - 180) : 0f;
        c.getMatrices().push();
        c.getMatrices().translate((float) (x + half), (float) (y + half), 0f);
        c.getMatrices().multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Z.rotationDegrees(rot));
        if (Config.mapTerrain && have) {
            double step = 2.0 * cacheRange / G;
            double cell = step * k;
            double offX = (cacheX - px) * k, offY = (cacheZ - pz) * k;
            for (int j = 0; j < G; j++)
                for (int i = 0; i < G; i++) {
                    int col = GRID[j * G + i];
                    if (col == 0) continue;
                    int x0 = (int) Math.floor(offX + (i - G / 2) * cell);
                    int y0 = (int) Math.floor(offY + (j - G / 2) * cell);
                    int x1 = (int) Math.floor(offX + (i - G / 2 + 1) * cell);
                    int y1 = (int) Math.floor(offY + (j - G / 2 + 1) * cell);
                    c.fill(x0, y0, Math.max(x1, x0 + 1), Math.max(y1, y0 + 1), col);
                }
        }
        // кольца расстояния
        for (int r = 1; r <= 2; r++) {
            int rr = (int) (half * r / 2.0) - 1;
            for (int a = 0; a < 48; a++) {
                double t = a * Math.PI / 24;
                c.fill((int) (Math.cos(t) * rr), (int) (Math.sin(t) * rr), (int) (Math.cos(t) * rr) + 1, (int) (Math.sin(t) * rr) + 1, 0x40FFFFFF);
            }
        }
        java.util.List<Object[]> labels = new java.util.ArrayList<>();
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || !(e instanceof LivingEntity)) continue;
            boolean pl = e instanceof PlayerEntity;
            if (!pl && !Config.mapMobs) continue;
            double dx = (e.getX() - px) * k, dz = (e.getZ() - pz) * k;
            double m = Math.hypot(dx, dz);
            boolean edge = false;
            if (m > half - 4) { if (!pl) continue; double f = (half - 4) / m; dx *= f; dz *= f; edge = true; }
            int col = pl ? (Cheats.invisIds.contains(e.getId()) ? 0xFFFFD040 : 0xFFFF2A2A) : (e instanceof net.minecraft.entity.mob.Monster ? 0xFFFF8A3A : 0xFF40D070);
            int ex = (int) dx, ey = (int) dz;
            int r = pl ? 3 : 2;
            c.fill(ex - r - 1, ey - r - 1, ex + r + 2, ey + r + 2, 0xFF000000);
            c.fill(ex - r, ey - r, ex + r + 1, ey + r + 1, col);
            if (pl && Config.mapNames) {
                double ang = Math.toRadians(rot);
                double sx = dx * Math.cos(ang) - dz * Math.sin(ang), sy = dx * Math.sin(ang) + dz * Math.cos(ang);
                labels.add(new Object[]{e.getName().getString() + (edge ? "" : " " + Math.round(mc.player.distanceTo(e)) + "м"), (int) (x + half + sx), (int) (y + half + sy)});
            }
        }
        // ты — стрелка (в режиме поворота всегда смотрит вверх)
        double yaw = Config.mapRotate ? Math.PI : Math.toRadians(mc.player.getYaw());
        for (int t = 1; t <= 8; t++) {
            int lx = (int) (-Math.sin(yaw) * t), ly = (int) (Math.cos(yaw) * t);
            c.fill(lx - 1, ly - 1, lx + 1, ly + 1, 0xFFFFFFFF);
        }
        c.fill(-3, -3, 4, 4, 0xFF000000);
        c.fill(-2, -2, 3, 3, 0xFF3A7BFF);
        c.getMatrices().pop();
        // север
        double na = Math.toRadians(rot);
        int nx = (int) (x + half + Math.sin(-na) * (half - 8) * 0), ny = y + 2;
        double ox = 0, oy = -(half - 7);
        nx = (int) (x + half + ox * Math.cos(na) - oy * Math.sin(na)) - 2;
        ny = (int) (y + half + ox * Math.sin(na) + oy * Math.cos(na)) - 4;
        c.drawText(mc.textRenderer, "N", nx, ny, 0xFFFF5050, true);
        for (Object[] l : labels) {
            String t = (String) l[0];
            int tx = MathHelper.clamp((Integer) l[1] - mc.textRenderer.getWidth(t) / 2, x + 1, x + s - mc.textRenderer.getWidth(t) - 1);
            int ty = MathHelper.clamp((Integer) l[2] + 5, y + 1, y + s - 9);
            c.drawText(mc.textRenderer, t, tx, ty, 0xFFFFFFFF, true);
        }
        c.disableScissor();
        if (Config.mapCoords)
            c.drawText(mc.textRenderer, mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ(), x + 2, y + s + 4, 0xFFFFFFFF, true);
    }
}
