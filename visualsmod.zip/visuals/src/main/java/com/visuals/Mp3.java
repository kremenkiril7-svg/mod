package com.visuals;

import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.Header;
import javazoom.jl.decoder.SampleBuffer;
import java.io.ByteArrayInputStream;
import java.util.Arrays;

// Декодер mp3 (библиотека JLayer). Отдельный класс: если библиотеки нет — упадёт только mp3.
class Mp3 {
    static Audio.Pcm decode(byte[] bytes) throws Exception {
        Bitstream bs = new Bitstream(new ByteArrayInputStream(bytes));
        Decoder dec = new Decoder();
        short[] out = new short[1 << 20];
        int n = 0, ch = 2, rate = 44100;
        Header h;
        while ((h = bs.readFrame()) != null) {
            SampleBuffer sb = (SampleBuffer) dec.decodeFrame(h, bs);
            short[] b = sb.getBuffer();
            int len = sb.getBufferLength();
            ch = sb.getChannelCount();
            rate = sb.getSampleFrequency();
            if (n + len > out.length) out = Arrays.copyOf(out, Math.max(out.length * 2, n + len));
            System.arraycopy(b, 0, out, n, len);
            n += len;
            bs.closeFrame();
        }
        Audio.Pcm p = new Audio.Pcm();
        p.data = Arrays.copyOf(out, n);
        p.ch = ch;
        p.rate = rate;
        return p;
    }
}
