package com.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.SimpleOption;

// Оптимизация FPS: пресеты настроек игры + авто-подстройка дальности под целевой FPS.
// Твои настройки сохраняются (Config.orig*) и возвращаются при выключении.
public class Opt {
    public static final String[] NAMES = {"Выкл", "Лёгкая", "Сильная", "Максимум"};
    public static final String[] SUBS = {"Твои настройки", "До 10, без теней", "До 7, быстрая графика", "До 5, минимум"};
    static final int MIN_VIEW = 4;
    public static String status = "";

    static boolean inited = false;
    static int tick = 0, filled = 0, hi = 0;
    static final int[] HIST = new int[5];
    static long lastChange = 0;

    // множитель количества частиц у наших эффектов
    public static float fx() {
        return switch (Config.optMode) { case 1 -> 0.7f; case 2 -> 0.5f; case 3 -> 0.3f; default -> 1f; };
    }

    // перечисления (частицы, облака, графика) читаем и ставим по номеру, без имён классов
    @SuppressWarnings({"unchecked", "rawtypes"})
    static int ord(SimpleOption opt) { return ((Enum) opt.getValue()).ordinal(); }

    @SuppressWarnings({"unchecked", "rawtypes"})
    static void setOrd(SimpleOption opt, int ordinal) {
        Object[] vals = ((Enum) opt.getValue()).getDeclaringClass().getEnumConstants();
        opt.setValue(vals[Math.max(0, Math.min(ordinal, vals.length - 1))]);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    static boolean getB(SimpleOption opt) { return Boolean.TRUE.equals(opt.getValue()); }

    @SuppressWarnings({"unchecked", "rawtypes"})
    static void setB(SimpleOption opt, boolean v) { opt.setValue(v); }

    static int cap(int mode) { return switch (mode) { case 1 -> 10; case 2 -> 7; case 3 -> 5; default -> 64; }; }

    static void saveOrig(MinecraftClient mc) {
        GameOptions o = mc.options;
        Config.origView = o.getViewDistance().getValue();
        Config.origSim = o.getSimulationDistance().getValue();
        Config.origEnt = (int) Math.round(o.getEntityDistanceScaling().getValue() * 100);
        Config.origParticles = ord(o.getParticles());
        Config.origClouds = ord(o.getCloudRenderMode());
        Config.origShadows = o.getEntityShadows().getValue() ? 1 : 0;
        Config.origAo = getB(o.getAo()) ? 1 : 0;
        Config.origGraphics = ord(o.getGraphicsMode());
        Config.origBlend = o.getBiomeBlendRadius().getValue();
        Config.origVsync = o.getEnableVsync().getValue() ? 1 : 0;
        Config.origMip = o.getMipmapLevels().getValue();
        Config.origSaved = true;
        Config.save();
    }

    static void restore(MinecraftClient mc) {
        if (!Config.origSaved) return;
        GameOptions o = mc.options;
        try {
            o.getViewDistance().setValue(Config.origView);
            o.getSimulationDistance().setValue(Config.origSim);
            o.getEntityDistanceScaling().setValue(Config.origEnt / 100.0);
            setOrd(o.getParticles(), Config.origParticles);
            setOrd(o.getCloudRenderMode(), Config.origClouds);
            o.getEntityShadows().setValue(Config.origShadows == 1);
            setB(o.getAo(), Config.origAo == 1);
            setOrd(o.getGraphicsMode(), Config.origGraphics);
            o.getBiomeBlendRadius().setValue(Config.origBlend);
            o.getEnableVsync().setValue(Config.origVsync == 1);
            o.getMipmapLevels().setValue(Config.origMip);
        } catch (Throwable ignored) {}
    }

    static void applyMode(MinecraftClient mc) {
        int m = Config.optMode;
        GameOptions o = mc.options;
        if (m == 0) { restore(mc); return; }
        try {
            o.getViewDistance().setValue(Math.min(Config.origView, cap(m)));
            o.getSimulationDistance().setValue(Math.min(Config.origSim, m == 1 ? 8 : m == 2 ? 6 : 5));
            o.getEntityDistanceScaling().setValue(m == 1 ? 0.75 : 0.5);
            setOrd(o.getParticles(), m == 1 ? 1 : 2);
            o.getEntityShadows().setValue(false);
            o.getEnableVsync().setValue(false);
            if (m >= 2) {
                o.getMipmapLevels().setValue(0);
                setOrd(o.getCloudRenderMode(), 0);
                setB(o.getAo(), false);
                setOrd(o.getGraphicsMode(), 0);
                o.getBiomeBlendRadius().setValue(1);
            } else if (ord(o.getGraphicsMode()) >= 2) {
                setOrd(o.getGraphicsMode(), 1);
            }
        } catch (Throwable ignored) {}
    }

    // вызывается при любом изменении настроек оптимизации в меню
    public static void refresh(MinecraftClient mc) {
        if (Config.optMode > 0 || Config.optAuto) {
            if (!Config.origSaved) saveOrig(mc);
            applyMode(mc);
        } else if (Config.origSaved) {
            restore(mc);
            Config.origSaved = false;
        }
        filled = 0;
        Config.save();
    }

    public static void setMode(MinecraftClient mc, int m) { Config.optMode = m; refresh(mc); }

    public static void tick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) return;
        if (!inited) { inited = true; refresh(mc); }
        if (!Config.optAuto) { status = ""; return; }
        if (mc.currentScreen != null) { filled = 0; return; }
        if (++tick % 20 != 0) return;
        HIST[hi] = mc.getCurrentFps();
        hi = (hi + 1) % HIST.length;
        if (filled < HIST.length) { filled++; if (filled < HIST.length) return; }
        int sum = 0;
        for (int v : HIST) sum += v;
        int avg = sum / HIST.length;
        long now = System.currentTimeMillis();
        int view = mc.options.getViewDistance().getValue();
        int top = Math.min(Config.origSaved ? Config.origView : 12, cap(Config.optMode));
        if (avg < Config.optTarget - 4 && now - lastChange > 4000) {
            if (view > MIN_VIEW) {
                mc.options.getViewDistance().setValue(view - 1);
                lastChange = now;
                filled = 0;
                status = "Авто: дальность " + (view - 1) + " (FPS " + avg + ")";
            } else {
                int sim = mc.options.getSimulationDistance().getValue();
                if (sim > 5) { mc.options.getSimulationDistance().setValue(sim - 1); lastChange = now; filled = 0; }
                status = "Мин. дальность. Для большего FPS поставь Sodium + Lithium";
            }
        } else if (avg > Config.optTarget + 35 && now - lastChange > 15000 && view < top) {
            mc.options.getViewDistance().setValue(view + 1);
            lastChange = now;
            filled = 0;
            status = "Авто: дальность " + (view + 1) + " (FPS " + avg + ")";
        }
    }
}
