package com.visuals;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Util;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.file.*;
import java.util.*;

// Плеер песен: свои файлы (ogg / mp3 / wav) выбираются прямо в игре, ресурспак не нужен.
public class Songs {
    public static class Track {
        public final String name, artist, res;
        public final Path file;
        public int dur;
        Track(String name, String artist, int dur, String res, Path file) {
            this.name = name; this.artist = artist; this.dur = dur; this.res = res; this.file = file;
        }
        public String name() { return name; }
        public String artist() { return artist; }
        public int dur() { return dur; }
    }

    public static final List<Track> TRACKS = new ArrayList<>();
    static final String[] N = {"Он гениален", "Лбтд", "Я тебя лю", "Ты любишь танцевать"};
    static final String[] A = {"Wokawona", "Кис-Кис", "Dabro", "CUPSIZE"};
    static final int[] D = {108, 176, 194, 145};
    static final int BUILTIN = 4, MAX_OWN = 60;

    public static int idx = -1;
    public static boolean playing = false;   // играет (не на паузе)
    static boolean loaded = false;           // трек загружен в плеер (играет или на паузе)
    static boolean loading = false;
    static Audio.Pcm pcm;
    static int gen = 0;
    static long baseMs = 0, baseAt = 0;
    public static String status = "";

    public static Path songsDir() { return FabricLoader.getInstance().getGameDir().resolve("visuals_songs"); }

    public static void register() {
        for (int i = 0; i < BUILTIN; i++) TRACKS.add(new Track(N[i], A[i], D[i], "/assets/visuals/sounds/song" + (i + 1) + ".mp3", null));
        rescan();
    }

    static boolean audio(String n) {
        n = n.toLowerCase();
        return n.endsWith(".ogg") || n.endsWith(".mp3") || n.endsWith(".wav");
    }

    public static void rescan() {
        while (TRACKS.size() > BUILTIN) TRACKS.remove(TRACKS.size() - 1);
        try {
            Files.createDirectories(songsDir());
            try (var st = Files.list(songsDir())) {
                List<Path> files = st.filter(p -> audio(p.getFileName().toString())).sorted().limit(MAX_OWN).toList();
                for (Path p : files) {
                    String n = p.getFileName().toString();
                    n = n.substring(0, n.lastIndexOf('.'));
                    String artist = "Свой файл";
                    int d = n.indexOf(" - ");
                    if (d > 0) { artist = n.substring(0, d).trim(); n = n.substring(d + 3).trim(); }
                    int dur = n.length() > 0 && p.toString().toLowerCase().endsWith(".ogg") ? oggDuration(p) : 0;
                    TRACKS.add(new Track(n, artist, dur, null, p));
                }
            }
        } catch (IOException ignored) {}
    }

    // длительность .ogg (Vorbis) в секундах: частота из заголовка, число сэмплов из последней страницы
    static int oggDuration(Path p) {
        try (RandomAccessFile f = new RandomAccessFile(p.toFile(), "r")) {
            long len = f.length();
            byte[] head = new byte[(int) Math.min(1024, len)];
            f.readFully(head);
            long rate = 0;
            for (int i = 0; i + 16 < head.length; i++) {
                if (head[i] == 1 && head[i + 1] == 'v' && head[i + 2] == 'o' && head[i + 3] == 'r'
                        && head[i + 4] == 'b' && head[i + 5] == 'i' && head[i + 6] == 's') {
                    rate = (head[i + 12] & 255L) | (head[i + 13] & 255L) << 8 | (head[i + 14] & 255L) << 16 | (head[i + 15] & 255L) << 24;
                    break;
                }
            }
            if (rate <= 0) return 0;
            int tail = (int) Math.min(70000, len);
            byte[] b = new byte[tail];
            f.seek(len - tail);
            f.readFully(b);
            for (int i = tail - 14; i >= 0; i--) {
                if (b[i] == 'O' && b[i + 1] == 'g' && b[i + 2] == 'g' && b[i + 3] == 'S') {
                    long gp = 0;
                    for (int k = 7; k >= 0; k--) gp = (gp << 8) | (b[i + 6 + k] & 255L);
                    return gp > 0 ? (int) (gp / rate) : 0;
                }
            }
        } catch (Throwable ignored) {}
        return 0;
    }

    public static Track current() { return idx >= 0 && idx < TRACKS.size() ? TRACKS.get(idx) : null; }

    public static long elapsedMs() {
        if (!loaded) return 0;
        return playing ? baseMs + (System.currentTimeMillis() - baseAt) : baseMs;
    }

    public static int elapsedSec() { return (int) (elapsedMs() / 1000); }

    static float gain() {
        float g = Math.max(0f, Config.musicVol / 100f);
        try { g *= MinecraftClient.getInstance().options.getSoundVolume(SoundCategory.MASTER); } catch (Throwable ignored) {}
        return g;
    }

    public static void play(int i) {
        if (i < 0 || i >= TRACKS.size()) return;
        stopOnly();
        idx = i;
        final Track t = TRACKS.get(i);
        final int my = ++gen;
        loading = true;
        status = "Загрузка: " + t.name;
        Thread th = new Thread(() -> {
            try {
                byte[] bytes;
                String fname;
                if (t.res != null) {
                    try (InputStream in = Songs.class.getResourceAsStream(t.res)) {
                        if (in == null) throw new IOException("нет файла");
                        bytes = in.readAllBytes();
                    }
                    fname = t.res;
                } else {
                    bytes = Files.readAllBytes(t.file);
                    fname = t.file.getFileName().toString();
                }
                Audio.log("decode " + fname + " bytes=" + bytes.length);
                Audio.Pcm p = Audio.decode(fname, bytes);
                Audio.log("decoded samples=" + p.data.length + " ch=" + p.ch + " rate=" + p.rate);
                MinecraftClient.getInstance().execute(() -> {
                    if (my != gen) return;
                    loading = false;
                    pcm = p;
                    if (p.seconds() > 0) t.dur = p.seconds();
                    if (!Audio.start(p, 0f, gain())) { status = "Нет звука (OpenAL не готов)"; return; }
                    loaded = true;
                    playing = true;
                    baseMs = 0;
                    baseAt = System.currentTimeMillis();
                    status = "Играет: " + t.name;
                    Lyrics.load(t);
                    Island.expand();
                });
            } catch (Throwable e) {
                MinecraftClient.getInstance().execute(() -> {
                    if (my != gen) return;
                    loading = false;
                    status = "Не открылось: " + e.getClass().getSimpleName() + (e instanceof NoClassDefFoundError ? " (mp3)" : "");
                });
            }
        }, "visuals-audio");
        th.setDaemon(true);
        th.start();
    }

    static void stopOnly() {
        gen++;
        loading = false;
        Audio.release();
        loaded = false;
        playing = false;
        pcm = null;
    }

    public static void stop() { stopOnly(); Island.expand(); }

    public static void toggle() {
        if (loading) return;
        if (playing) {
            baseMs = elapsedMs();
            Audio.pause();
            playing = false;
        } else if (loaded) {
            Audio.resume();
            baseAt = System.currentTimeMillis();
            playing = true;
        } else play(idx >= 0 ? idx : 0);
        Island.expand();
    }

    public static void next() { if (!TRACKS.isEmpty()) play(((idx < 0 ? -1 : idx) + 1) % TRACKS.size()); }

    public static void prev() { if (!TRACKS.isEmpty()) play(((idx <= 0 ? TRACKS.size() : idx) - 1) % TRACKS.size()); }

    public static void tick(MinecraftClient mc) {
        if (!loaded) return;
        if (!Audio.ready()) return; // идёт перезагрузка ресурсов — ждём
        int st = Audio.state();
        if (st == -1) { // звуковой движок пересоздан (перезагрузка ресурсов) — запускаем с того же места
            if (pcm != null && Audio.start(pcm, baseMs / 1000f, gain())) {
                if (!playing) Audio.pause();
                baseAt = System.currentTimeMillis();
            } else stop();
            return;
        }
        Audio.gain(gain());
        if (st == 1) {
            float off = Audio.offset();
            if (off >= 0) { baseMs = (long) (off * 1000); baseAt = System.currentTimeMillis(); }
        } else if (st == 0 && playing) {
            next();
        }
    }

    // добавить песню из любого места (выбор в игре)
    public static void addFromFile(Path p) {
        try {
            Files.createDirectories(songsDir());
            Path dst = songsDir().resolve(p.getFileName().toString());
            if (!dst.equals(p)) Files.copy(p, dst, StandardCopyOption.REPLACE_EXISTING);
            rescan();
            String n = dst.getFileName().toString();
            for (int i = BUILTIN; i < TRACKS.size(); i++)
                if (TRACKS.get(i).file != null && TRACKS.get(i).file.getFileName().toString().equals(n)) { play(i); return; }
            status = "Добавлено: " + n;
        } catch (Throwable t) {
            status = "Не удалось скопировать: " + t.getClass().getSimpleName();
        }
    }

    public static void openFolder() {
        try {
            Files.createDirectories(songsDir());
            Util.getOperatingSystem().open(songsDir().toUri());
        } catch (Throwable t) {
            status = "Папка: " + songsDir();
        }
    }

    // файлы, перетащенные в окно меню (на компьютере)
    public static void addFiles(MinecraftClient mc, List<Path> paths) {
        int ok = 0;
        try {
            Files.createDirectories(songsDir());
            for (Path p : paths) {
                String n = p.getFileName().toString(), l = n.toLowerCase();
                if (audio(l) || l.endsWith(".lrc") || l.endsWith(".txt")) {
                    Files.copy(p, songsDir().resolve(n), StandardCopyOption.REPLACE_EXISTING);
                    ok++;
                }
            }
        } catch (Throwable t) { status = "Ошибка копирования"; return; }
        rescan();
        status = ok > 0 ? "Добавлено файлов: " + ok : "Нужен .ogg / .mp3 / .wav";
    }
}
