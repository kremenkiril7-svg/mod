package com.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

public class Sounds {
    public static final String[] NAMES = {"Нет", "Луч света", "Падение человека", "Святой дух"};
    // 1 — твой mp3 (короткое замыкание), 2-12 — новые, 13-15 — ванильные звуки Minecraft
    public static final String[] HIT_NAMES = {"Нет", "Замыкание (моё)", "Удар", "Кристалл", "Монета", "Клинок", "Бас",
            "Лазер", "Поп", "Щелчок", "Барабан", "Колокольчик", "Бонк", "Опыт (MC)", "Дзынь (MC)", "Крит (MC)"};
    static SoundEvent[] EVENTS = new SoundEvent[4];
    static SoundEvent[] HITS = new SoundEvent[HIT_NAMES.length];
    static long lastHit = 0;

    public static void register() {
        String[] ids = {null, "beam", "fall", "holy"};
        for (int i = 1; i < 4; i++) {
            Identifier id = Identifier.of("visuals", ids[i]);
            EVENTS[i] = Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
        }
        for (int i = 1; i <= 12; i++) {
            Identifier id = Identifier.of("visuals", "hit" + i);
            HITS[i] = Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
        }
        HITS[13] = SoundEvent.of(Identifier.of("minecraft", "entity.experience_orb.pickup"));
        HITS[14] = SoundEvent.of(Identifier.of("minecraft", "entity.arrow.hit_player"));
        HITS[15] = SoundEvent.of(Identifier.of("minecraft", "entity.player.attack.crit"));
    }

    public static void play(int idx, ClientWorld w, Vec3d p) {
        if (idx <= 0 || idx > 3) return;
        w.playSound(p.x, p.y, p.z, EVENTS[idx], SoundCategory.PLAYERS, 1.5f, 1f, false);
    }

    public static void playHitIdx(int i) {
        if (i <= 0 || i >= HITS.length || HITS[i] == null) return;
        float vol = Math.max(0f, Config.hitVol / 100f);
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(HITS[i], 1.0f, vol));
    }

    public static void playHit() {
        long now = System.currentTimeMillis();
        if (now - lastHit < 60) return;
        lastHit = now;
        playHitIdx(Config.hitSound);
    }
}
