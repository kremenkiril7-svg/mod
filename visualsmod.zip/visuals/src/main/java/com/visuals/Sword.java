package com.visuals;

import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.ResourcePackActivationType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ResourcePackManager;
import net.minecraft.resource.ResourcePackProfile;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import java.util.*;

// Скины незеритового меча: встроенные ресурспаки мода, переключаются из меню
public class Sword {
    public static final String[] NAMES = {"Обычный", "Меч 1: тёмный", "Меч 2: ледяной", "Меч 3: золотой", "3D меч 1: фиолетовый", "3D меч 2: огненный"};
    public static final String[] SUBS = {"Как в игре", "Красная гарда", "Голубой клинок", "Золото и фиолет", "Объёмный клинок", "Толстый, горящий"};
    public static String status = "";

    public static void register() {
        FabricLoader.getInstance().getModContainer("visuals").ifPresent(mod -> {
            for (int i = 1; i <= 5; i++)
                ResourceManagerHelper.registerBuiltinResourcePack(Identifier.of("visuals", "sword_" + i), mod,
                        Text.literal("Visuals: " + NAMES[i]), ResourcePackActivationType.NORMAL);
        });
    }

    public static int current() {
        try {
            for (String id : MinecraftClient.getInstance().getResourcePackManager().getEnabledIds()) {
                int k = id.indexOf("sword_");
                if (k >= 0 && k + 6 < id.length() && Character.isDigit(id.charAt(k + 6))) return id.charAt(k + 6) - '0';
            }
        } catch (Throwable ignored) {}
        return 0;
    }

    public static void apply(int n) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (n == current()) return;
        try {
            ResourcePackManager m = mc.getResourcePackManager();
            m.scanPacks();
            List<String> ids = new ArrayList<>(m.getEnabledIds());
            ids.removeIf(s -> s.contains("sword_"));
            if (n > 0) {
                String target = null;
                for (String s : m.getIds()) if (s.contains("sword_" + n)) target = s;
                if (target == null) { status = "Набор меча не найден"; return; }
                ids.add(target);
            }
            m.setEnabledProfiles(ids);
            mc.options.resourcePacks.clear();
            for (ResourcePackProfile p : m.getEnabledProfiles()) if (!p.isPinned()) mc.options.resourcePacks.add(p.getId());
            mc.options.write();
            status = "Применяю: " + NAMES[n] + "...";
            mc.reloadResources();
        } catch (Throwable t) {
            status = "Ошибка: " + t.getClass().getSimpleName();
        }
    }
}
