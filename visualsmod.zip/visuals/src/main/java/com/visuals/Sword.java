package com.visuals;

import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.ResourcePackActivationType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ResourcePackManager;
import net.minecraft.resource.ResourcePackProfile;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import java.util.*;

// Скины незеритового меча: встроенные ресурспаки мода, переключаются из меню
public class Sword {
    public static final String[] NAMES = {"Обычный", "Меч 1: тёмный", "Меч 2: ледяной", "Меч 3: золотой", "3D меч 1: фиолетовый", "3D меч 2: огненный"};
    public static final String[] SUBS = {"Как в игре", "Красная гарда", "Голубой клинок", "Золото и фиолет", "Объёмный клинок", "Толстый, горящий"};
    public static String status = "";

    public static final String[] LAYOUTS = {"Обычная", "Выше", "Вбок"};
    public static final String[] LSUBS = {"Как в игре", "Меч выше в руке", "Наклон набок"};

    public static final String[] TOOLS = {"Меч", "Кирка", "Топор", "Лопата", "Мотыга"};
    static final String[] TOOL_IDS = {"sword", "pickaxe", "axe", "shovel", "hoe"};
    public static final String[] MATS = {"Дерево", "Камень", "Железо", "Золото", "Алмаз", "Незерит"};
    static final String[] MAT_IDS = {"wooden", "stone", "iron", "golden", "diamond", "netherite"};

    public static String itemId(int tool, int mat) { return MAT_IDS[mat] + "_" + TOOL_IDS[tool]; }

    public static boolean skinItem(int tool, int mat) { return tool == 0 && mat == 5; }

    // раскладка для любого инструмента (кроме незеритового меча — у него свои наборы со скинами)
    public static int posOf(String id) {
        try {
            for (String s : MinecraftClient.getInstance().getResourcePackManager().getEnabledIds()) {
                int k = s.indexOf("pos_" + id + "_");
                if (k >= 0) return s.charAt(s.length() - 1) - '0';
            }
        } catch (Throwable ignored) {}
        return 0;
    }

    public static void applyPos(String id, int l) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (l == posOf(id)) return;
        try {
            ResourcePackManager m = mc.getResourcePackManager();
            m.scanPacks();
            List<String> ids = new ArrayList<>(m.getEnabledIds());
            ids.removeIf(s -> s.contains("pos_" + id + "_"));
            if (l > 0) {
                String target = null;
                for (String s : m.getIds()) if (s.endsWith("pos_" + id + "_" + l)) target = s;
                if (target == null) { status = "Набор не найден"; return; }
                ids.add(target);
            }
            m.setEnabledProfiles(ids);
            mc.options.resourcePacks.clear();
            for (ResourcePackProfile p : m.getEnabledProfiles()) if (!p.isPinned()) mc.options.resourcePacks.add(p.getId());
            mc.options.write();
            status = "Применяю раскладку: " + LAYOUTS[l] + "...";
            mc.reloadResources();
        } catch (Throwable t) {
            status = "Ошибка: " + t.getClass().getSimpleName();
        }
    }

    public static void register() {
        FabricLoader.getInstance().getModContainer("visuals").ifPresent(mod -> {
            for (int n = 0; n <= 5; n++)
                for (int l = 0; l < 3; l++) {
                    if (n == 0 && l == 0) continue;
                    ResourceManagerHelper.registerBuiltinResourcePack(Identifier.of("visuals", "sword_" + n + "_" + l), mod,
                            Text.literal("Limozut: " + NAMES[n] + " / " + LAYOUTS[l]), ResourcePackActivationType.NORMAL);
                }
            for (int mt = 0; mt < 6; mt++)
                for (int tl = 0; tl < 5; tl++) {
                    if (mt == 5 && tl == 0) continue;
                    String id = itemId(tl, mt);
                    for (int l = 1; l <= 2; l++)
                        ResourceManagerHelper.registerBuiltinResourcePack(Identifier.of("visuals", "pos_" + id + "_" + l), mod,
                                Text.literal("Limozut: " + MATS[mt] + " " + TOOLS[tl] + " / " + LAYOUTS[l]), ResourcePackActivationType.NORMAL);
                }
        });
    }

    // {меч, раскладка} по включённым пакам
    static int[] cur() {
        try {
            for (String id : MinecraftClient.getInstance().getResourcePackManager().getEnabledIds()) {
                int k = id.indexOf("sword_");
                if (k >= 0 && k + 8 < id.length() && Character.isDigit(id.charAt(k + 6)) && Character.isDigit(id.charAt(k + 8)))
                    return new int[]{id.charAt(k + 6) - '0', id.charAt(k + 8) - '0'};
            }
        } catch (Throwable ignored) {}
        return new int[]{0, 0};
    }

    public static int current() { return cur()[0]; }

    public static int layout() { return cur()[1]; }

    public static void apply(int n, int l) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int[] c = cur();
        if (n == c[0] && l == c[1]) return;
        try {
            ResourcePackManager m = mc.getResourcePackManager();
            m.scanPacks();
            List<String> ids = new ArrayList<>(m.getEnabledIds());
            ids.removeIf(s -> s.contains("sword_"));
            if (n > 0 || l > 0) {
                String target = null;
                for (String s : m.getIds()) if (s.endsWith("sword_" + n + "_" + l)) target = s;
                if (target == null) { status = "Набор меча не найден"; return; }
                ids.add(target);
            }
            m.setEnabledProfiles(ids);
            mc.options.resourcePacks.clear();
            for (ResourcePackProfile p : m.getEnabledProfiles()) if (!p.isPinned()) mc.options.resourcePacks.add(p.getId());
            mc.options.write();
            status = "Применяю: " + NAMES[n] + ", " + LAYOUTS[l] + "...";
            mc.reloadResources();
        } catch (Throwable t) {
            status = "Ошибка: " + t.getClass().getSimpleName();
        }
    }
}
