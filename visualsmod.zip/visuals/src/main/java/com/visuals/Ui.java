package com.visuals;

import net.minecraft.client.gui.DrawContext;

// Оформление меню: 3 тёмные темы + «Старый» (красный) стиль
public class Ui {
    public static final String[] THEMES = {"Чёрный", "Приколный", "Красный", "Старый"};
    // фон, боковая панель, карточка, рамка, акцент, второй текст
    static final int[][] P = {
            {0xFF0B0A12, 0xFF0E0C17, 0xFF161329, 0xFF24203D, 0xFF8B6CFF, 0xFF8581A0},
            {0xFF140A24, 0xFF1B0E31, 0xFF28134A, 0xFF4F2D86, 0xFFFF4FD8, 0xFFC0A4E0},
            {0xFF140808, 0xFF1B0B0B, 0xFF281212, 0xFF4F1D1D, 0xFFE23030, 0xFFBF9090}};

    static boolean old() { return Config.theme >= 3 || Config.theme < 0; }

    static int[] p() { return P[Math.max(0, Math.min(Config.theme, 2))]; }

    public static int sub() { return old() ? 0xFFFFB0B0 : p()[5]; }

    public static int acc() { return old() ? 0xFFFF3A3A : p()[4]; }

    public static void panel(DrawContext c, int x, int y, int w, int h) {
        if (!old()) {
            round(c, x, y, w, h, 8, p()[0]);
            c.drawBorder(x, y, w, h, p()[3]);
            return;
        }
        c.fillGradient(x, y, x + w, y + h, 0xFFC41414, 0xFF6E0000);
        for (int yy = 0; yy < h && Config.optMode == 0; yy += 2) {
            int off = ((h - yy) % 44 + 44) % 44;
            for (int k = -1; k * 44 < w + 44; k++) {
                int xs = x + k * 44 + off, xe = xs + 12;
                int a = Math.max(xs, x), b = Math.min(xe, x + w);
                if (b > a) c.fill(a, y + yy, b, Math.min(y + yy + 2, y + h), 0x2EFFFFFF);
            }
        }
        c.drawBorder(x, y, w, h, 0xFF140000);
        c.drawBorder(x + 1, y + 1, w - 2, h - 2, 0xFFFF4A4A);
    }

    public static void sidebar(DrawContext c, int x, int y, int w, int h) {
        if (old()) c.fill(x + 2, y + 2, x + w, y + h - 2, 0x55000000);
        else c.fill(x + 1, y + 1, x + w, y + h - 1, p()[1]);
    }

    public static void slot(DrawContext c, int x, int y, int w, int h, boolean active) {
        if (!old()) {
            round(c, x, y, w, h, 5, active ? p()[4] : p()[2]);
            return;
        }
        c.fill(x, y, x + w, y + h, active ? 0xFF9A0000 : 0xFF4E0000);
        c.fill(x, y, x + w, y + 1, 0xFF1E0000);
        c.fill(x, y, x + 1, y + h, 0xFF1E0000);
        c.fill(x, y + h - 1, x + w, y + h, 0xFFFF7A7A);
        c.fill(x + w - 1, y, x + w, y + h, 0xFFFF7A7A);
    }

    // пункт боковой панели
    public static void tab(DrawContext c, int x, int y, int w, int h, boolean active) {
        if (old()) { if (active) slot(c, x, y, w, h, true); return; }
        if (active) round(c, x, y, w, h, 8, p()[4]);
    }

    // карточка (как в списке модулей)
    public static void card(DrawContext c, int x, int y, int w, int h, boolean on) {
        if (!old()) {
            round(c, x, y, w, h, 7, p()[2]);
            if (on) c.fill(x, y + 6, x + 2, y + h - 6, p()[4]);
        } else slot(c, x, y, w, h, on);
    }

    // скруглённый прямоугольник
    public static void round(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double d = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(Math.max(0, r * r - d * d)));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
        }
    }
}
