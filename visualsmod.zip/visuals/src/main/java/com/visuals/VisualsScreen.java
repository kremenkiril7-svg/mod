package com.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;

public class VisualsScreen extends Screen {
    static final int PW = 520, PH = 252;
    static final int T_COMBAT = 0, T_WORLD = 1, T_SOUNDS = 2, T_SONGS = 3, T_FUN = 4, T_CLOTHES = 5, T_SWORD = 6, T_FPS = 7, T_PROFILE = 8;
    static final String[] TABS = {"Бой", "Мир", "Звуки", "Песни", "Приколно", "Одежда", "Меч", "FPS", "Профиль"};
    static final String[] SUBTABS = {"Инфо", "FPS-панели", "Прыжок", "Текст", "Экран"};
    static final String[] NAMES = {"Наводка+атака", "Супер 1.8", "Килаура", "Авто-выбор", "Анти-отдача",
            "Авто-блок", "Полёт", "Скорость", "Рентген", "Ночное зрение", "Игроки (ESP)", "Инфо", "Авто-подбор"};
    static final String[] SUBS = {"Плавно, с КД 1.9", "Мгновенно, спам", "Бьёт без наводки", "Булава / топор", "Не толкает",
            "Блок в руке", "Пробел / Shift", "Быстрый бег", "Только руды", "Видно в темноте", "Квадрат, хп, броня", "Инвентарь, прочность", "Предметы рядом"};
    static final String[] LYR_POS = {"Снизу", "По центру", "Сверху"};

    record Hit(int x, int y, int w, int h, Runnable act, Sl sl) {}

    static class Sl {
        int x, w;
        double min, max;
        DoubleConsumer set;
    }

    int tab = 0, sub = 0, px, py, waiting = -1, age = 0, songScroll = 0;
    float scale = 1f;
    String nickMsg = "";
    TextFieldWidget nick;
    final List<Hit> hits = new ArrayList<>();
    Sl drag;

    public VisualsScreen() { super(Text.literal("Читы")); }

    @Override
    protected void init() {
        scale = Math.min(1f, Math.min((width - 6f) / PW, (height - 6f) / PH));
        px = (int) ((width / scale - PW) / 2);
        py = (int) ((height / scale - PH) / 2);
        nick = new TextFieldWidget(textRenderer, px + 10, py + 70, 200, 18, Text.literal(""));
        nick.setMaxLength(16);
        nick.setText(client.getSession().getUsername());
    }

    @Override public boolean shouldPause() { return false; }
    @Override public void tick() { age++; }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float d) {
        c.fill(0, 0, width, height, 0x88000000);
    }

    static String keyName(int k) {
        if (k < 0) return "—";
        String s = InputUtil.fromKeyCode(k, 0).getLocalizedText().getString();
        return s.length() > 8 ? s.substring(0, 8) : s;
    }

    static int cyc(int v, int n, int d) { return ((v + d) % n + n) % n; }

    static String clip(String s, int n) { return s.length() > n ? s.substring(0, n - 1) + "…" : s; }

    boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    // ---------- мини-виджеты (рисуем и сразу регистрируем клики) ----------
    void hit(int x, int y, int w, int h, Runnable a) { hits.add(new Hit(x, y, w, h, a, null)); }

    void text(DrawContext c, String s, int x, int y, int col) { c.drawText(textRenderer, s, x, y, col, false); }

    void button(DrawContext c, int x, int y, int w, int h, String label, boolean active, Runnable a) {
        Ui.slot(c, x, y, w, h, active);
        c.drawCenteredTextWithShadow(textRenderer, label, x + w / 2, y + (h - 8) / 2, 0xFFFFFFFF);
        hit(x, y, w, h, a);
    }

    void switchBox(DrawContext c, int x, int y, boolean on) {
        Ui.slot(c, x, y, 32, 14, on);
        int kn = on ? x + 18 : x + 2;
        c.fill(kn, y + 2, kn + 12, y + 12, 0xFFFFFFFF);
    }

    void toggle(DrawContext c, int x, int y, int w, int h, String label, boolean on, Runnable flip) {
        Ui.slot(c, x, y, w, h, false);
        c.drawTextWithShadow(textRenderer, label, x + 6, y + (h - 8) / 2, 0xFFFFFFFF);
        switchBox(c, x + w - 40, y + (h - 14) / 2, on);
        hit(x, y, w, h, flip);
    }

    void slider(DrawContext c, int x, int y, int w, String label, double v, double min, double max, DoubleConsumer set) {
        c.drawTextWithShadow(textRenderer, label, x, y, 0xFFFFFFFF);
        Ui.slot(c, x, y + 12, w, 8, false);
        int fw = (int) ((MathHelper.clamp(v, min, max) - min) / (max - min) * (w - 6));
        c.fill(x + 2, y + 14, x + 2 + fw, y + 18, 0xFFFF3A3A);
        c.fill(x + fw, y + 10, x + fw + 6, y + 22, 0xFFFFFFFF);
        Sl s = new Sl();
        s.x = x; s.w = w; s.min = min; s.max = max; s.set = set;
        hits.add(new Hit(x, y + 8, w, 20, null, s));
    }

    // выбор стрелками: change(-1) назад, change(1) вперёд, change(0) — клик по названию (прослушать)
    void selector(DrawContext c, int x, int y, int w, String label, String val, IntConsumer change) {
        Ui.slot(c, x, y, w, 36, false);
        text(c, label, x + 6, y + 4, 0xFFFFB0B0);
        c.drawCenteredTextWithShadow(textRenderer, val, x + w / 2, y + 19, 0xFFFFFFFF);
        hit(x + 24, y, w - 48, 36, () -> change.accept(0));
        Ui.slot(c, x + 4, y + 15, 18, 16, false);
        c.drawCenteredTextWithShadow(textRenderer, "<", x + 13, y + 19, 0xFFFFFFFF);
        hit(x + 4, y + 15, 18, 16, () -> change.accept(-1));
        Ui.slot(c, x + w - 22, y + 15, 18, 16, false);
        c.drawCenteredTextWithShadow(textRenderer, ">", x + w - 13, y + 19, 0xFFFFFFFF);
        hit(x + w - 22, y + 15, 18, 16, () -> change.accept(1));
    }

    void toggleRow(DrawContext c, int i, int x, int y, int w) {
        Ui.slot(c, x, y, w, 32, false);
        c.drawTextWithShadow(textRenderer, NAMES[i], x + 6, y + 5, 0xFFFFFFFF);
        text(c, SUBS[i], x + 6, y + 17, 0xFFFFB0B0);
        hit(x, y, w, 32, () -> Cheats.toggle(i));
        int kx = x + w - 98;
        boolean wait = waiting == i;
        Ui.slot(c, kx, y + 8, 54, 16, wait);
        c.drawCenteredTextWithShadow(textRenderer, wait ? "..." : keyName(Config.keys[i]), kx + 27, y + 12, 0xFFFFFFFF);
        hit(kx, y + 8, 54, 16, () -> waiting = i);
        switchBox(c, x + w - 40, y + 9, Cheats.get(i));
    }

    // ---------- отрисовка ----------
    @Override
    public void render(DrawContext c, int mx, int my, float d) {
        renderBackground(c, mx, my, d);
        hits.clear();
        c.getMatrices().push();
        c.getMatrices().scale(scale, scale, 1f);
        Ui.panel(c, px, py, PW, PH);
        c.drawTextWithShadow(textRenderer, "Настройки", px + 10, py + 6, 0xFFFFFFFF);
        text(c, "Настрой игру под себя!", px + 10, py + 17, 0xFFFFC0C0);
        for (int i = 0; i < TABS.length; i++) {
            int x = px + 10 + i * 56;
            final int ti = i;
            Ui.slot(c, x, py + 30, 54, 16, tab == i);
            c.drawCenteredTextWithShadow(textRenderer, TABS[i], x + 27, py + 34, 0xFFFFFFFF);
            hit(x, py + 30, 54, 16, () -> { tab = ti; waiting = -1; nick.setFocused(false); });
        }
        switch (tab) {
            case T_COMBAT -> renderCombat(c);
            case T_WORLD -> renderWorld(c);
            case T_SOUNDS -> renderSounds(c);
            case T_SONGS -> renderSongs(c);
            case T_FUN -> renderFun(c);
            case T_CLOTHES -> renderClothes(c);
            case T_SWORD -> renderSword(c);
            case T_FPS -> renderFps(c);
            default -> renderProfile(c, (int) (mx / scale), (int) (my / scale), d);
        }
        c.getMatrices().pop();
        if (Config.island) Island.render(c, client, width, mx, my, true);
    }

    void renderCombat(DrawContext c) {
        for (int i = 0; i < 5; i++) toggleRow(c, i, px + 10, py + 54 + i * 36, 244);
        int rx = px + 266;
        slider(c, rx, py + 54, 244, "Радиус удара: " + String.format("%.1f", Config.radius), Config.radius, 2.0, 6.0,
                v -> Config.radius = Math.round(v * 10) / 10f);
        slider(c, rx, py + 100, 244, "Скорость: " + Config.cps + " уд/сек", Config.cps, 1, 20, v -> Config.cps = (int) Math.round(v));
        toggle(c, rx, py + 134, 244, 24, "Килаура с перезарядкой 1.9", Config.auraCd, () -> Config.auraCd = !Config.auraCd);
        text(c, "Дальше ~4 блоков сервер удар", rx, py + 170, 0xFFFFB0B0);
        text(c, "не засчитывает (радиус для наводки).", rx, py + 181, 0xFFFFB0B0);
    }

    void renderWorld(DrawContext c) {
        for (int i = 5; i < 13; i++) {
            int j = i - 5;
            toggleRow(c, i, px + 10 + (j / 4) * 256, py + 54 + (j % 4) * 36, 244);
        }
        slider(c, px + 10, py + 204, 244, "Радиус авто-подбора: " + Config.pickupRadius + " бл.", Config.pickupRadius, 1, 16,
                v -> Config.pickupRadius = (int) Math.round(v));
        text(c, "Подбор работает в одиночном мире", px + 266, py + 208, 0xFFFFB0B0);
    }

    void renderSounds(DrawContext c) {
        int L = px + 10, R = px + 266, y0 = py + 54;
        selector(c, L, y0, 244, "Звук смерти моба", Sounds.NAMES[Config.mobSound], d -> {
            if (d != 0) Config.mobSound = cyc(Config.mobSound, 4, d);
            previewSound(Config.mobSound);
        });
        selector(c, R, y0, 244, "Анимация смерти моба", Anims.NAMES[Config.mobAnim], d -> {
            if (d != 0) Config.mobAnim = cyc(Config.mobAnim, Anims.NAMES.length, d);
            previewAnim(Config.mobAnim);
        });
        selector(c, L, y0 + 42, 244, "Звук смерти игрока", Sounds.NAMES[Config.playerSound], d -> {
            if (d != 0) Config.playerSound = cyc(Config.playerSound, 4, d);
            previewSound(Config.playerSound);
        });
        selector(c, R, y0 + 42, 244, "Анимация смерти игрока", Anims.NAMES[Config.playerAnim], d -> {
            if (d != 0) Config.playerAnim = cyc(Config.playerAnim, Anims.NAMES.length, d);
            previewAnim(Config.playerAnim);
        });
        int n = Sounds.HIT_NAMES.length;
        selector(c, L, y0 + 84, 244, "Звук удара (при ударе по мобу / игроку)", Sounds.HIT_NAMES[Config.hitSound], d -> {
            if (d != 0) Config.hitSound = cyc(Config.hitSound, n, d);
            Sounds.playHitIdx(Config.hitSound);
        });
        slider(c, R + 4, y0 + 90, 236, "Громкость удара: " + Config.hitVol + "%", Config.hitVol, 0, 200, v -> Config.hitVol = (int) Math.round(v));
        toggle(c, R, y0 + 120, 244, 24, "Анимации только для моих убийств", Config.animOnlyMine, () -> Config.animOnlyMine = !Config.animOnlyMine);
        text(c, "Стрелки — выбрать, клик по названию — послушать/посмотреть.", L, y0 + 134, 0xFFFFB0B0);
        text(c, "Звуки удара: 1 — твой mp3 (замыкание), 2-12 — новые, (MC) — родные.", L, y0 + 150, 0xFFFFB0B0);
        text(c, "«Молния (как в игре)» — настоящая молния, без урона.", L, y0 + 162, 0xFFFFB0B0);
        text(c, "Звук играет и при ударе килаурой.", L, y0 + 174, 0xFFFFB0B0);
    }

    void renderSongs(DrawContext c) {
        int total = Songs.TRACKS.size();
        songScroll = MathHelper.clamp(songScroll, 0, Math.max(0, total - 6));
        for (int r = 0; r < 6; r++) {
            int i = songScroll + r, x = px + 10, y = py + 54 + r * 30;
            if (i < total) {
                Songs.Track t = Songs.TRACKS.get(i);
                boolean cur = Songs.playing && Songs.idx == i;
                Ui.slot(c, x, y, 244, 28, cur);
                c.drawTextWithShadow(textRenderer, (cur ? "▶ " : "♪ ") + clip(t.name(), 36), x + 6, y + 5, 0xFFFFFFFF);
                text(c, t.artist() + (t.dur() > 0 ? "  " + t.dur() / 60 + ":" + String.format("%02d", t.dur() % 60) : ""), x + 6, y + 16, 0xFFFFB0B0);
                final int fi = i;
                hit(x, y, 244, 28, () -> Songs.play(fi));
            } else {
                Ui.slot(c, x, y, 244, 28, false);
                text(c, "— пусто (свои песни) —", x + 6, y + 10, 0xFFAA6060);
            }
        }
        button(c, px + 10, py + 235, 40, 14, "▲", false, () -> songScroll = Math.max(0, songScroll - 6));
        button(c, px + 54, py + 235, 40, 14, "▼", false, () -> songScroll = Math.min(Math.max(0, total - 6), songScroll + 6));
        text(c, (songScroll + 1) + "-" + Math.min(total, songScroll + 6) + " из " + total, px + 100, py + 238, 0xFFFFB0B0);
        int rx = px + 266;
        toggle(c, rx, py + 54, 244, 24, "Анимация плеера (остров)", Config.island, () -> Config.island = !Config.island);
        String[] ic = {"|<", Songs.playing ? "||" : ">", ">|"};
        for (int i = 0; i < 3; i++) {
            final int fi = i;
            button(c, rx + i * 84, py + 82, 76, 20, ic[i], false, () -> { if (fi == 0) Songs.prev(); else if (fi == 1) Songs.toggle(); else Songs.next(); });
            boolean wait = waiting == 13 + i;
            Ui.slot(c, rx + i * 84, py + 105, 76, 14, wait);
            c.drawCenteredTextWithShadow(textRenderer, wait ? "..." : keyName(Config.keys[13 + i]), rx + i * 84 + 38, py + 108, 0xFFFFFFFF);
            hit(rx + i * 84, py + 105, 76, 14, () -> waiting = 13 + fi);
        }
        slider(c, rx, py + 122, 244, "Громкость песни: " + Config.musicVol + "%", Config.musicVol, 0, 200, v -> Config.musicVol = (int) Math.round(v));
        toggle(c, rx, py + 150, 244, 22, "Текст ищется сам (интернет)", Config.lyricsAuto, () -> Config.lyricsAuto = !Config.lyricsAuto);
        text(c, clip(Songs.playing ? Lyrics.status : "Текст: включи песню", 44), rx, py + 176, 0xFFFFFFFF);
        button(c, rx, py + 190, 120, 22, "Добавить песню", false, () -> client.setScreen(new FilePickScreen(this)));
        button(c, rx + 124, py + 190, 120, 22, "Найти текст", false, Lyrics::refetch);
        text(c, clip(Songs.status, 44), rx, py + 218, 0xFFFFE0E0);
        text(c, "Выбери любую песню (mp3 / ogg / wav) — без ресурспаков.", rx, py + 232, 0xFFFFB0B0);
    }

    void renderFun(DrawContext c) {
        for (int i = 0; i < SUBTABS.length; i++) {
            final int fi = i;
            button(c, px + 10 + i * 101, py + 54, 98, 16, SUBTABS[i], sub == i, () -> sub = fi);
        }
        int L = px + 10, R = px + 266, y0 = py + 78;
        switch (sub) {
            case 0 -> {
                toggle(c, L, y0, 244, 24, "Броня + прочность", Config.infoArmor, () -> Config.infoArmor = !Config.infoArmor);
                toggle(c, L, y0 + 27, 244, 24, "Инвентарь", Config.infoInv, () -> Config.infoInv = !Config.infoInv);
                toggle(c, L, y0 + 54, 244, 24, "Хотбар", Config.infoHotbar, () -> Config.infoHotbar = !Config.infoHotbar);
                toggle(c, L, y0 + 81, 244, 24, "Еда и здоровье", Config.infoFood, () -> Config.infoFood = !Config.infoFood);
                toggle(c, L, y0 + 108, 244, 24, "Прочность предмета в руке", Config.infoHand, () -> Config.infoHand = !Config.infoHand);
                toggle(c, L, y0 + 135, 244, 24, "Координаты", Config.infoCoords, () -> Config.infoCoords = !Config.infoCoords);
                selector(c, R, y0, 244, "Где показывать панель «Инфо»", Fun.CORNERS[Config.infoPos], d -> {
                    if (d != 0) Config.infoPos = cyc(Config.infoPos, 4, d);
                });
                slider(c, R, y0 + 46, 244, "Размер панели: " + Config.infoScale + "%", Config.infoScale, 50, 150, v -> Config.infoScale = (int) Math.round(v));
                toggle(c, R, y0 + 80, 244, 24, "Панель «Инфо» включена", Cheats.info, () -> Cheats.info = !Cheats.info);
                text(c, "Включи, чтобы увидеть панель на экране.", R, y0 + 112, 0xFFFFB0B0);
                text(c, "То же самое: вкладка «Мир» → Инфо.", R, y0 + 123, 0xFFFFB0B0);
            }
            case 1 -> {
                toggle(c, L, y0, 244, 24, "Остров (плеер + FPS)", Config.island, () -> Config.island = !Config.island);
                toggle(c, L, y0 + 27, 244, 24, "Показывать FPS в острове", Config.fpsShow, () -> Config.fpsShow = !Config.fpsShow);
                selector(c, L, y0 + 58, 244, "Где показывать остров с FPS", Fun.POS[Config.fpsPos], d -> {
                    if (d != 0) Config.fpsPos = cyc(Config.fpsPos, Fun.POS.length, d);
                });
                toggle(c, R, y0, 244, 24, "Панель FPS / TPS / пинг", Config.hudBar, () -> Config.hudBar = !Config.hudBar);
                selector(c, R, y0 + 31, 244, "Где показывать панель", Fun.POS[Config.barPos], d -> {
                    if (d != 0) Config.barPos = cyc(Config.barPos, Fun.POS.length, d);
                });
                text(c, "Остров разворачивается в плеер при клике.", R, y0 + 74, 0xFFFFB0B0);
                text(c, "Не ставь остров и панель в одно место.", R, y0 + 85, 0xFFFFB0B0);
            }
            case 2 -> {
                selector(c, L, y0, 244, "Анимация прыжка (кольца)", Fun.JUMP[Config.jumpFx], d -> {
                    if (d != 0) Config.jumpFx = cyc(Config.jumpFx, Fun.JUMP.length, d);
                });
                selector(c, L, y0 + 42, 244, "Цвет колец", Draw.COLORS[Config.jumpColor], d -> {
                    if (d != 0) Config.jumpColor = cyc(Config.jumpColor, Draw.COLORS.length, d);
                });
                slider(c, R, y0, 244, "Размер колец: " + Config.jumpSize + "%", Config.jumpSize, 50, 250, v -> Config.jumpSize = (int) Math.round(v));
                toggle(c, R, y0 + 32, 244, 24, "Частицы вокруг игрока", Config.jumpParts, () -> Config.jumpParts = !Config.jumpParts);
                button(c, R, y0 + 62, 244, 24, "Показать пример", false, () -> {
                    if (client.player != null) Fun.ring(client, client.player);
                });
                text(c, "Кольца лучше видно от 3-го лица (F5).", R, y0 + 94, 0xFFFFB0B0);
            }
            case 3 -> {
                toggle(c, L, y0, 244, 24, "Текст песни на экране", Config.lyrics, () -> Config.lyrics = !Config.lyrics);
                toggle(c, L, y0 + 27, 244, 24, "Искать текст сам (интернет)", Config.lyricsAuto, () -> Config.lyricsAuto = !Config.lyricsAuto);
                selector(c, L, y0 + 58, 244, "Где показывать текст", LYR_POS[Config.lyricsPos], d -> {
                    if (d != 0) Config.lyricsPos = cyc(Config.lyricsPos, 3, d);
                });
                slider(c, R, y0, 244, "Размер текста: " + Config.lyricsSize + "%", Config.lyricsSize, 80, 300, v -> Config.lyricsSize = (int) Math.round(v));
                slider(c, R, y0 + 34, 244, "Сдвиг по времени: " + Config.lyricsOffset + " мс", Config.lyricsOffset, -5000, 5000,
                        v -> Config.lyricsOffset = (int) Math.round(v / 50.0) * 50);
                text(c, clip(Lyrics.status, 44), R, y0 + 68, 0xFFFFFFFF);
                button(c, R, y0 + 82, 244, 22, "Найти текст заново", false, Lyrics::refetch);
                text(c, "Текст сам находится по названию песни и", R, y0 + 112, 0xFFFFB0B0);
                text(c, "запоминается. Не совпал по времени — сдвиг.", R, y0 + 123, 0xFFFFB0B0);
            }
            default -> {
                toggle(c, L, y0, 244, 24, "Эффекты зелий (список)", Config.effectsHud, () -> Config.effectsHud = !Config.effectsHud);
                selector(c, L, y0 + 31, 244, "Где показывать эффекты", Fun.POS[Config.effectsPos], d -> {
                    if (d != 0) Config.effectsPos = cyc(Config.effectsPos, Fun.POS.length, d);
                });
                toggle(c, R, y0, 244, 24, "Броня вокруг прицела (прочность)", Config.armorHud, () -> Config.armorHud = !Config.armorHud);
                slider(c, R, y0 + 31, 244, "Расстояние от прицела: " + Config.armorGap, Config.armorGap, 10, 120, v -> Config.armorGap = (int) Math.round(v));
                slider(c, R, y0 + 65, 244, "Размер брони: " + Config.armorScale + "%", Config.armorScale, 50, 200, v -> Config.armorScale = (int) Math.round(v));
                text(c, "Слева шлем и нагрудник, справа штаны и ботинки.", L, y0 + 82, 0xFFFFB0B0);
                text(c, "Число — сколько прочности осталось.", L, y0 + 93, 0xFFFFB0B0);
            }
        }
    }

    void renderSword(DrawContext c) {
        int cur = Sword.current();
        for (int i = 0; i < Sword.NAMES.length; i++) {
            final int fi = i;
            int y = py + 54 + i * 31;
            Ui.slot(c, px + 10, y, 244, 28, cur == i);
            c.drawTextWithShadow(textRenderer, (cur == i ? "▶ " : "") + Sword.NAMES[i], px + 16, y + 5, 0xFFFFFFFF);
            text(c, Sword.SUBS[i], px + 16, y + 16, 0xFFFFB0B0);
            hit(px + 10, y, 244, 28, () -> Sword.apply(fi));
        }
        int rx = px + 266;
        Ui.slot(c, rx, py + 54, 244, 100, false);
        c.getMatrices().push();
        c.getMatrices().translate(rx + 122 - 40, py + 60, 0);
        c.getMatrices().scale(5f, 5f, 1f);
        c.drawItem(new ItemStack(Items.NETHERITE_SWORD), 0, 0);
        c.getMatrices().pop();
        button(c, rx, py + 158, 40, 20, "<", false, () -> Sword.apply((cur + Sword.NAMES.length - 1) % Sword.NAMES.length));
        button(c, rx + 204, py + 158, 40, 20, ">", false, () -> Sword.apply((cur + 1) % Sword.NAMES.length));
        c.drawCenteredTextWithShadow(textRenderer, Sword.NAMES[cur], rx + 122, py + 164, 0xFFFFFFFF);
        text(c, "Меняется только незеритовый меч.", rx, py + 182, 0xFFFFB0B0);
        text(c, "Выбрал — игра на пару секунд перезагрузит ресурсы.", rx, py + 193, 0xFFFFB0B0);
        text(c, "Стрелки < > листают мечи по кругу.", rx, py + 204, 0xFFFFB0B0);
        text(c, clip(Sword.status, 44), rx, py + 218, 0xFFFFE0E0);
    }

    void renderClothes(DrawContext c) {
        int L = px + 10, R = px + 266, y0 = py + 54;
        c.drawTextWithShadow(textRenderer, "Шляпа", L, y0, 0xFFFFFFFF);
        c.drawTextWithShadow(textRenderer, "Крылья", R, y0, 0xFFFFFFFF);
        selector(c, L, y0 + 12, 244, "Вид шляпы", Clothes.HATS[Config.hat], d -> {
            if (d != 0) Config.hat = cyc(Config.hat, Clothes.HATS.length, d);
        });
        selector(c, L, y0 + 52, 244, "Цвет шляпы", Draw.COLORS[Config.hatColor], d -> {
            if (d != 0) Config.hatColor = cyc(Config.hatColor, Draw.COLORS.length, d);
        });
        slider(c, L, y0 + 96, 244, "Размер шляпы: " + Config.hatSize + "%", Config.hatSize, 50, 200, v -> Config.hatSize = (int) Math.round(v));
        selector(c, R, y0 + 12, 244, "Вид крыльев", Clothes.WINGS[Config.wings], d -> {
            if (d != 0) Config.wings = cyc(Config.wings, Clothes.WINGS.length, d);
        });
        selector(c, R, y0 + 52, 244, "Цвет крыльев", Draw.COLORS[Config.wingColor], d -> {
            if (d != 0) Config.wingColor = cyc(Config.wingColor, Draw.COLORS.length, d);
        });
        slider(c, R, y0 + 96, 244, "Размер крыльев: " + Config.wingSize + "%", Config.wingSize, 50, 200, v -> Config.wingSize = (int) Math.round(v));
        slider(c, R, y0 + 130, 244, "Скорость взмахов: " + Config.wingSpeed + "%", Config.wingSpeed, 30, 250, v -> Config.wingSpeed = (int) Math.round(v));
        text(c, "Одежду видно от 3-го лица: нажми F5.", L, y0 + 134, 0xFFFFB0B0);
        text(c, "В воздухе крылья машут сильнее.", L, y0 + 145, 0xFFFFB0B0);
    }

    void renderFps(DrawContext c) {
        int y0 = py + 54;
        for (int i = 0; i < 4; i++) {
            final int fi = i;
            int x = px + 10 + i * 128;
            Ui.slot(c, x, y0, 122, 40, Config.optMode == i);
            c.drawCenteredTextWithShadow(textRenderer, Opt.NAMES[i], x + 61, y0 + 9, 0xFFFFFFFF);
            c.drawCenteredTextWithShadow(textRenderer, Opt.SUBS[i], x + 61, y0 + 24, 0xFFFFD0D0);
            hit(x, y0, 122, 40, () -> Opt.setMode(client, fi));
        }
        toggle(c, px + 10, y0 + 48, 244, 28, "Авто-подстройка под цель", Config.optAuto, () -> {
            Config.optAuto = !Config.optAuto;
            Opt.refresh(client);
        });
        slider(c, px + 10, y0 + 84, 244, "Цель: " + Config.optTarget + " FPS", Config.optTarget, 30, 144, v -> Config.optTarget = (int) Math.round(v / 5.0) * 5);
        int rx = px + 266;
        text(c, "FPS сейчас: " + client.getCurrentFps(), rx, y0 + 50, 0xFFFFFFFF);
        text(c, "Дальность прорисовки: " + client.options.getViewDistance().getValue()
                + (Config.origSaved ? "  (твоя: " + Config.origView + ")" : ""), rx, y0 + 62, 0xFFFFFFFF);
        text(c, "Дальность симуляции: " + client.options.getSimulationDistance().getValue(), rx, y0 + 74, 0xFFFFFFFF);
        text(c, clip(Opt.status.isEmpty() ? "Авто: ждёт данных (5 сек в игре)" : Opt.status, 44), rx, y0 + 86, 0xFFFFE0E0);
        text(c, "Пресеты: дальность, тени, частицы, облака, VSync, плавный свет.", px + 10, y0 + 124, 0xFFFFB0B0);
        text(c, "«Выкл» возвращает все твои настройки как были. Авто-режим сам", px + 10, y0 + 135, 0xFFFFB0B0);
        text(c, "снижает дальность, пока FPS ниже цели, и поднимает обратно.", px + 10, y0 + 146, 0xFFFFB0B0);
        text(c, "Сильнее всего поднимают FPS моды Sodium + Lithium (Modrinth).", px + 10, y0 + 162, 0xFFFFFFFF);
        text(c, "С Sodium «Рентген» не работает. В лаунчере: -Xmx4G (память Java).", px + 10, y0 + 173, 0xFFFFFFFF);
    }

    void renderProfile(DrawContext c, int mx, int my, float d) {
        c.drawTextWithShadow(textRenderer, "Ник в игре", px + 10, py + 56, 0xFFFFFFFF);
        nick.render(c, mx, my, d);
        button(c, px + 220, py + 69, 120, 20, "Сменить ник", false, () -> nickMsg = Nick.set(nick.getText().trim()));
        text(c, nickMsg, px + 10, py + 94, 0xFFFFE0E0);
        text(c, "Ник меняется сразу, без перезахода в лаунчер.", px + 10, py + 108, 0xFFFFB0B0);
        text(c, "Чтобы он применился в игре, перезайди в мир.", px + 10, py + 119, 0xFFFFB0B0);

        c.drawTextWithShadow(textRenderer, "Клавиша меню", px + 10, py + 148, 0xFFFFFFFF);
        boolean wm = waiting == 100;
        Ui.slot(c, px + 110, py + 144, 70, 16, wm);
        c.drawCenteredTextWithShadow(textRenderer, wm ? "..." : keyName(Config.keyMenu), px + 145, py + 148, 0xFFFFFFFF);
        hit(px + 110, py + 144, 70, 16, () -> waiting = 100);
        text(c, "Нажми на кнопку клавиши и жми нужную. Esc — убрать.", px + 10, py + 168, 0xFFFFB0B0);
    }

    // ---------- ввод ----------
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (tab == T_PROFILE && nick.isFocused()) {
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) { nickMsg = Nick.set(nick.getText().trim()); return true; }
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) { nick.setFocused(false); return true; }
            return nick.keyPressed(keyCode, scanCode, modifiers);
        }
        if (waiting != -1) {
            int val = keyCode == GLFW.GLFW_KEY_ESCAPE ? -1 : keyCode;
            if (waiting == 100) { if (val != -1) Config.keyMenu = val; }
            else Config.keys[waiting] = val;
            waiting = -1;
            Config.save();
            return true;
        }
        if (keyCode == Config.keyMenu && age > 6) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (tab == T_PROFILE && nick.isFocused()) return nick.charTyped(chr, modifiers);
        return super.charTyped(chr, modifiers);
    }

    void setSlider(Sl s, double mx) {
        double f = MathHelper.clamp((mx - s.x - 2) / (s.w - 6), 0, 1);
        s.set.accept(s.min + f * (s.max - s.min));
    }

    @Override
    public boolean mouseClicked(double rmx, double rmy, int b) {
        if (Config.island && Island.click(width, rmx, rmy)) return true;
        double mx = rmx / scale, my = rmy / scale;
        waiting = -1;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!in(mx, my, h.x(), h.y(), h.w(), h.h())) continue;
            if (h.sl() != null) { drag = h.sl(); setSlider(drag, mx); }
            else h.act().run();
            Config.save();
            return true;
        }
        if (tab == T_PROFILE) {
            boolean inside = in(mx, my, px + 10, py + 70, 200, 18);
            nick.setFocused(inside);
            if (inside) { nick.mouseClicked(mx, my, b); return true; }
        }
        return super.mouseClicked(rmx, rmy, b);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int b, double dx, double dy) {
        if (drag != null) { setSlider(drag, mx / scale); return true; }
        return super.mouseDragged(mx, my, b, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int b) {
        if (drag != null) { drag = null; Config.save(); return true; }
        return super.mouseReleased(mx, my, b);
    }

    // без @Override: если сигнатура в версии другая — просто не сработает, а не сломает сборку
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        if (tab == T_SONGS) {
            songScroll = Math.max(0, songScroll - (int) Math.signum(vAmount));
            return true;
        }
        return false;
    }

    public void onFilesDropped(List<Path> paths) { Songs.addFiles(client, paths); }

    public void filesDragged(List<Path> paths) { Songs.addFiles(client, paths); }

    void previewSound(int i) {
        if (client.world != null && client.player != null) Sounds.play(i, client.world, client.player.getPos());
    }

    void previewAnim(int i) {
        if (client.player == null) return;
        Vec3d look = client.player.getRotationVec(1f);
        Anims.play(i, client.player.getPos().add(look.x * 5, 0, look.z * 5));
    }
}
