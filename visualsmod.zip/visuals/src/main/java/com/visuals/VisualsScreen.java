package com.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;

// Меню Limozut: боковая панель + карточки, как на примере
public class VisualsScreen extends Screen {
    static final int PW = 690, PH = 250, SB = 150;
    static final int T_CHEATS = 0, T_SWORD = 1, T_SONGS = 2, T_SOUNDS = 3, T_ANIM = 4, T_CLOTHES = 5, T_FUN = 6, T_FPS = 7, T_PROFILE = 8;
    static final String[] TABS = {"Читы", "Мечи", "Песни", "Звуки", "Анимации", "Скин", "Приколное", "FPS", "Профиль"};
    static final String[] FUN_SUBS = {"Инфо", "FPS-панели", "Экран"};
    static final String[] SONG_SUBS = {"Песни", "Текст"};
    static final int NCHEATS = 15;
    static final String[] NAMES = {"Наводка+атака", "Супер 1.8", "Килаура", "Авто-выбор", "Анти-отдача",
            "Авто-блок", "Полёт", "Скорость", "Рентген", "Ночное зрение", "Игроки (ESP)", "Инфо", "Авто-подбор",
            "Автокликер", "Креатив"};
    static final String[] SUBS = {"Плавно, с КД 1.9", "Мгновенно, спам", "Бьёт без наводки", "Булава / топор", "Не толкает",
            "Блок под ногами", "Пробел / Shift", "Быстрый бег", "Только руды", "Видно в темноте", "Квадрат, хп, броня", "Инвентарь, прочность", "Предметы рядом",
            "Кликает по цели в прицеле", "Режим игры (одиночный)"};
    static final String[] LYR_POS = {"Снизу", "По центру", "Сверху"};
    static final String[] TARGETS = {"Все существа", "Только игроки", "Только мобы"};
    static final String[] WALK = {"Нет", "Кольца при ходьбе", "Цветной след"};

    record Hit(int x, int y, int w, int h, Runnable act, Sl sl) {}

    static class Sl {
        int x, w;
        double min, max;
        DoubleConsumer set;
    }

    int tab = 0, sub = 0, px, py, cx, cy, waiting = -1, age = 0, songScroll = 0, cheatPage = 0, detail = -1;
    float scale = 1f;
    String nickMsg = "";
    TextFieldWidget nick;
    final List<Hit> hits = new ArrayList<>();
    Sl drag;

    public VisualsScreen() { super(Text.literal("Limozut")); }

    @Override
    protected void init() {
        scale = Math.min(1f, Math.min((width - 6f) / PW, (height - 6f) / PH));
        px = (int) ((width / scale - PW) / 2);
        py = (int) ((height / scale - PH) / 2);
        cx = px + SB + 10;
        cy = py + 40;
        nick = new TextFieldWidget(textRenderer, cx, cy + 16, 200, 18, Text.literal(""));
        nick.setMaxLength(16);
        nick.setText(client.getSession().getUsername());
    }

    @Override public boolean shouldPause() { return false; }
    @Override public void tick() { age++; }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float d) {
        c.fill(0, 0, width, height, 0x99000000);
    }

    static String keyName(int k) {
        if (k < 0) return "—";
        String s = InputUtil.fromKeyCode(k, 0).getLocalizedText().getString();
        return s.length() > 8 ? s.substring(0, 8) : s;
    }

    static int cyc(int v, int n, int d) { return ((v + d) % n + n) % n; }

    static String clip(String s, int n) { return s.length() > n ? s.substring(0, n - 1) + "…" : s; }

    boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    // ---------- мини-виджеты ----------
    void hit(int x, int y, int w, int h, Runnable a) { hits.add(new Hit(x, y, w, h, a, null)); }

    void text(DrawContext c, String s, int x, int y, int col) { c.drawText(textRenderer, s, x, y, col, false); }

    void hint(DrawContext c, String s, int x, int y) { text(c, s, x, y, Ui.sub()); }

    void button(DrawContext c, int x, int y, int w, int h, String label, boolean active, Runnable a) {
        Ui.slot(c, x, y, w, h, active);
        c.drawCenteredTextWithShadow(textRenderer, label, x + w / 2, y + (h - 8) / 2, 0xFFFFFFFF);
        hit(x, y, w, h, a);
    }

    void switchBox(DrawContext c, int x, int y, boolean on) {
        Ui.round(c, x, y, 32, 14, 7, on ? Ui.acc() : 0xFF3A3650);
        int kn = on ? x + 19 : x + 2;
        Ui.round(c, kn, y + 2, 11, 10, 5, 0xFFFFFFFF);
    }

    void toggle(DrawContext c, int x, int y, int w, int h, String label, boolean on, Runnable flip) {
        Ui.slot(c, x, y, w, h, false);
        c.drawTextWithShadow(textRenderer, label, x + 6, y + (h - 8) / 2, 0xFFFFFFFF);
        switchBox(c, x + w - 40, y + (h - 14) / 2, on);
        hit(x, y, w, h, flip);
    }

    void slider(DrawContext c, int x, int y, int w, String label, double v, double min, double max, DoubleConsumer set) {
        c.drawTextWithShadow(textRenderer, label, x, y, 0xFFFFFFFF);
        Ui.round(c, x, y + 12, w, 8, 4, 0xFF2A2640);
        int fw = (int) ((MathHelper.clamp(v, min, max) - min) / (max - min) * (w - 8));
        Ui.round(c, x, y + 12, fw + 8, 8, 4, Ui.acc());
        c.fill(x + fw + 1, y + 10, x + fw + 7, y + 22, 0xFFFFFFFF);
        Sl s = new Sl();
        s.x = x; s.w = w; s.min = min; s.max = max; s.set = set;
        hits.add(new Hit(x, y + 8, w, 20, null, s));
    }

    // выбор стрелками: change(-1) назад, change(1) вперёд, change(0) — клик по названию
    void selector(DrawContext c, int x, int y, int w, String label, String val, IntConsumer change) {
        Ui.slot(c, x, y, w, 36, false);
        text(c, label, x + 6, y + 4, Ui.sub());
        c.drawCenteredTextWithShadow(textRenderer, val, x + w / 2, y + 19, 0xFFFFFFFF);
        hit(x + 24, y, w - 48, 36, () -> change.accept(0));
        Ui.slot(c, x + 4, y + 15, 18, 16, false);
        c.drawCenteredTextWithShadow(textRenderer, "<", x + 13, y + 19, 0xFFFFFFFF);
        hit(x + 4, y + 15, 18, 16, () -> change.accept(-1));
        Ui.slot(c, x + w - 22, y + 15, 18, 16, false);
        c.drawCenteredTextWithShadow(textRenderer, ">", x + w - 13, y + 19, 0xFFFFFFFF);
        hit(x + w - 22, y + 15, 18, 16, () -> change.accept(1));
    }

    String[] subsOf() {
        return tab == T_FUN ? FUN_SUBS : tab == T_SONGS ? SONG_SUBS : null;
    }

    int enabledCount() {
        int n = 0;
        for (int i = 0; i < 14; i++) if (Cheats.get(i)) n++;
        return n;
    }

    // ---------- каркас ----------
    @Override
    public void render(DrawContext c, int mx, int my, float d) {
        renderBackground(c, mx, my, d);
        hits.clear();
        c.getMatrices().push();
        c.getMatrices().scale(scale, scale, 1f);
        Ui.panel(c, px, py, PW, PH);
        Ui.sidebar(c, px, py, SB, PH);
        Ui.round(c, px + 10, py + 9, 20, 20, 6, Ui.acc());
        c.drawCenteredTextWithShadow(textRenderer, "L", px + 20, py + 15, 0xFFFFFFFF);
        c.drawTextWithShadow(textRenderer, "LIMOZUT", px + 36, py + 15, 0xFFFFFFFF);
        for (int i = 0; i < TABS.length; i++) {
            final int ti = i;
            int y = py + 36 + i * 23;
            Ui.tab(c, px + 8, y, SB - 16, 21, tab == i);
            c.drawTextWithShadow(textRenderer, TABS[i], px + 20, y + 6, 0xFFFFFFFF);
            if (i == T_CHEATS) {
                String n = String.valueOf(enabledCount());
                c.drawTextWithShadow(textRenderer, n, px + SB - 16 - textRenderer.getWidth(n), y + 6, tab == i ? 0xFFFFFFFF : Ui.sub());
            }
            hit(px + 8, y, SB - 16, 21, () -> { tab = ti; sub = 0; detail = -1; waiting = -1; nick.setFocused(false); });
        }
        c.drawTextWithShadow(textRenderer, TABS[tab], cx, py + 13, 0xFFFFFFFF);
        if (tab == T_CHEATS) text(c, "Включено " + enabledCount() + " из 14", cx + 80, py + 14, Ui.sub());
        String[] ss = subsOf();
        if (ss != null) {
            for (int i = 0; i < ss.length; i++) {
                final int fi = i;
                button(c, px + PW - 8 - (ss.length - i) * 90, py + 8, 86, 18, ss[i], sub == i, () -> sub = fi);
            }
        }
        switch (tab) {
            case T_CHEATS -> { if (detail >= 0) renderDetail(c); else renderCheats(c); }
            case T_SWORD -> renderSword(c);
            case T_SONGS -> renderSongs(c);
            case T_SOUNDS -> renderSounds(c);
            case T_ANIM -> renderAnim(c);
            case T_CLOTHES -> renderClothes(c);
            case T_FUN -> renderFun(c);
            case T_FPS -> renderFps(c);
            default -> renderProfile(c, (int) (mx / scale), (int) (my / scale), d);
        }
        c.getMatrices().pop();
        if (Config.island) Island.render(c, client, width, mx, my, true);
    }

    // ---------- читы: карточки ----------
    void renderCheats(DrawContext c) {
        int per = 8;
        int pages = (NCHEATS + per - 1) / per;
        cheatPage = MathHelper.clamp(cheatPage, 0, pages - 1);
        for (int k = 0; k < per; k++) {
            int i = cheatPage * per + k;
            if (i >= NCHEATS) break;
            final int fi = i;
            int x = cx + (k % 2) * 256, y = cy + (k / 2) * 50;
            boolean on = i != 14 && Cheats.get(i);
            Ui.card(c, x, y, 246, 46, on);
            c.drawTextWithShadow(textRenderer, NAMES[i], x + 10, y + 7, 0xFFFFFFFF);
            text(c, clip(SUBS[i], 34), x + 10, y + 21, Ui.sub());
            hit(x, y, 246, 46, () -> Cheats.toggle(fi));
            if (i != 14) switchBox(c, x + 246 - 44, y + 7, on);
            String kn = Config.keys[i] >= 0 ? keyName(Config.keys[i]) : "";
            if (!kn.isEmpty()) text(c, "[" + kn + "]", x + 10, y + 32, Ui.sub());
            Ui.slot(c, x + 246 - 46, y + 27, 38, 14, false);
            c.drawCenteredTextWithShadow(textRenderer, "Ещё", x + 246 - 27, y + 30, 0xFFFFFFFF);
            hit(x + 246 - 46, y + 27, 38, 14, () -> { detail = fi; waiting = -1; });
        }
        button(c, cx, cy + 206, 40, 16, "<", false, () -> cheatPage = Math.max(0, cheatPage - 1));
        button(c, cx + 44, cy + 206, 40, 16, ">", false, () -> cheatPage = Math.min(pages - 1, cheatPage + 1));
        text(c, "Страница " + (cheatPage + 1) + " из " + pages, cx + 92, cy + 210, Ui.sub());
        if (!Cheats.status.isEmpty()) text(c, clip(Cheats.status, 40), cx + 256, cy + 210, 0xFFFFE0E0);
    }

    // ---------- читы: настройки одного чита ----------
    void renderDetail(DrawContext c) {
        final int i = detail;
        int L = cx, R = cx + 256, y0 = cy + 26;
        button(c, cx, cy, 80, 18, "< Назад", false, () -> detail = -1);
        c.drawTextWithShadow(textRenderer, NAMES[i], cx + 92, cy + 5, 0xFFFFFFFF);
        if (i != 14) toggle(c, L, y0, 244, 24, "Включён", Cheats.get(i), () -> Cheats.toggle(i));
        boolean w = waiting == i;
        Ui.slot(c, R, y0, 244, 24, w);
        c.drawTextWithShadow(textRenderer, "Клавиша: " + (w ? "..." : keyName(Config.keys[i])), R + 6, y0 + 8, 0xFFFFFFFF);
        hit(R, y0, 244, 24, () -> waiting = i);
        int y = y0 + 34;
        switch (i) {
            case 0 -> {
                slider(c, L, y, 244, "Скорость наводки: " + Config.aimSpeed + "°", Config.aimSpeed, 2, 60, v -> Config.aimSpeed = (int) Math.round(v));
                slider(c, R, y, 244, "Радиус удара: " + String.format("%.1f", Config.radius), Config.radius, 2.0, 6.0, v -> Config.radius = Math.round(v * 10) / 10f);
                targetSel(c, L, y + 40);
                toggle(c, R, y + 44, 244, 24, "Только если видно цель", Config.needSee, () -> Config.needSee = !Config.needSee);
                toggle(c, R, y + 72, 244, 24, "Видимый поворот головы (3-е лицо)", Config.headRot, () -> Config.headRot = !Config.headRot);
            }
            case 1 -> {
                slider(c, L, y, 244, "Скорость: " + Config.cps + " уд/сек", Config.cps, 1, 20, v -> Config.cps = (int) Math.round(v));
                slider(c, R, y, 244, "Радиус удара: " + String.format("%.1f", Config.radius), Config.radius, 2.0, 6.0, v -> Config.radius = Math.round(v * 10) / 10f);
                targetSel(c, L, y + 40);
                toggle(c, R, y + 44, 244, 24, "Только если видно цель", Config.needSee, () -> Config.needSee = !Config.needSee);
                toggle(c, R, y + 72, 244, 24, "Видимый поворот головы (3-е лицо)", Config.headRot, () -> Config.headRot = !Config.headRot);
            }
            case 2 -> {
                slider(c, L, y, 244, "Радиус удара: " + String.format("%.1f", Config.radius), Config.radius, 2.0, 6.0, v -> Config.radius = Math.round(v * 10) / 10f);
                slider(c, R, y, 244, "Скорость: " + Config.cps + " уд/сек", Config.cps, 1, 20, v -> Config.cps = (int) Math.round(v));
                targetSel(c, L, y + 40);
                toggle(c, R, y + 44, 244, 24, "С перезарядкой 1.9", Config.auraCd, () -> Config.auraCd = !Config.auraCd);
                toggle(c, R, y + 72, 244, 24, "Только если видно цель", Config.needSee, () -> Config.needSee = !Config.needSee);
                toggle(c, R, y + 100, 244, 24, "Видимый поворот головы (3-е лицо)", Config.headRot, () -> Config.headRot = !Config.headRot);
            }
            case 3 -> {
                toggle(c, L, y, 244, 24, "Против щита брать топор", Config.autoAxe, () -> Config.autoAxe = !Config.autoAxe);
                hint(c, "Без щита у цели берёт булаву, потом меч.", L, y + 34);
            }
            case 4 -> {
                slider(c, L, y, 244, "Сила: гасит " + Config.antiKbPct + "% отдачи", Config.antiKbPct, 0, 100, v -> Config.antiKbPct = (int) Math.round(v));
            }
            case 6 -> slider(c, L, y, 244, "Скорость полёта: " + Config.flySpeed + "%", Config.flySpeed, 20, 300, v -> Config.flySpeed = (int) Math.round(v));
            case 7 -> slider(c, L, y, 244, "Скорость бега: " + Config.speedMul + "%", Config.speedMul, 50, 400, v -> Config.speedMul = (int) Math.round(v));
            case 11 -> {
                toggle(c, L, y, 244, 22, "Броня + прочность", Config.infoArmor, () -> Config.infoArmor = !Config.infoArmor);
                toggle(c, L, y + 25, 244, 22, "Инвентарь", Config.infoInv, () -> Config.infoInv = !Config.infoInv);
                toggle(c, L, y + 50, 244, 22, "Хотбар", Config.infoHotbar, () -> Config.infoHotbar = !Config.infoHotbar);
                toggle(c, L, y + 75, 244, 22, "Еда и здоровье", Config.infoFood, () -> Config.infoFood = !Config.infoFood);
                toggle(c, L, y + 100, 244, 22, "Предмет в руке", Config.infoHand, () -> Config.infoHand = !Config.infoHand);
                toggle(c, L, y + 125, 244, 22, "Координаты", Config.infoCoords, () -> Config.infoCoords = !Config.infoCoords);
                selector(c, R, y, 244, "Где показывать панель", Fun.CORNERS[Config.infoPos], d -> { if (d != 0) Config.infoPos = cyc(Config.infoPos, 4, d); });
                slider(c, R, y + 46, 244, "Размер панели: " + Config.infoScale + "%", Config.infoScale, 50, 150, v -> Config.infoScale = (int) Math.round(v));
            }
            case 12 -> slider(c, L, y, 244, "Радиус подбора: " + Config.pickupRadius + " бл.", Config.pickupRadius, 1, 16, v -> Config.pickupRadius = (int) Math.round(v));
            case 13 -> {
                slider(c, L, y, 244, "Скорость: " + Config.clickCps + " клик/сек", Config.clickCps, 1, 25, v -> Config.clickCps = (int) Math.round(v));
                toggle(c, R, y - 4, 244, 24, "Кликать только пока зажата атака", Config.clickNeedHold, () -> Config.clickNeedHold = !Config.clickNeedHold);
                targetSel(c, L, y + 40);
                hint(c, "Бьёт того, на кого смотришь. Килауру не заменяет.", R, y + 50);
            }
            case 14 -> {
                for (int m = 0; m < 4; m++) {
                    final int fm = m;
                    button(c, (m % 2 == 0 ? L : R), y + (m / 2) * 32, 244, 26, Cheats.MODES[m], false, () -> Cheats.gamemode(fm));
                }
                hint(c, "Работает в одиночном мире, чит-команды не нужны.", L, y + 70);
                text(c, Cheats.status, L, y + 84, 0xFFFFE0E0);
            }
            default -> hint(c, "Дополнительных настроек нет: включил — работает.", L, y);
        }
    }

    void targetSel(DrawContext c, int x, int y) {
        selector(c, x, y, 244, "Кого бить", TARGETS[Math.min(Config.target, 2)], d -> { if (d != 0) Config.target = cyc(Config.target, TARGETS.length, d); });
    }

    // ---------- мечи ----------
    int toolSel = 0, matSel = 5;

    void renderSword(DrawContext c) {
        int R = cx + 256;
        boolean skin = Sword.skinItem(toolSel, matSel);
        String id = Sword.itemId(toolSel, matSel);
        int lay = skin ? Sword.layout() : Sword.posOf(id);
        if (skin) {
            int cur = Sword.current();
            for (int i = 0; i < Sword.NAMES.length; i++) {
                final int fi = i;
                int y = cy + i * 31;
                Ui.slot(c, cx, y, 244, 28, cur == i);
                c.drawTextWithShadow(textRenderer, Sword.NAMES[i], cx + 8, y + 5, 0xFFFFFFFF);
                text(c, Sword.SUBS[i], cx + 8, y + 16, cur == i ? 0xFFFFFFFF : Ui.sub());
                hit(cx, y, 244, 28, () -> Sword.apply(fi, Sword.layout()));
            }
        } else {
            hint(c, "Скины (3 обычных и 2 объёмных) есть у", cx, cy + 4);
            hint(c, "незеритового меча — выбери справа Меч + Незерит.", cx, cy + 15);
            hint(c, "Раскладка (положение в руке) работает для", cx, cy + 36);
            hint(c, "любого меча, кирки, топора, лопаты и мотыги.", cx, cy + 47);
        }
        for (int i = 0; i < 5; i++) {
            final int fi = i;
            button(c, R + i * 49, cy, 47, 20, Sword.TOOLS[i], toolSel == i, () -> toolSel = fi);
        }
        selector(c, R, cy + 26, 244, "Материал", Sword.MATS[matSel], d -> { if (d != 0) matSel = cyc(matSel, 6, d); });
        for (int l = 0; l < 3; l++) {
            final int fl = l;
            button(c, R + l * 82, cy + 68, 80, 20, Sword.LAYOUTS[l], lay == l, () -> {
                if (skin) Sword.apply(Sword.current(), fl); else Sword.applyPos(id, fl);
            });
        }
        hint(c, "Положение в руке: " + Sword.LSUBS[lay], R, cy + 93);
        Ui.slot(c, R, cy + 106, 244, 76, false);
        c.getMatrices().push();
        c.getMatrices().translate(R + 122 - 32, cy + 112, 0);
        c.getMatrices().scale(4f, 4f, 1f);
        try {
            c.drawItem(new ItemStack(net.minecraft.registry.Registries.ITEM.get(net.minecraft.util.Identifier.of("minecraft", id))), 0, 0);
        } catch (Throwable ignored) {}
        c.getMatrices().pop();
        hint(c, "После выбора игра на пару секунд перезагрузит ресурсы.", R, cy + 188);
        text(c, clip(Sword.status, 44), R, cy + 200, 0xFFFFE0E0);
    }

    // ---------- песни и текст ----------
    void renderSongs(DrawContext c) {
        if (sub == 1) { renderLyrics(c); return; }
        int total = Songs.TRACKS.size();
        songScroll = MathHelper.clamp(songScroll, 0, Math.max(0, total - 6));
        for (int r = 0; r < 6; r++) {
            int i = songScroll + r, x = cx, y = cy + r * 30;
            if (i < total) {
                Songs.Track t = Songs.TRACKS.get(i);
                boolean cur = Songs.idx == i && (Songs.playing || Songs.loaded);
                Ui.slot(c, x, y, 244, 28, cur);
                c.drawTextWithShadow(textRenderer, (cur ? "▶ " : "♪ ") + clip(t.name(), 36), x + 6, y + 5, 0xFFFFFFFF);
                text(c, t.artist() + (t.dur() > 0 ? "  " + t.dur() / 60 + ":" + String.format("%02d", t.dur() % 60) : ""), x + 6, y + 16, cur ? 0xFFFFFFFF : Ui.sub());
                final int fi = i;
                hit(x, y, 244, 28, () -> Songs.play(fi));
            } else {
                Ui.slot(c, x, y, 244, 28, false);
                text(c, "— пусто —", x + 6, y + 10, Ui.sub());
            }
        }
        button(c, cx, cy + 185, 40, 16, "▲", false, () -> songScroll = Math.max(0, songScroll - 6));
        button(c, cx + 44, cy + 185, 40, 16, "▼", false, () -> songScroll = Math.min(Math.max(0, total - 6), songScroll + 6));
        hint(c, (songScroll + 1) + "-" + Math.min(total, songScroll + 6) + " из " + total, cx + 92, cy + 189);
        int rx = cx + 256;
        toggle(c, rx, cy, 244, 24, "Анимация плеера (остров)", Config.island, () -> Config.island = !Config.island);
        String[] ic = {"|<", Songs.playing ? "||" : ">", ">|"};
        for (int i = 0; i < 3; i++) {
            final int fi = i;
            button(c, rx + i * 84, cy + 28, 76, 20, ic[i], false, () -> { if (fi == 0) Songs.prev(); else if (fi == 1) Songs.toggle(); else Songs.next(); });
            boolean wait = waiting == 20 + i;
            Ui.slot(c, rx + i * 84, cy + 51, 76, 14, wait);
            c.drawCenteredTextWithShadow(textRenderer, wait ? "..." : keyName(Config.keys[20 + i]), rx + i * 84 + 38, cy + 54, 0xFFFFFFFF);
            hit(rx + i * 84, cy + 51, 76, 14, () -> waiting = 20 + fi);
        }
        slider(c, rx, cy + 68, 244, "Громкость песни: " + Config.musicVol + "%", Config.musicVol, 0, 200, v -> Config.musicVol = (int) Math.round(v));
        toggle(c, rx, cy + 96, 244, 22, "Текст ищется сам (интернет)", Config.lyricsAuto, () -> Config.lyricsAuto = !Config.lyricsAuto);
        text(c, clip(Songs.playing ? Lyrics.status : "Текст: включи песню", 44), rx, cy + 124, 0xFFFFFFFF);
        button(c, rx, cy + 138, 120, 22, "Добавить песню", false, () -> client.setScreen(new FilePickScreen(this)));
        button(c, rx + 124, cy + 138, 120, 22, "Найти текст", false, Lyrics::refetch);
        text(c, clip(Songs.status, 44), rx, cy + 166, 0xFFFFE0E0);
        hint(c, "Любая песня: mp3 / ogg / wav, без ресурспаков.", rx, cy + 180);
    }

    void renderLyrics(DrawContext c) {
        int L = cx, R = cx + 256, y0 = cy + 4;
        toggle(c, L, y0, 244, 24, "Текст песни на экране", Config.lyrics, () -> Config.lyrics = !Config.lyrics);
        toggle(c, L, y0 + 27, 244, 24, "Искать текст сам (интернет)", Config.lyricsAuto, () -> Config.lyricsAuto = !Config.lyricsAuto);
        selector(c, L, y0 + 58, 244, "Где показывать текст", LYR_POS[Config.lyricsPos], d -> {
            if (d != 0) Config.lyricsPos = cyc(Config.lyricsPos, 3, d);
        });
        slider(c, R, y0, 244, "Размер текста: " + Config.lyricsSize + "%", Config.lyricsSize, 80, 300, v -> Config.lyricsSize = (int) Math.round(v));
        slider(c, R, y0 + 34, 244, "Сдвиг по времени: " + Config.lyricsOffset + " мс", Config.lyricsOffset, -5000, 5000,
                v -> Config.lyricsOffset = (int) Math.round(v / 50.0) * 50);
        text(c, clip(Lyrics.status, 44), R, y0 + 68, 0xFFFFFFFF);
        button(c, R, y0 + 82, 244, 22, "Найти текст заново", false, Lyrics::refetch);
        hint(c, "Текст сам находится по названию песни и", R, y0 + 112);
        hint(c, "запоминается. Не совпал по времени — сдвиг.", R, y0 + 123);
    }

    // ---------- звуки убийства ----------
    void renderSounds(DrawContext c) {
        int L = cx, R = cx + 256, y0 = cy;
        int na = Anims.NAMES.length;
        selector(c, L, y0, 244, "Звук смерти моба", Sounds.NAMES[Config.mobSound], d -> {
            if (d != 0) Config.mobSound = cyc(Config.mobSound, 4, d);
            previewSound(Config.mobSound);
        });
        selector(c, R, y0, 244, "Анимация смерти моба", Anims.NAMES[Config.mobAnim], d -> {
            if (d != 0) Config.mobAnim = cyc(Config.mobAnim, na, d);
            previewAnim(Config.mobAnim);
        });
        selector(c, L, y0 + 42, 244, "Звук смерти игрока", Sounds.NAMES[Config.playerSound], d -> {
            if (d != 0) Config.playerSound = cyc(Config.playerSound, 4, d);
            previewSound(Config.playerSound);
        });
        selector(c, R, y0 + 42, 244, "Анимация смерти игрока", Anims.NAMES[Config.playerAnim], d -> {
            if (d != 0) Config.playerAnim = cyc(Config.playerAnim, na, d);
            previewAnim(Config.playerAnim);
        });
        int n = Sounds.HIT_NAMES.length;
        selector(c, L, y0 + 84, 244, "Звук удара (по мобу / игроку)", Sounds.HIT_NAMES[Config.hitSound], d -> {
            if (d != 0) Config.hitSound = cyc(Config.hitSound, n, d);
            Sounds.playHitIdx(Config.hitSound);
        });
        slider(c, R + 4, y0 + 90, 236, "Громкость удара: " + Config.hitVol + "%", Config.hitVol, 0, 200, v -> Config.hitVol = (int) Math.round(v));
        toggle(c, R, y0 + 120, 244, 24, "Анимации только для моих убийств", Config.animOnlyMine, () -> Config.animOnlyMine = !Config.animOnlyMine);
        hint(c, "Стрелки — выбрать, клик по названию — послушать.", L, y0 + 134);
        hint(c, "Звуки удара: 1 — твой mp3, 2-12 — новые, (MC) — родные.", L, y0 + 150);
        hint(c, "«Молния (как в игре)» — настоящая, без урона.", L, y0 + 162);
        hint(c, "Звук играет и при ударе килаурой.", L, y0 + 174);
    }

    // ---------- анимации: прыжок и ходьба ----------
    void renderAnim(DrawContext c) {
        int L = cx, R = cx + 256, y0 = cy;
        c.drawTextWithShadow(textRenderer, "Прыжок", L, y0, 0xFFFFFFFF);
        c.drawTextWithShadow(textRenderer, "Ходьба", R, y0, 0xFFFFFFFF);
        selector(c, L, y0 + 12, 244, "Анимация прыжка (кольца)", Fun.JUMP[Config.jumpFx], d -> { if (d != 0) Config.jumpFx = cyc(Config.jumpFx, Fun.JUMP.length, d); });
        selector(c, L, y0 + 52, 244, "Цвет колец", Draw.COLORS[Config.jumpColor], d -> { if (d != 0) Config.jumpColor = cyc(Config.jumpColor, Draw.COLORS.length, d); });
        slider(c, L, y0 + 96, 244, "Размер колец: " + Config.jumpSize + "%", Config.jumpSize, 50, 250, v -> Config.jumpSize = (int) Math.round(v));
        toggle(c, L, y0 + 128, 244, 22, "Частицы вокруг игрока", Config.jumpParts, () -> Config.jumpParts = !Config.jumpParts);
        button(c, L, y0 + 154, 244, 22, "Показать пример", false, () -> { if (client.player != null) Fun.ring(client, client.player); });
        selector(c, R, y0 + 12, 244, "Анимация при ходьбе", WALK[Config.walkFx], d -> { if (d != 0) Config.walkFx = cyc(Config.walkFx, WALK.length, d); });
        toggle(c, R, y0 + 54, 244, 24, "Показывать только от 3-го лица", Config.animThirdOnly, () -> Config.animThirdOnly = !Config.animThirdOnly);
        hint(c, "Кольца и след рисуются в мире, а не поверх", R, y0 + 88);
        hint(c, "экрана. Лучше видно от 3-го лица (F5).", R, y0 + 99);
        hint(c, "Цвет и размер — как у прыжка.", R, y0 + 114);
    }

    // ---------- приколное ----------
    void renderFun(DrawContext c) {
        int L = cx, R = cx + 256, y0 = cy + 4;
        switch (sub) {
            case 0 -> {
                toggle(c, L, y0, 244, 24, "Броня + прочность", Config.infoArmor, () -> Config.infoArmor = !Config.infoArmor);
                toggle(c, L, y0 + 27, 244, 24, "Инвентарь", Config.infoInv, () -> Config.infoInv = !Config.infoInv);
                toggle(c, L, y0 + 54, 244, 24, "Хотбар", Config.infoHotbar, () -> Config.infoHotbar = !Config.infoHotbar);
                toggle(c, L, y0 + 81, 244, 24, "Еда и здоровье", Config.infoFood, () -> Config.infoFood = !Config.infoFood);
                toggle(c, L, y0 + 108, 244, 24, "Прочность предмета в руке", Config.infoHand, () -> Config.infoHand = !Config.infoHand);
                toggle(c, L, y0 + 135, 244, 24, "Координаты", Config.infoCoords, () -> Config.infoCoords = !Config.infoCoords);
                selector(c, R, y0, 244, "Где показывать панель «Инфо»", Fun.CORNERS[Config.infoPos], d -> { if (d != 0) Config.infoPos = cyc(Config.infoPos, 4, d); });
                slider(c, R, y0 + 46, 244, "Размер панели: " + Config.infoScale + "%", Config.infoScale, 50, 150, v -> Config.infoScale = (int) Math.round(v));
                toggle(c, R, y0 + 80, 244, 24, "Панель «Инфо» включена", Cheats.info, () -> Cheats.info = !Cheats.info);
            }
            case 1 -> {
                toggle(c, L, y0, 244, 24, "Остров (плеер + FPS)", Config.island, () -> Config.island = !Config.island);
                toggle(c, L, y0 + 27, 244, 24, "Показывать FPS в острове", Config.fpsShow, () -> Config.fpsShow = !Config.fpsShow);
                selector(c, L, y0 + 58, 244, "Где показывать остров с FPS", Fun.POS[Config.fpsPos], d -> { if (d != 0) Config.fpsPos = cyc(Config.fpsPos, Fun.POS.length, d); });
                toggle(c, R, y0, 244, 24, "Панель FPS / TPS / пинг", Config.hudBar, () -> Config.hudBar = !Config.hudBar);
                selector(c, R, y0 + 31, 244, "Где показывать панель", Fun.POS[Config.barPos], d -> { if (d != 0) Config.barPos = cyc(Config.barPos, Fun.POS.length, d); });
                hint(c, "Остров разворачивается в плеер при клике.", R, y0 + 74);
                hint(c, "Не ставь остров и панель в одно место.", R, y0 + 85);
            }
            default -> {
                toggle(c, L, y0, 244, 24, "Эффекты зелий (список)", Config.effectsHud, () -> Config.effectsHud = !Config.effectsHud);
                selector(c, L, y0 + 31, 244, "Где показывать эффекты", Fun.POS[Config.effectsPos], d -> { if (d != 0) Config.effectsPos = cyc(Config.effectsPos, Fun.POS.length, d); });
                toggle(c, R, y0, 244, 24, "Броня вокруг прицела (прочность)", Config.armorHud, () -> Config.armorHud = !Config.armorHud);
                slider(c, R, y0 + 31, 244, "Расстояние от прицела: " + Config.armorGap, Config.armorGap, 10, 120, v -> Config.armorGap = (int) Math.round(v));
                slider(c, R, y0 + 65, 244, "Размер брони: " + Config.armorScale + "%", Config.armorScale, 50, 200, v -> Config.armorScale = (int) Math.round(v));
                hint(c, "Слева шлем и нагрудник, справа штаны и ботинки.", L, y0 + 82);
                hint(c, "Число — сколько прочности осталось.", L, y0 + 93);
            }
        }
    }

    // ---------- скин: шляпа и крылья ----------
    void renderClothes(DrawContext c) {
        int L = cx, R = cx + 256, y0 = cy;
        c.drawTextWithShadow(textRenderer, "Шляпа", L, y0, 0xFFFFFFFF);
        c.drawTextWithShadow(textRenderer, "Крылья", R, y0, 0xFFFFFFFF);
        selector(c, L, y0 + 12, 244, "Вид шляпы", Clothes.HATS[Config.hat], d -> { if (d != 0) Config.hat = cyc(Config.hat, Clothes.HATS.length, d); });
        selector(c, L, y0 + 52, 244, "Цвет шляпы", Draw.COLORS[Config.hatColor], d -> { if (d != 0) Config.hatColor = cyc(Config.hatColor, Draw.COLORS.length, d); });
        slider(c, L, y0 + 96, 244, "Размер шляпы: " + Config.hatSize + "%", Config.hatSize, 50, 200, v -> Config.hatSize = (int) Math.round(v));
        selector(c, R, y0 + 12, 244, "Вид крыльев", Clothes.WINGS[Config.wings], d -> { if (d != 0) Config.wings = cyc(Config.wings, Clothes.WINGS.length, d); });
        selector(c, R, y0 + 52, 244, "Цвет крыльев", Draw.COLORS[Config.wingColor], d -> { if (d != 0) Config.wingColor = cyc(Config.wingColor, Draw.COLORS.length, d); });
        slider(c, R, y0 + 96, 244, "Размер крыльев: " + Config.wingSize + "%", Config.wingSize, 50, 200, v -> Config.wingSize = (int) Math.round(v));
        slider(c, R, y0 + 130, 244, "Скорость взмахов: " + Config.wingSpeed + "%", Config.wingSpeed, 30, 250, v -> Config.wingSpeed = (int) Math.round(v));
        hint(c, "Одежду видно от 3-го лица: нажми F5.", L, y0 + 134);
        hint(c, "В воздухе крылья машут сильнее.", L, y0 + 145);
    }

    // ---------- оптимизация ----------
    void renderFps(DrawContext c) {
        int y0 = cy;
        for (int i = 0; i < 4; i++) {
            final int fi = i;
            int x = cx + i * 128;
            Ui.slot(c, x, y0, 122, 40, Config.optMode == i);
            c.drawCenteredTextWithShadow(textRenderer, Opt.NAMES[i], x + 61, y0 + 9, 0xFFFFFFFF);
            c.drawCenteredTextWithShadow(textRenderer, Opt.SUBS[i], x + 61, y0 + 24, 0xFFFFFFFF);
            hit(x, y0, 122, 40, () -> Opt.setMode(client, fi));
        }
        toggle(c, cx, y0 + 48, 244, 28, "Авто-подстройка под цель", Config.optAuto, () -> {
            Config.optAuto = !Config.optAuto;
            Opt.refresh(client);
        });
        slider(c, cx, y0 + 84, 244, "Цель: " + Config.optTarget + " FPS", Config.optTarget, 30, 144, v -> Config.optTarget = (int) Math.round(v / 5.0) * 5);
        int rx = cx + 256;
        text(c, "FPS сейчас: " + client.getCurrentFps(), rx, y0 + 50, 0xFFFFFFFF);
        text(c, "Дальность прорисовки: " + client.options.getViewDistance().getValue()
                + (Config.origSaved ? "  (твоя: " + Config.origView + ")" : ""), rx, y0 + 62, 0xFFFFFFFF);
        text(c, "Дальность симуляции: " + client.options.getSimulationDistance().getValue(), rx, y0 + 74, 0xFFFFFFFF);
        text(c, clip(Opt.status.isEmpty() ? "Авто: ждёт данных (5 сек в игре)" : Opt.status, 44), rx, y0 + 86, 0xFFFFE0E0);
        hint(c, "Пресеты: дальность, тени, частицы, облака, mipmap, VSync,", cx, y0 + 124);
        hint(c, "плавный свет. «Выкл» возвращает все твои настройки.", cx, y0 + 135);
        hint(c, "Авто-режим сам снижает дальность, пока FPS ниже цели.", cx, y0 + 146);
        text(c, "Сильнее всего поднимают FPS моды Sodium + Lithium (Modrinth).", cx, y0 + 162, 0xFFFFFFFF);
        text(c, "С Sodium «Рентген» не работает. В лаунчере: -Xmx4G.", cx, y0 + 173, 0xFFFFFFFF);
    }

    // ---------- профиль ----------
    void renderProfile(DrawContext c, int mx, int my, float d) {
        c.drawTextWithShadow(textRenderer, "Ник в игре", cx, cy + 2, 0xFFFFFFFF);
        nick.render(c, mx, my, d);
        button(c, cx + 210, cy + 15, 120, 20, "Сменить ник", false, () -> nickMsg = Nick.set(nick.getText().trim()));
        text(c, nickMsg, cx, cy + 40, 0xFFFFE0E0);
        hint(c, "Ник меняется сразу. Чтобы применился — перезайди в мир.", cx, cy + 52);

        c.drawTextWithShadow(textRenderer, "Клавиша меню", cx, cy + 82, 0xFFFFFFFF);
        boolean wm = waiting == 100;
        Ui.slot(c, cx + 100, cy + 78, 70, 16, wm);
        c.drawCenteredTextWithShadow(textRenderer, wm ? "..." : keyName(Config.keyMenu), cx + 135, cy + 82, 0xFFFFFFFF);
        hit(cx + 100, cy + 78, 70, 16, () -> waiting = 100);
        hint(c, "Нажми на кнопку клавиши и жми нужную. Esc — убрать.", cx, cy + 100);
        hint(c, "На телефоне меню открывается командой /limozut или /visuals.", cx, cy + 111);

        selector(c, cx, cy + 130, 244, "Вид меню", Ui.THEMES[Math.max(0, Math.min(Config.theme, 3))], dd -> { if (dd != 0) Config.theme = cyc(Config.theme, 4, dd); });
        hint(c, "Чёрный, Приколный, Красный или Старый (как раньше).", cx, cy + 172);
    }

    // ---------- ввод ----------
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (tab == T_PROFILE && nick.isFocused()) {
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) { nickMsg = Nick.set(nick.getText().trim()); return true; }
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) { nick.setFocused(false); return true; }
            return nick.keyPressed(keyCode, scanCode, modifiers);
        }
        if (waiting != -1) {
            int val = keyCode == GLFW.GLFW_KEY_ESCAPE ? -1 : keyCode;
            if (waiting == 100) { if (val != -1) Config.keyMenu = val; }
            else Config.keys[waiting] = val;
            waiting = -1;
            Config.save();
            return true;
        }
        if (keyCode == Config.keyMenu && age > 6) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (tab == T_PROFILE && nick.isFocused()) return nick.charTyped(chr, modifiers);
        return super.charTyped(chr, modifiers);
    }

    void setSlider(Sl s, double mx) {
        double f = MathHelper.clamp((mx - s.x - 4) / (s.w - 8), 0, 1);
        s.set.accept(s.min + f * (s.max - s.min));
    }

    @Override
    public boolean mouseClicked(double rmx, double rmy, int b) {
        if (Config.island && Island.click(width, rmx, rmy)) return true;
        double mx = rmx / scale, my = rmy / scale;
        waiting = -1;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!in(mx, my, h.x(), h.y(), h.w(), h.h())) continue;
            if (h.sl() != null) { drag = h.sl(); setSlider(drag, mx); }
            else h.act().run();
            Config.save();
            return true;
        }
        if (tab == T_PROFILE) {
            boolean inside = in(mx, my, cx, cy + 16, 200, 18);
            nick.setFocused(inside);
            if (inside) { nick.mouseClicked(mx, my, b); return true; }
        }
        return super.mouseClicked(rmx, rmy, b);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int b, double dx, double dy) {
        if (drag != null) { setSlider(drag, mx / scale); return true; }
        return super.mouseDragged(mx, my, b, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int b) {
        if (drag != null) { drag = null; Config.save(); return true; }
        return super.mouseReleased(mx, my, b);
    }

    // без @Override: если сигнатура в версии другая — просто не сработает, а не сломает сборку
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        if (tab == T_SONGS && sub == 0) {
            songScroll = Math.max(0, songScroll - (int) Math.signum(vAmount));
            return true;
        }
        if (tab == T_CHEATS && detail < 0) {
            cheatPage = Math.max(0, Math.min(1, cheatPage - (int) Math.signum(vAmount)));
            return true;
        }
        return false;
    }

    public void onFilesDropped(List<Path> paths) { Songs.addFiles(client, paths); }

    public void filesDragged(List<Path> paths) { Songs.addFiles(client, paths); }

    void previewSound(int i) {
        if (client.world != null && client.player != null) Sounds.play(i, client.world, client.player.getPos());
    }

    void previewAnim(int i) {
        if (client.player == null) return;
        Vec3d look = client.player.getRotationVec(1f);
        Anims.play(i, client.player.getPos().add(look.x * 5, 0, look.z * 5));
    }
}
