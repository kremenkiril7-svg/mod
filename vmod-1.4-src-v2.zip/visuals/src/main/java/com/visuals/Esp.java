package com.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class Esp {
    static double[] project(MinecraftClient mc, Camera cam, Vec3d pos, int sw, int sh) {
        Vec3d cp = cam.getPos();
        double dx = pos.x - cp.x, dy = pos.y - cp.y, dz = pos.z - cp.z;
        double yaw = Math.toRadians(cam.getYaw()), pitch = Math.toRadians(cam.getPitch());
        double fx = -Math.sin(yaw) * Math.cos(pitch), fy = -Math.sin(pitch), fz = Math.cos(yaw) * Math.cos(pitch);
        double rx = -Math.cos(yaw), ry = 0, rz = -Math.sin(yaw);
        double ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx;
        double z = dx * fx + dy * fy + dz * fz;
        if (z <= 0.05) return null;
        double x = dx * rx + dy * ry + dz * rz;
        double y = dx * ux + dy * uy + dz * uz;
        double t = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2);
        double aspect = (double) mc.getWindow().getFramebufferWidth() / mc.getWindow().getFramebufferHeight();
        double sx = (x / (z * t * aspect)) * 0.5 + 0.5;
        double sy = 0.5 - (y / (z * t)) * 0.5;
        return new double[]{sx * sw, sy * sh};
    }

    // Квадрат вокруг игрока + полоски здоровья и брони над ним
    public static void draw(DrawContext ctx, MinecraftClient mc, float td) {
        if (!Cheats.players || mc.world == null || mc.player == null) return;
        Camera cam = mc.gameRenderer.getCamera();
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        TextRenderer tr = mc.textRenderer;
        for (AbstractClientPlayerEntity o : mc.world.getPlayers()) {
            if (o == mc.player) continue;
            double ix = MathHelper.lerp(td, o.prevX, o.getX());
            double iy = MathHelper.lerp(td, o.prevY, o.getY());
            double iz = MathHelper.lerp(td, o.prevZ, o.getZ());
            double hw = o.getWidth() / 2, h = o.getHeight();
            double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
            boolean ok = true;
            for (int cx = -1; cx <= 1 && ok; cx += 2)
                for (int cz = -1; cz <= 1 && ok; cz += 2)
                    for (int cy = 0; cy <= 1; cy++) {
                        double[] s = project(mc, cam, new Vec3d(ix + cx * hw, iy + cy * h, iz + cz * hw), sw, sh);
                        if (s == null) { ok = false; break; }
                        minX = Math.min(minX, s[0]); maxX = Math.max(maxX, s[0]);
                        minY = Math.min(minY, s[1]); maxY = Math.max(maxY, s[1]);
                    }
            if (!ok) continue;
            int x1 = (int) minX, y1 = (int) minY, w = Math.max(6, (int) (maxX - minX)), hh = Math.max(6, (int) (maxY - minY));
            boolean invis = Cheats.invisIds.contains(o.getId());
            int col = invis ? 0xFFFFD040 : 0xFFFF2A2A;
            ctx.drawBorder(x1 - 1, y1 - 1, w + 2, hh + 2, 0xFF000000);
            ctx.drawBorder(x1, y1, w, hh, col);

            float hp = o.getHealth() + o.getAbsorptionAmount(), max = Math.max(1f, o.getMaxHealth());
            float rh = MathHelper.clamp(hp / max, 0f, 1f);
            ctx.fill(x1, y1 - 9, x1 + w, y1 - 6, 0xFF000000);
            int hc = rh > 0.6f ? 0xFF3CDC3C : (rh > 0.3f ? 0xFFE8C020 : 0xFFE02020);
            ctx.fill(x1, y1 - 9, x1 + (int) (w * rh), y1 - 6, hc);
            float ra = MathHelper.clamp(o.getArmor() / 20f, 0f, 1f);
            ctx.fill(x1, y1 - 5, x1 + w, y1 - 2, 0xFF000000);
            ctx.fill(x1, y1 - 5, x1 + (int) (w * ra), y1 - 2, 0xFF4AA8FF);
            String label = o.getName().getString() + "  " + Math.round(hp) + " хп  " + o.getArmor() + " бр" + (invis ? "  [невидимка]" : "");
            ctx.drawCenteredTextWithShadow(tr, label, x1 + w / 2, y1 - 20, 0xFFFFFFFF);
        }
    }

    // Инфо: инвентарь и прочность без открытия
    public static void info(DrawContext ctx, MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        TextRenderer tr = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth();
        int pw = 172, x = sw - pw - 4, y = 24, ph = 156;
        Ui.panel(ctx, x, y, pw, ph);
        ctx.drawTextWithShadow(tr, "Инфо", x + 6, y + 5, 0xFFFFFFFF);
        String food = "Еда " + p.getHungerManager().getFoodLevel() + "/20  хп " + Math.round(p.getHealth());
        ctx.drawText(tr, food, x + 40, y + 5, 0xFFFFE0E0, false);

        // броня + левая рука
        for (int i = 0; i < 5; i++) {
            ItemStack s = i < 4 ? p.getInventory().getArmorStack(3 - i) : p.getOffHandStack();
            int sx = x + 6 + i * 18 + (i == 4 ? 14 : 0), sy = y + 18;
            Ui.slot(ctx, sx, sy, 18, 18, false);
            if (!s.isEmpty()) {
                ctx.drawItem(s, sx + 1, sy + 1);
                ctx.drawStackOverlay(tr, s, sx + 1, sy + 1);
                if (s.isDamageable()) {
                    int left = s.getMaxDamage() - s.getDamage();
                    int pct = left * 100 / Math.max(1, s.getMaxDamage());
                    int c = pct > 60 ? 0xFF7CFF7C : (pct > 30 ? 0xFFFFE060 : 0xFFFF5050);
                    ctx.drawText(tr, pct + "%", sx + 1, sy + 20, c, false);
                }
            }
        }
        // основной инвентарь 3 ряда
        for (int i = 0; i < 27; i++) {
            ItemStack s = p.getInventory().getStack(9 + i);
            int sx = x + 6 + (i % 9) * 18, sy = y + 42 + (i / 9) * 18;
            Ui.slot(ctx, sx, sy, 18, 18, false);
            if (!s.isEmpty()) { ctx.drawItem(s, sx + 1, sy + 1); ctx.drawStackOverlay(tr, s, sx + 1, sy + 1); }
        }
        // хотбар
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            int sx = x + 6 + i * 18, sy = y + 100 + 4;
            Ui.slot(ctx, sx, sy, 18, 18, i == p.getInventory().selectedSlot);
            if (!s.isEmpty()) { ctx.drawItem(s, sx + 1, sy + 1); ctx.drawStackOverlay(tr, s, sx + 1, sy + 1); }
        }
        // прочность предмета в руке
        ItemStack hand = p.getMainHandStack();
        if (!hand.isEmpty() && hand.isDamageable()) {
            int left = hand.getMaxDamage() - hand.getDamage();
            ctx.drawText(tr, "В руке: " + left + "/" + hand.getMaxDamage(), x + 6, y + 128, 0xFFFFE0E0, false);
        }
    }
}
