package com.visuals;

import net.minecraft.client.world.ClientWorld;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

public class Sounds {
    public static final String[] NAMES = {"Нет", "Луч света", "Падение человека", "Святой дух"};
    static SoundEvent[] EVENTS = new SoundEvent[4];

    public static void register() {
        String[] ids = {null, "beam", "fall", "holy"};
        for (int i = 1; i < 4; i++) {
            Identifier id = Identifier.of("visuals", ids[i]);
            EVENTS[i] = Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
        }
    }

    public static void play(int idx, ClientWorld w, Vec3d p) {
        if (idx <= 0 || idx > 3) return;
        w.playSound(p.x, p.y, p.z, EVENTS[idx], SoundCategory.PLAYERS, 1.5f, 1f, false);
    }
}
