package com.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;

// Одежда игрока: шляпы и крылья (полупрозрачные светящиеся). Видно от 3-го лица (F5).
public class Clothes {
    public static final String[] HATS = {"Нет", "Конус", "Цилиндр", "Нимб", "Корона"};
    public static final String[] WINGS = {"Нет", "Ангел", "Демон", "Бабочка"};
    public static final String[] COLOR_NAMES = Jump.COLOR_NAMES;

    static int base(int idx, float time) {
        int c = Jump.COLORS[Math.max(0, Math.min(Jump.COLORS.length - 1, idx))];
        return c >= 0 ? c : Jump.hsv((time * 4f % 360f) / 360f);
    }

    static int argb(int rgb, int a, float mul) {
        int r = Math.min(255, (int) (((rgb >> 16) & 255) * mul));
        int g = Math.min(255, (int) (((rgb >> 8) & 255) * mul));
        int b = Math.min(255, (int) ((rgb & 255) * mul));
        return (Math.max(0, Math.min(255, a)) << 24) | (r << 16) | (g << 8) | b;
    }

    // ---------- примитивы: двусторонний четырёхугольник ----------
    static void v(VertexConsumer vc, Matrix4f m, float[] p, int c) {
        vc.vertex(m, p[0], p[1], p[2]).color((c >> 16) & 255, (c >> 8) & 255, c & 255, (c >>> 24) & 255);
    }

    static void quad(VertexConsumer vc, Matrix4f m, float[] a, int ca, float[] b, int cb, float[] c, int cc, float[] d, int cd) {
        v(vc, m, a, ca); v(vc, m, b, cb); v(vc, m, c, cc); v(vc, m, d, cd);
        v(vc, m, d, cd); v(vc, m, c, cc); v(vc, m, b, cb); v(vc, m, a, ca);
    }

    static void tri(VertexConsumer vc, Matrix4f m, float[] a, int ca, float[] b, int cb, float[] c, int cc) {
        quad(vc, m, a, ca, b, cb, c, cc, c, cc);
    }

    static float[] P(double x, double y, double z) { return new float[]{(float) x, (float) y, (float) z}; }

    // ---------- точка входа ----------
    public static void render(Entity e, double x, double y, double z, float td, MatrixStack ms, VertexConsumerProvider vcp) {
        if (Config.hatType == 0 && Config.wingType == 0) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (e != mc.player || !(e instanceof LivingEntity le)) return;
        if (x == 0 && y == 0 && z == 0) return;                 // превью в инвентаре
        if (e.isInvisible() || e.isSpectator() || e.isSleeping() || e.isSwimming() || le.isFallFlying()) return;

        float time = e.age + td;
        float yaw = MathHelper.lerpAngleDegrees(td, le.prevBodyYaw, le.bodyYaw);
        float eye = (float) (e.getEyeY() - e.getY());
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getLightning());

        ms.push();
        ms.translate(x, y, z);
        ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-yaw));
        Matrix4f m = ms.peek().getPositionMatrix();
        if (Config.hatType > 0) hat(vc, m, eye + 0.24f, time);
        if (Config.wingType > 0) wings(vc, m, eye - 0.32f, time, e.isOnGround(), le);
        ms.pop();
    }

    // ---------- шляпы ----------
    static void hat(VertexConsumer vc, Matrix4f m, float hb, float time) {
        float sc = Config.hatScale;
        int rgb = base(Config.hatColor, time);
        switch (Config.hatType) {
            case 1 -> cone(vc, m, hb, sc, rgb);
            case 2 -> topHat(vc, m, hb, sc, rgb);
            case 3 -> halo(vc, m, hb + 0.18f * sc + (float) Math.sin(time * 0.1) * 0.03f, sc, rgb);
            default -> crown(vc, m, hb - 0.02f, sc, rgb);
        }
    }

    static void cone(VertexConsumer vc, Matrix4f m, float y0, float sc, int rgb) {
        int n = 28;
        double R = 0.62 * sc, H = 0.30 * sc;
        float[] apex = P(0, y0 + H, 0);
        int cApex = argb(rgb, 200, 1.0f), cEdge = argb(rgb, 110, 0.8f), rim = argb(rgb, 255, 1.0f);
        for (int i = 0; i < n; i++) {
            double a0 = i * Math.PI * 2 / n, a1 = (i + 1) * Math.PI * 2 / n;
            float[] p0 = P(Math.cos(a0) * R, y0, Math.sin(a0) * R), p1 = P(Math.cos(a1) * R, y0, Math.sin(a1) * R);
            tri(vc, m, apex, cApex, p0, cEdge, p1, cEdge);
            double Ri = R * 0.93;
            float[] q0 = P(Math.cos(a0) * Ri, y0 + 0.012, Math.sin(a0) * Ri), q1 = P(Math.cos(a1) * Ri, y0 + 0.012, Math.sin(a1) * Ri);
            quad(vc, m, p0, rim, p1, rim, q1, rim, q0, rim);
        }
    }

    static void topHat(VertexConsumer vc, Matrix4f m, float y0, float sc, int rgb) {
        int n = 20;
        double r = 0.27 * sc, br = 0.42 * sc, h = 0.34 * sc;
        int side = argb(rgb, 200, 0.9f), top = argb(rgb, 230, 1.0f), brim = argb(rgb, 180, 0.8f), band = argb(rgb, 255, 0.55f);
        float[] ctr = P(0, y0 + h, 0);
        for (int i = 0; i < n; i++) {
            double a0 = i * Math.PI * 2 / n, a1 = (i + 1) * Math.PI * 2 / n;
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            quad(vc, m, P(c0 * r, y0, s0 * r), side, P(c1 * r, y0, s1 * r), side, P(c1 * r, y0 + h, s1 * r), side, P(c0 * r, y0 + h, s0 * r), side);
            quad(vc, m, P(c0 * r * 1.02, y0 + 0.03 * sc, s0 * r * 1.02), band, P(c1 * r * 1.02, y0 + 0.03 * sc, s1 * r * 1.02), band,
                    P(c1 * r * 1.02, y0 + 0.10 * sc, s1 * r * 1.02), band, P(c0 * r * 1.02, y0 + 0.10 * sc, s0 * r * 1.02), band);
            tri(vc, m, ctr, top, P(c0 * r, y0 + h, s0 * r), top, P(c1 * r, y0 + h, s1 * r), top);
            quad(vc, m, P(c0 * r, y0, s0 * r), brim, P(c1 * r, y0, s1 * r), brim, P(c1 * br, y0, s1 * br), brim, P(c0 * br, y0, s0 * br), brim);
        }
    }

    static void ring(VertexConsumer vc, Matrix4f m, float y, double r0, double r1, int col, int n) {
        for (int i = 0; i < n; i++) {
            double a0 = i * Math.PI * 2 / n, a1 = (i + 1) * Math.PI * 2 / n;
            quad(vc, m, P(Math.cos(a0) * r0, y, Math.sin(a0) * r0), col, P(Math.cos(a1) * r0, y, Math.sin(a1) * r0), col,
                    P(Math.cos(a1) * r1, y, Math.sin(a1) * r1), col, P(Math.cos(a0) * r1, y, Math.sin(a0) * r1), col);
        }
    }

    static void halo(VertexConsumer vc, Matrix4f m, float y, float sc, int rgb) {
        ring(vc, m, y, 0.19 * sc, 0.33 * sc, argb(rgb, 60, 1f), 32);
        ring(vc, m, y, 0.22 * sc, 0.30 * sc, argb(rgb, 150, 1f), 32);
        ring(vc, m, y, 0.25 * sc, 0.27 * sc, argb(rgb, 255, 1f), 32);
    }

    static void crown(VertexConsumer vc, Matrix4f m, float y0, float sc, int rgb) {
        int n = 24;
        double r = 0.29 * sc, h = 0.10 * sc, sp = 0.22 * sc;
        int band = argb(rgb, 230, 0.9f), tip = argb(rgb, 255, 1.0f);
        for (int i = 0; i < n; i++) {
            double a0 = i * Math.PI * 2 / n, a1 = (i + 1) * Math.PI * 2 / n;
            quad(vc, m, P(Math.cos(a0) * r, y0, Math.sin(a0) * r), band, P(Math.cos(a1) * r, y0, Math.sin(a1) * r), band,
                    P(Math.cos(a1) * r, y0 + h, Math.sin(a1) * r), band, P(Math.cos(a0) * r, y0 + h, Math.sin(a0) * r), band);
        }
        int k = 8;
        for (int i = 0; i < k; i++) {
            double a = i * Math.PI * 2 / k, da = Math.PI / k * 0.8;
            tri(vc, m, P(Math.cos(a - da) * r, y0 + h, Math.sin(a - da) * r), band, P(Math.cos(a + da) * r, y0 + h, Math.sin(a + da) * r), band,
                    P(Math.cos(a) * r, y0 + h + sp, Math.sin(a) * r), tip);
        }
    }

    // ---------- крылья ----------
    // wing-space: fx — вдоль крыла от спины наружу, fy — вверх. psi — угол отвода крыла назад.
    static float[] W(float rx, float ry, float rz, float side, double psi, double fx, double fy) {
        return P(rx + side * Math.cos(psi) * fx, ry + fy, rz - Math.sin(psi) * fx);
    }

    static void wings(VertexConsumer vc, Matrix4f m, float ry, float time, boolean ground, LivingEntity le) {
        float sc = Config.wingScale;
        int rgb = base(Config.wingColor, time);
        double amp = !Config.wingFlap ? 0 : (ground ? 5 : 22), spd = ground ? 0.12 : 0.35;
        double psiBase = Config.wingType == 3 ? 55 : (Config.wingType == 2 ? 40 : 32);
        double psi = Math.toRadians(psiBase + amp * Math.sin(time * spd));
        for (int s = -1; s <= 1; s += 2) {
            float rx = s * 0.10f, rz = -0.17f;
            switch (Config.wingType) {
                case 1 -> angel(vc, m, rx, ry, rz, s, psi, sc, rgb);
                case 2 -> demon(vc, m, rx, ry, rz, s, psi, sc, rgb);
                default -> butterfly(vc, m, rx, ry, rz, s, psi, sc, rgb);
            }
        }
    }

    static void angel(VertexConsumer vc, Matrix4f m, float rx, float ry, float rz, int s, double psi, float sc, int rgb) {
        double[] ang = {58, 38, 18, -2, -22};
        double[] len = {0.85, 1.0, 0.98, 0.82, 0.6};
        int cRoot = argb(rgb, 190, 1f), cTip = argb(rgb, 70, 1f);
        for (int i = 0; i < ang.length; i++) {
            double a = Math.toRadians(ang[i]), L = len[i] * sc;
            double dx = Math.cos(a), dy = Math.sin(a), nx = -dy, ny = dx;
            double wr = 0.075 * sc, wt = 0.03 * sc;
            double tx = dx * L, ty = dy * L;
            quad(vc, m, W(rx, ry, rz, s, psi, -nx * wr, -ny * wr), cRoot, W(rx, ry, rz, s, psi, nx * wr, ny * wr), cRoot,
                    W(rx, ry, rz, s, psi, tx + nx * wt, ty + ny * wt), cTip, W(rx, ry, rz, s, psi, tx - nx * wt, ty - ny * wt), cTip);
        }
        // перепонка у основания
        float[] r0 = P(rx, ry, rz);
        tri(vc, m, r0, argb(rgb, 150, 1f), W(rx, ry, rz, s, psi, Math.cos(Math.toRadians(58)) * 0.5 * sc, Math.sin(Math.toRadians(58)) * 0.5 * sc), argb(rgb, 40, 1f),
                W(rx, ry, rz, s, psi, Math.cos(Math.toRadians(-22)) * 0.4 * sc, Math.sin(Math.toRadians(-22)) * 0.4 * sc), argb(rgb, 40, 1f));
    }

    static void demon(VertexConsumer vc, Matrix4f m, float rx, float ry, float rz, int s, double psi, float sc, int rgb) {
        double[] ang = {75, 42, 8};
        double[] len = {0.95, 1.1, 0.9};
        float[] r0 = P(rx, ry, rz);
        int mem = argb(rgb, 130, 0.6f), bone = argb(rgb, 255, 1f);
        float[][] tips = new float[3][];
        for (int i = 0; i < 3; i++) {
            double a = Math.toRadians(ang[i]);
            tips[i] = W(rx, ry, rz, s, psi, Math.cos(a) * len[i] * sc, Math.sin(a) * len[i] * sc);
            double nx = -Math.sin(a), ny = Math.cos(a), w = 0.025 * sc;
            quad(vc, m, W(rx, ry, rz, s, psi, -nx * w, -ny * w), bone, W(rx, ry, rz, s, psi, nx * w, ny * w), bone,
                    W(rx, ry, rz, s, psi, Math.cos(a) * len[i] * sc + nx * w * 0.4, Math.sin(a) * len[i] * sc + ny * w * 0.4), bone,
                    W(rx, ry, rz, s, psi, Math.cos(a) * len[i] * sc - nx * w * 0.4, Math.sin(a) * len[i] * sc - ny * w * 0.4), bone);
        }
        tri(vc, m, r0, mem, tips[0], mem, tips[1], mem);
        tri(vc, m, r0, mem, tips[1], mem, tips[2], mem);
        float[] low = W(rx, ry, rz, s, psi, 0.15 * sc, -0.55 * sc);
        tri(vc, m, r0, mem, tips[2], mem, low, mem);
    }

    static void ellipse(VertexConsumer vc, Matrix4f m, float rx, float ry, float rz, int s, double psi,
                        double cx, double cy, double ax, double ay, double rot, int cCenter, int cEdge) {
        int n = 16;
        float[] c = W(rx, ry, rz, s, psi, cx, cy);
        for (int i = 0; i < n; i++) {
            double a0 = i * Math.PI * 2 / n, a1 = (i + 1) * Math.PI * 2 / n;
            double x0 = Math.cos(a0) * ax, y0 = Math.sin(a0) * ay, x1 = Math.cos(a1) * ax, y1 = Math.sin(a1) * ay;
            double rc = Math.cos(rot), rs = Math.sin(rot);
            tri(vc, m, c, cCenter,
                    W(rx, ry, rz, s, psi, cx + x0 * rc - y0 * rs, cy + x0 * rs + y0 * rc), cEdge,
                    W(rx, ry, rz, s, psi, cx + x1 * rc - y1 * rs, cy + x1 * rs + y1 * rc), cEdge);
        }
    }

    static void butterfly(VertexConsumer vc, Matrix4f m, float rx, float ry, float rz, int s, double psi, float sc, int rgb) {
        int cc = argb(rgb, 170, 1f), ce = argb(rgb, 70, 1f);
        ellipse(vc, m, rx, ry, rz, s, psi, 0.55 * sc, 0.45 * sc, 0.55 * sc, 0.45 * sc, Math.toRadians(25), cc, ce);
        ellipse(vc, m, rx, ry, rz, s, psi, 0.40 * sc, -0.28 * sc, 0.32 * sc, 0.30 * sc, Math.toRadians(-20), cc, ce);
    }
}
