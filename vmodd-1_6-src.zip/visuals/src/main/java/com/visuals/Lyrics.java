package com.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

// Текст песни на экране (караоке). Файл .lrc (или .txt) лежит в папке visuals_songs
// с тем же именем, что и песня. Для встроенных песен: song1.lrc / song2.lrc / song3.lrc
public class Lyrics {
    record Line(long ms, String text) {}

    static List<Line> lines = new ArrayList<>();
    public static String status = "";
    static final Pattern TS = Pattern.compile("\\[(\\d{1,3}):(\\d{1,2})(?:[.:](\\d{1,3}))?]");

    public static boolean has() { return !lines.isEmpty(); }

    public static void load(Songs.Track t, int idx) {
        lines = new ArrayList<>();
        status = "";
        if (t == null) return;
        try {
            Path dir = Songs.songsDir();
            List<String> names = new ArrayList<>();
            names.add(t.name());
            if (idx >= 0 && idx < 3) names.add("song" + (idx + 1));
            for (String n : names) {
                Path lrc = dir.resolve(n + ".lrc");
                Path txt = dir.resolve(n + ".txt");
                if (Files.exists(lrc)) { parseLrc(Files.readString(lrc, StandardCharsets.UTF_8)); break; }
                if (Files.exists(txt)) { parseTxt(Files.readString(txt, StandardCharsets.UTF_8), t.dur()); break; }
            }
            lines.sort(Comparator.comparingLong(Line::ms));
            status = lines.isEmpty() ? "Нет текста: положи " + t.name() + ".lrc" : "Текст: " + lines.size() + " строк";
        } catch (Exception e) {
            status = "Ошибка текста";
        }
    }

    static void parseLrc(String s) {
        if (s.startsWith("\uFEFF")) s = s.substring(1);
        long offset = 0;
        for (String raw : s.split("\\r?\\n")) {
            String line = raw.trim();
            if (line.startsWith("[offset:")) {
                try { offset = Long.parseLong(line.substring(8, line.indexOf(']')).trim()); } catch (Exception ignored) {}
                continue;
            }
            Matcher m = TS.matcher(line);
            List<Long> times = new ArrayList<>();
            int end = 0;
            while (m.find() && m.start() == end) {
                long min = Long.parseLong(m.group(1)), sec = Long.parseLong(m.group(2));
                long ms = 0;
                if (m.group(3) != null) {
                    String f = m.group(3);
                    ms = Long.parseLong(f);
                    if (f.length() == 1) ms *= 100; else if (f.length() == 2) ms *= 10;
                }
                times.add(min * 60000 + sec * 1000 + ms);
                end = m.end();
            }
            if (times.isEmpty()) continue;
            String text = line.substring(end).trim();
            for (long tm : times) lines.add(new Line(Math.max(0, tm - offset), text));
        }
    }

    // обычный текст без времени: строки равномерно (по 4 сек. или по длине песни)
    static void parseTxt(String s, int dur) {
        if (s.startsWith("\uFEFF")) s = s.substring(1);
        List<String> ls = new ArrayList<>();
        for (String raw : s.split("\\r?\\n")) if (!raw.isBlank()) ls.add(raw.trim());
        if (ls.isEmpty()) return;
        long step = dur > 0 ? Math.max(1500, dur * 1000L / ls.size()) : 4000;
        for (int i = 0; i < ls.size(); i++) lines.add(new Line(i * step, ls.get(i)));
    }

    static int indexAt(long ms) {
        int lo = 0, hi = lines.size() - 1, ans = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (lines.get(mid).ms() <= ms) { ans = mid; lo = mid + 1; } else hi = mid - 1;
        }
        return ans;
    }

    static void centered(DrawContext c, TextRenderer tr, String s, int cx, int y, float sc, int color) {
        c.getMatrices().push();
        c.getMatrices().translate((float) cx, (float) y, 0f);
        c.getMatrices().scale(sc, sc, 1f);
        c.drawTextWithShadow(tr, s, -tr.getWidth(s) / 2, 0, color);
        c.getMatrices().pop();
    }

    public static void render(DrawContext c, MinecraftClient mc, int sw, int sh) {
        if (!Config.lyrics || !Songs.playing || lines.isEmpty()) return;
        long el = Songs.elapsedMs();
        int cur = indexAt(el);
        TextRenderer tr = mc.textRenderer;
        float sz = Config.lyricsSize;
        int lh = (int) (11 * sz) + 4;
        int y = Config.lyricsPos == 0 ? sh - 78 - lh * 2 : Config.lyricsPos == 1 ? 76 : sh / 2 + 30;
        int cx = sw / 2;

        if (cur > 0 && !lines.get(cur - 1).text().isEmpty())
            centered(c, tr, lines.get(cur - 1).text(), cx, y, sz * 0.75f, 0xFF8C8C8C);
        if (cur >= 0) {
            Line l = lines.get(cur);
            String text = l.text();
            long next = cur + 1 < lines.size() ? lines.get(cur + 1).ms() : l.ms() + 5000;
            float prog = Math.min(1f, Math.max(0f, (el - l.ms()) / (float) Math.max(300, Math.min(next - l.ms(), 6000) * 0.9f)));
            int k = (int) (text.length() * prog);
            int total = tr.getWidth(text);
            c.getMatrices().push();
            c.getMatrices().translate((float) cx, (float) (y + lh), 0f);
            c.getMatrices().scale(sz, sz, 1f);
            int x0 = -total / 2;
            String a = text.substring(0, k), b = text.substring(k);
            c.drawTextWithShadow(tr, a, x0, 0, 0xFFFF6A6A);
            c.drawTextWithShadow(tr, b, x0 + tr.getWidth(a), 0, 0xFFFFFFFF);
            c.getMatrices().pop();
        }
        if (cur + 1 < lines.size() && !lines.get(cur + 1).text().isEmpty())
            centered(c, tr, lines.get(cur + 1).text(), cx, y + lh * 2, sz * 0.75f, 0xFF8C8C8C);
    }
}
