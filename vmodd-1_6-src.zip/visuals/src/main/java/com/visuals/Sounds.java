package com.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

public class Sounds {
    public static final String[] NAMES = {"Нет", "Луч света", "Падение человека", "Святой дух"};
    public static final String[] HIT_NAMES = {"Нет", "Замыкание (твой)", "Динь", "Монета", "Поп", "Кристалл", "Бам"};
    public static final float[] HIT_VOL = {0.5f, 1.0f, 1.5f, 2.0f};
    public static final String[] HIT_VOL_NAMES = {"50%", "100%", "150%", "200%"};
    static SoundEvent[] EVENTS = new SoundEvent[4];
    static SoundEvent[] HITS = new SoundEvent[7];
    static long lastHit = 0;

    public static void register() {
        String[] ids = {null, "beam", "fall", "holy"};
        for (int i = 1; i < 4; i++) {
            Identifier id = Identifier.of("visuals", ids[i]);
            EVENTS[i] = Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
        }
        for (int i = 1; i < 7; i++) {
            Identifier id = Identifier.of("visuals", "hit" + i);
            HITS[i] = Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
        }
    }

    public static void play(int idx, ClientWorld w, Vec3d p) {
        if (idx <= 0 || idx > 3) return;
        w.playSound(p.x, p.y, p.z, EVENTS[idx], SoundCategory.PLAYERS, 1.5f, 1f, false);
    }

    // звук удара (вызов защищён от дубля в течение 120 мс)
    public static void hit() { playHit(Config.hitSound, true); }

    public static void playHit(int idx, boolean debounce) {
        if (idx <= 0 || idx > 6) return;
        long now = System.currentTimeMillis();
        if (debounce) {
            if (now - lastHit < 120) return;
            lastHit = now;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        float pitch = 0.96f + (float) Math.random() * 0.08f;
        mc.getSoundManager().play(PositionedSoundInstance.master(HITS[idx], pitch, HIT_VOL[Math.max(0, Math.min(3, Config.hitVol))]));
    }
}
